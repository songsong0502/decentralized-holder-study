"""Baseline decentralized solvers and fitting utilities.

Everything here is a strict generalisation of `medsolvers.decentralized`:
with `smooth_eps=0.0`, a constant step and `method="gt"` it reproduces that
routine bit for bit (verified in exp_r1).  The extra knobs are the ones the
review asks us to vary in order to isolate *why* the consensus error stops
falling:

  smooth_eps  -- replaces the non-differentiable penalty |v|^{1+a} by the
                 smoothed surrogate (v^2 + eps^2)^{(1+a)/2}, whose gradient
                 (1+a) v (v^2+eps^2)^{(a-1)/2} IS Lipschitz with constant of
                 order (1+a) eps^{a-1}.  eps -> 0 recovers the original.
  step_rule   -- a callable k -> eta_k, so a diminishing step can be used in
                 place of the fixed one.
  method      -- "gt"    gradient tracking (DIGing), the method under test;
                 "dgd"   plain decentralized gradient descent;
                 "extra" EXTRA, the exact first-order correction of Shi et al.
                 The last two are the decentralized baselines the review asks
                 for, run on exactly the same shared/private model.

Nothing in this module changes the objective: the shared anatomy z is still a
consensus variable, the private detail d_i is still updated locally and never
communicated.
"""
import numpy as np

import medmodel as mm
import medsolvers as ms


# ----------------------------------------------------------------------
def psi_grad(v, alpha, eps=0.0):
    """Gradient of the (optionally smoothed) sparsity penalty.

    eps = 0 : (1+a)|v|^a sign(v)                    -- a-Holder, non-Lipschitz
    eps > 0 : (1+a) v (v^2+eps^2)^{(a-1)/2}         -- Lipschitz
    """
    if eps <= 0.0:
        return ms._psi_grad(v, alpha)
    return (1.0 + alpha) * v * (v * v + eps * eps) ** (0.5 * (alpha - 1.0))


def const_step(eta):
    return lambda k: eta


def decaying_step(eta0, power):
    """eta_k = eta0 / (1+k)^power -- the classical diminishing-step rule."""
    return lambda k: eta0 / (1.0 + k) ** power


# ----------------------------------------------------------------------
def decentralized(ys, masks, alphas, lam_z, a_z, lam_d, step_rule, iters,
                  W=None, metric=None, eta_d=None, smooth_eps=0.0,
                  method="gt", cons_every=1):
    """Shared/private reconstruction solved without a master.

    Returns (history, X, Z, D, consensus history).
    """
    K = len(ys)
    W = ms.path_mixing(K) if W is None else W
    Z = np.zeros((K,) + masks[0].shape)
    D = np.zeros((K,) + masks[0].shape)

    def gz_local(i):
        return (ms.data_grad(Z[i] + D[i], ys[i], masks[i])
                + (lam_z / K) * psi_grad(Z[i], a_z, smooth_eps))

    G = np.array([gz_local(i) for i in range(K)])
    S = G.copy()
    Zprev, Gprev = None, None
    hist = [] if metric is None else [metric(Z + D)]
    cons = []
    for k in range(iters):
        eta = step_rule(k)
        etad = eta if eta_d is None else eta_d

        if method == "gt":
            Z = np.einsum("ij,jyx->iyx", W, Z) - eta * S
        elif method == "dgd":
            Z = np.einsum("ij,jyx->iyx", W, Z) - eta * G
        elif method == "extra":
            # EXTRA (Shi et al. 2015):
            #   z^1     = W z^0 - eta g^0
            #   z^{k+1} = (I+W) z^k - (I+W)/2 z^{k-1} - eta (g^k - g^{k-1})
            if Zprev is None:
                Znew = np.einsum("ij,jyx->iyx", W, Z) - eta * G
            else:
                IW = np.eye(K) + W
                Znew = (np.einsum("ij,jyx->iyx", IW, Z)
                        - np.einsum("ij,jyx->iyx", 0.5 * IW, Zprev)
                        - eta * (G - Gprev))
            Zprev, Gprev = Z, G
            Z = Znew
        else:
            raise ValueError(method)

        for i in range(K):
            D[i] -= etad * (ms.data_grad(Z[i] + D[i], ys[i], masks[i])
                            + lam_d * psi_grad(D[i], alphas[i], smooth_eps))

        Gnew = np.array([gz_local(i) for i in range(K)])
        if method == "gt":
            S = np.einsum("ij,jyx->iyx", W, S) + Gnew - G
        G = Gnew

        if metric is not None:
            hist.append(metric(Z + D))
        if (k + 1) % cons_every == 0 or k == iters - 1:
            zbar = Z.mean(0)
            cons.append(float(np.max(np.linalg.norm((Z - zbar).reshape(K, -1), axis=1))
                              / (np.linalg.norm(zbar) + 1e-30)))
    return np.array(hist), Z + D, Z, D, np.array(cons)


# ----------------------------------------------------------------------
def loglog_fit(x, y):
    """Least-squares fit of log y on log x with the statistics the review asks
    for: slope, standard error, two-sided 95% interval and R^2."""
    from scipy import stats
    lx, ly = np.log(np.asarray(x, float)), np.log(np.asarray(y, float))
    r = stats.linregress(lx, ly)
    dof = len(lx) - 2
    tcrit = stats.t.ppf(0.975, dof)
    return dict(slope=float(r.slope), stderr=float(r.stderr),
                r2=float(r.rvalue ** 2),
                ci=(float(r.slope - tcrit * r.stderr),
                    float(r.slope + tcrit * r.stderr)),
                intercept=float(r.intercept), n=len(lx))


def mean_ci(v):
    """Mean, sample SD and 95% confidence interval of the mean."""
    from scipy import stats
    v = np.asarray(v, float)
    n = len(v)
    m, sd = float(v.mean()), float(v.std(ddof=1))
    h = stats.t.ppf(0.975, n - 1) * sd / np.sqrt(n)
    return dict(mean=m, sd=sd, ci=(m - h, m + h), n=n)


# ----------------------------------------------------------------------
def prox_psi(v, t, alpha, iters=40):
    """Proximal operator of t*|x|^{1+alpha}, computed coordinate-wise.

    The optimality condition x + t(1+a)|x|^a sign(x) = v is monotone and
    sign-preserving, so with w = |x| >= 0 and b = |v| we solve
        g(w) = w + t(1+a) w^a - b = 0
    by safeguarded Newton from w = b (g is increasing, g(0) <= 0 <= g(b)).
    """
    b = np.abs(v)
    w = b.copy()
    c = t * (1.0 + alpha)
    for _ in range(iters):
        wa = np.where(w > 0, w, 0.0) ** alpha
        g = w + c * wa - b
        dg = 1.0 + c * alpha * np.where(w > 1e-300, w, 1e-300) ** (alpha - 1.0)
        w = np.maximum(w - g / dg, 0.0)
    return np.sign(v) * w


def decentralized_prox(ys, masks, alphas, lam_z, a_z, lam_d, eta, iters,
                       W=None, metric=None, eta_d=None, cons_every=1):
    """Decentralized PROXIMAL gradient tracking.

    The non-smooth penalty is handled by its proximal operator instead of by
    a gradient step; only the smooth data term is tracked.  This is the
    decentralized proximal/composite scheme of Wang and co-authors applied to
    the same shared/private model, and it is the natural baseline for a
    method whose difficulty is a non-Lipschitz penalty.
    """
    K = len(ys)
    W = ms.path_mixing(K) if W is None else W
    Z = np.zeros((K,) + masks[0].shape)
    D = np.zeros((K,) + masks[0].shape)
    eta_d = eta if eta_d is None else eta_d

    def gsmooth(i):
        return ms.data_grad(Z[i] + D[i], ys[i], masks[i])

    G = np.array([gsmooth(i) for i in range(K)])
    S = G.copy()
    hist = [] if metric is None else [metric(Z + D)]
    cons = []
    for k in range(iters):
        Z = prox_psi(np.einsum("ij,jyx->iyx", W, Z) - eta * S,
                     eta * lam_z / K, a_z)
        for i in range(K):
            D[i] = prox_psi(D[i] - eta_d * ms.data_grad(Z[i] + D[i], ys[i], masks[i]),
                            eta_d * lam_d, alphas[i])
        Gnew = np.array([gsmooth(i) for i in range(K)])
        S = np.einsum("ij,jyx->iyx", W, S) + Gnew - G
        G = Gnew
        if metric is not None:
            hist.append(metric(Z + D))
        if (k + 1) % cons_every == 0 or k == iters - 1:
            zbar = Z.mean(0)
            cons.append(float(np.max(np.linalg.norm((Z - zbar).reshape(K, -1), axis=1))
                              / (np.linalg.norm(zbar) + 1e-30)))
    return np.array(hist), Z + D, Z, D, np.array(cons)
