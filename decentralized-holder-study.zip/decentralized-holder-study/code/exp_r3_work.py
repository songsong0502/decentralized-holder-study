"""R3 -- what each method actually costs to reach the same accuracy.

Figure 1b of the report charges every method for the grid points one worker
must solve for.  That is a fair measure of the coupling a step induces, but
it is not a cost model: an explicit step is one matrix-vector product, an
IMEX step is a triangular solve against a matrix factorised once, a backward
Euler step is three Newton iterations each with its own factorisation and
solve, and a gradient-tracking step adds two rounds of neighbour
communication that none of the others need.

The run below is done in two passes.  The first finds, for each method, the
iteration at which the relative field error first falls below 1e-3.  The
second re-runs exactly that many iterations with counters attached, so every
column of the table refers to the same accuracy rather than the same budget.
Wall-clock is measured on that second pass; all four run in one process on
one core, so it measures arithmetic and says nothing about a deployment.
"""
import time

import numpy as np

import graphs, decentralized as dec, models_dec as md, pdesolvers as ps

NGRID, M = 12, 4
ALPHAS = [0.5] * M
TOL = 1e-3
STEPS = dict(fwd=0.12, imex=0.30, bwd=1.00, gt=0.04)


class Counted(ps.SteadyRD):
    """SteadyRD keeping a tally of the work it is asked to do."""

    def __init__(self, nodes, owner):
        super().__init__(nodes, owner)
        self.c = dict(grad=0, matvec=0, react=0, factor_setup=0,
                      factor_step=0, solve=0, newton=0)

    def residual(self, u):
        # react() below does its own counting, so only the outer work is
        # tallied here
        self.c["grad"] += 1; self.c["matvec"] += 1
        return super().residual(u)

    def react(self, u):
        self.c["react"] += 1
        return super().react(u)


def run_forward(prob, tau, iters, met):
    u = np.zeros(prob.n); hist = [met(u)]
    with np.errstate(over="ignore", invalid="ignore"):
        for _ in range(iters):
            u = u - tau * prob.residual(u)
            if not np.all(np.isfinite(u)):
                hist.append(np.inf); break
            hist.append(met(u))
    return np.array(hist), u


def run_imex(prob, tau, iters, met):
    u = np.zeros(prob.n)
    inv = np.linalg.inv(np.eye(prob.n) + tau * prob.A)
    prob.c["factor_setup"] += 1
    hist = [met(u)]
    for _ in range(iters):
        rhs = u - tau * (prob.react(u) - prob.q)
        u = inv @ rhs
        prob.c["solve"] += 1; prob.c["matvec"] += 1
        hist.append(met(u))
    return np.array(hist), u


def run_backward(prob, tau, iters, met, newton=3):
    u = np.zeros(prob.n); I = np.eye(prob.n); hist = [met(u)]
    for _ in range(iters):
        uk = u.copy(); v = u.copy()
        for _ in range(newton):
            G = v + tau * (prob.A @ v + prob.react(v) - prob.q) - uk
            prob.c["matvec"] += 1; prob.c["grad"] += 1
            J = I + tau * (prob.A + np.diag(prob.react_prime(v)))
            v = v - np.linalg.solve(J, G)
            prob.c["factor_step"] += 1; prob.c["solve"] += 1; prob.c["newton"] += 1
        u = v
        hist.append(met(u))
    return np.array(hist), u


def run_gt(nodes, W, eta, iters, x0, x_star):
    m, n = len(nodes), len(x0)
    X = np.tile(x0, (m, 1)).astype(float)
    G = dec.grad_all(nodes, X); S = G.copy()
    den = np.linalg.norm(x0 - x_star) + 1e-30
    err = [float(np.linalg.norm(X.mean(0) - x_star) / den)]
    edges = int((np.count_nonzero(W) - m) / 2)
    c = dict(grad=m, matvec=m, react=m, factor_setup=0, factor_step=0,
             solve=0, newton=0, rounds=0, floats=0)
    for _ in range(iters):
        X = W @ X - eta * S
        Gnew = dec.grad_all(nodes, X)
        S = W @ S + Gnew - G
        G = Gnew
        c["grad"] += m; c["matvec"] += m; c["react"] += m
        c["rounds"] += 2
        c["floats"] += 2 * 2 * edges * n
        err.append(float(np.linalg.norm(X.mean(0) - x_star) / den))
    return np.array(err), X.mean(0), c, edges


def main():
    nodes, u0, u_exact, owner = md.make_pde(N=NGRID, m=M, alphas=ALPHAS)
    den = np.linalg.norm(u_exact)
    core = u_exact == 0.0
    met = lambda u: float(np.linalg.norm(u - u_exact) / den)
    n = len(u_exact)
    W = graphs.metropolis(graphs.ring(M))

    # ---- pass 1: how many iterations does each need? -----------------
    budgets = dict(fwd=20000, imex=20000, bwd=2000, gt=20000)
    p = Counted(nodes, owner)
    its = {}
    its["fwd"] = ps.iters_to_tol(run_forward(p, STEPS["fwd"], budgets["fwd"], met)[0], TOL)
    p = Counted(nodes, owner)
    its["imex"] = ps.iters_to_tol(run_imex(p, STEPS["imex"], budgets["imex"], met)[0], TOL)
    p = Counted(nodes, owner)
    its["bwd"] = ps.iters_to_tol(run_backward(p, STEPS["bwd"], budgets["bwd"], met)[0], TOL)
    its["gt"] = ps.iters_to_tol(run_gt(nodes, W, STEPS["gt"], budgets["gt"], u0, u_exact)[0], TOL)

    # ---- pass 2: rerun to exactly that many iterations, with counters -
    rows = []

    p = Counted(nodes, owner)
    t0 = time.perf_counter(); h, u = run_forward(p, STEPS["fwd"], its["fwd"], met)
    rows.append(("forward Euler", STEPS["fwd"], its["fwd"], dict(p.c, rounds=0, floats=0),
                 time.perf_counter() - t0, h, u, n // M))

    p = Counted(nodes, owner)
    t0 = time.perf_counter(); h, u = run_imex(p, STEPS["imex"], its["imex"], met)
    rows.append(("IMEX Euler", STEPS["imex"], its["imex"], dict(p.c, rounds=0, floats=0),
                 time.perf_counter() - t0, h, u, n))

    p = Counted(nodes, owner)
    t0 = time.perf_counter(); h, u = run_backward(p, STEPS["bwd"], its["bwd"], met)
    rows.append(("backward Euler", STEPS["bwd"], its["bwd"], dict(p.c, rounds=0, floats=0),
                 time.perf_counter() - t0, h, u, 3 * n))

    t0 = time.perf_counter()
    h, u, c, edges = run_gt(nodes, W, STEPS["gt"], its["gt"], u0, u_exact)
    rows.append(("decentralized GT", STEPS["gt"], its["gt"], c,
                 time.perf_counter() - t0, h, u, n // M))

    print(f"grid n={n}, m={M} subdomains, ring with {edges} edges; "
          f"every row is run to relative field error {TOL:g}\n")
    print(f"{'method':<19}{'step':>6}{'iters':>7}{'grad ev':>9}{'nonlin ev':>11}"
          f"{'factorise':>11}{'solve':>7}{'Newton':>8}{'comm rd':>9}"
          f"{'MB moved':>10}{'time(s)':>9}{'unknowns/step':>15}")
    for name, step, it, c, t, h, u, unk in rows:
        fac = c["factor_setup"] + c["factor_step"]
        print(f"{name:<19}{step:>6.2f}{it:>7d}{c['grad']:>9d}{c['react']:>11d}"
              f"{fac:>11d}{c['solve']:>7d}{c['newton']:>8d}{c['rounds']:>9d}"
              f"{c['floats']*8/1e6:>10.2f}{t:>9.3f}{unk:>15d}")

    print("\n'unknowns/step' is the number of grid points one worker must "
          "assemble or solve for in a single step:")
    print("  n/m for a local stencil, n for a global solve, 3n for three "
          "Newton steps on a global system.")
    print("\naccuracy reached at the tolerance iteration:")
    for name, step, it, c, t, h, u, unk in rows:
        ce = float(np.linalg.norm(u[core] - u_exact[core]) / den)
        print(f"  {name:<19} field {h[-1]:.3e}   dead core {ce:.3e}")


if __name__ == "__main__":
    main()
