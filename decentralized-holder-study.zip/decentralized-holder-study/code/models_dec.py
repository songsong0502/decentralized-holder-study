"""Problem builders for the decentralized experiments.

Every builder returns objects consumable by decentralized.py:
  - a list of Node objects (node i owns Q_i, q_i, alpha_i);
  - x0 (common start) and x_star (planted exact minimiser).

  synth : controlled consensus quadratic + l_{1+alpha} sparsity, used for the
          process-per-node check (exp_f_distributed.py).
  pde   : the reaction-diffusion problem of Section 2.1.  The unscaled
          five-point Laplacian A is split edge by edge into symmetric pieces
          A_i, one per horizontal strip (interface edges half to each strip);
          worker i carries the reaction exponent alpha_i on its own grid
          points only, and q_i is planted so that x_star is the exact
          minimiser of sum_i f_i.  Every worker keeps a full copy of the field.
  fin, drone : further builders kept from earlier development; they are not
          used by any experiment of the paper.
"""
import numpy as np

from decentralized import Node, plant_linear_terms


# ----------------------------------------------------------------------
def _spd_factor(n, k, rng, ridge):
    """A random SPD matrix B B'/k + ridge I from a k-factor model."""
    B = rng.standard_normal((n, k)) * (0.5 + rng.random((n, k)))
    return B @ B.T / k + ridge * np.eye(n)


def _sparse_star(n, s, rng, positive=False):
    """A vector with exactly s nonzeros; the other n-s entries are exact
    zeros so the non-Lipschitz set {x_j = 0} is touched at the optimum."""
    x = np.zeros(n)
    idx = rng.choice(n, size=s, replace=False)
    vals = 0.5 + rng.random(s)
    if not positive:
        vals *= rng.choice([-1.0, 1.0], size=s)
    x[idx] = vals
    return x


# ======================================================================
# Controlled synthetic consensus problem
# ======================================================================
def make_synth(n=60, m=8, alphas=None, lam=0.05, s=None, k=8,
               ridge=1e-2, seed=0):
    """min sum_i [ 1/2 x'Q_i x - q_i'x + lam sum_j |x_j|^{1+alpha_i} ].

    x_star is sparse (touches the non-smooth set); q_i planted so x_star is
    the exact global minimiser.  alphas is a length-m vector of per-node
    Holder exponents.
    """
    rng = np.random.default_rng(seed)
    if alphas is None:
        alphas = [0.5] * m
    s = s if s is not None else n // 3
    Qs = [_spd_factor(n, k, rng, ridge) for _ in range(m)]
    x_star = _sparse_star(n, s, rng)
    # lam may be a scalar (same weight everywhere) or a length-m sequence,
    # letting a single worker carry a different penalty weight -- used by G2
    # to separate the effect of the exponent from that of the weight.
    lams = [lam] * m if np.isscalar(lam) else list(lam)
    kinds = ["abs"] * m
    qs = plant_linear_terms(Qs, lams, alphas, kinds, x_star)
    nodes = [Node(Qs[i], qs[i], lams[i], alphas[i], "abs") for i in range(m)]
    x0 = np.zeros(n)
    return nodes, x0, x_star


# ======================================================================
# Model 1: reaction-diffusion PDE, domain-decomposed, heterogeneous p_i
# ======================================================================
def _grid_laplacian_blocks(N, m):
    """Dirichlet 5-point Laplacian on the (N-1)^2 interior grid, returned
    as m symmetric additive blocks A_i (one per horizontal strip of grid
    rows) with A = sum_i A_i.  Each interior edge is assigned to the strip
    of its lower-index endpoint; interface edges split half-and-half, so the
    assembly is exact and every A_i is symmetric PSD and local to its strip.

    Also returns `owner`, the strip index owning each grid coordinate.
    """
    n1 = N - 1
    n = n1 * n1
    h2 = 1.0   # unit-weight graph Laplacian (illustrative scaling, well conditioned)
    # coordinate k = (i,j), i=k%n1 (x), j=k//n1 (y); strip by grid-row j
    owner = np.array([ (k // n1) * m // n1 for k in range(n) ])
    A = [np.zeros((n, n)) for _ in range(m)]

    def add_edge(a, b, strip_weight):
        for strip, w in strip_weight:
            A[strip][a, a] += w * h2
            A[strip][b, b] += w * h2
            A[strip][a, b] -= w * h2
            A[strip][b, a] -= w * h2

    for k in range(n):
        i, j = k % n1, k // n1
        for (di, dj) in [(1, 0), (0, 1)]:            # +x and +y neighbours
            ii, jj = i + di, j + dj
            if ii < n1 and jj < n1:
                kk = jj * n1 + ii
                oa, ob = owner[k], owner[kk]
                if oa == ob:
                    add_edge(k, kk, [(oa, 1.0)])
                else:
                    add_edge(k, kk, [(oa, 0.5), (ob, 0.5)])
    # Dirichlet boundary: diagonal contribution for missing neighbours,
    # assigned to the coordinate's own strip (keeps A_i local + makes A SPD)
    for k in range(n):
        i, j = k % n1, k // n1
        miss = (i == 0) + (i == n1 - 1) + (j == 0) + (j == n1 - 1)
        A[owner[k]][k, k] += miss * h2
    return A, owner


def make_pde(N=12, m=4, alphas=None, gamma=0.5, ridge=1e-6, seed=1):
    """Domain-decomposed reaction-diffusion.  Subdomain i has its own
    reaction exponent alpha_i on its own grid points; a dead-core x_star
    (zero on a subregion) puts the non-Lipschitz set inside the domain."""
    rng = np.random.default_rng(seed)
    n1 = N - 1
    n = n1 * n1
    if alphas is None:
        alphas = [0.5] * m
    A, owner = _grid_laplacian_blocks(N, m)
    Qs = [A[i] + (ridge) * np.eye(n) for i in range(m)]

    # dead-core solution: zero on a disc near the origin corner, smooth bump
    xs = (np.arange(n1) + 1.0) / N
    X, Y = np.meshgrid(xs, xs)
    r = np.sqrt(X ** 2 + Y ** 2).ravel()
    x_star = ((1.5 * r - 0.5) ** 2) * np.maximum(0.0, r - 1.0 / 3.0)  # dead core r<=1/3

    # per-node reaction weight: gamma on the node's own grid points only
    lams = []
    for i in range(m):
        w = np.where(owner == i, gamma, 0.0)
        lams.append(w)
    kinds = ["pos"] * m
    qs = plant_linear_terms(Qs, lams, alphas, kinds, x_star)
    nodes = [Node(Qs[i], qs[i], lams[i], alphas[i], "pos") for i in range(m)]
    x0 = np.zeros(n)
    return nodes, x0, x_star, owner


# ======================================================================
# Model 2: multi-institution sparse portfolio, consensus on a common book
# ======================================================================
def make_finance(n_assets=80, m=6, alphas=None, T=400, k=5,
                 lam=2e-3, delta=1e-3, s=None, seed=11):
    """Each institution i estimates its own covariance Sigma_i from its own
    returns history (own factor emphasis) and regularises with its own
    l_{1+alpha_i} sparsity (trading style).  Consensus on the common book w;
    w_star is sparse (most assets not held)."""
    rng = np.random.default_rng(seed)
    s = s if s is not None else n_assets // 4
    Qs = []
    for i in range(m):
        # institution-specific factor exposures -> heterogeneous covariance
        F = 0.01 * rng.standard_normal((T, k))
        Bmat = rng.standard_normal((n_assets, k)) * (0.5 + rng.random((n_assets, k)))
        R = F @ Bmat.T + 0.02 * rng.standard_normal((T, n_assets))
        Rc = R - R.mean(axis=0)
        Qs.append(Rc.T @ Rc / T + delta * np.eye(n_assets))
    if alphas is None:
        alphas = [0.5] * m
    w_star = _sparse_star(n_assets, s, rng)
    lams = [lam] * m
    kinds = ["abs"] * m
    qs = plant_linear_terms(Qs, lams, alphas, kinds, w_star)
    nodes = [Node(Qs[i], qs[i], lams[i], alphas[i], "abs") for i in range(m)]
    w0 = np.zeros(n_assets)
    return nodes, w0, w_star


# ======================================================================
# Model 4: drone-swarm distributed estimation, consensus on a common field
# ======================================================================
def make_drone(n=64, m=9, alphas=None, n_meas=40, lam=0.02, delta=1e-2,
               s=None, seed=7):
    """Drone i senses a common sparse field theta through its own operator
    H_i (its viewpoint) and adds its own robust l_{1+alpha_i} prior.
    Consensus on theta over the formation graph; theta_star is sparse."""
    rng = np.random.default_rng(seed)
    s = s if s is not None else n // 6
    Qs = []
    for i in range(m):
        H = rng.standard_normal((n_meas, n)) / np.sqrt(n_meas)
        Qs.append(H.T @ H + delta * np.eye(n))
    if alphas is None:
        alphas = [0.5] * m
    theta_star = _sparse_star(n, s, rng)
    lams = [lam] * m
    kinds = ["abs"] * m
    qs = plant_linear_terms(Qs, lams, alphas, kinds, theta_star)
    nodes = [Node(Qs[i], qs[i], lams[i], alphas[i], "abs") for i in range(m)]
    theta0 = np.zeros(n)
    return nodes, theta0, theta_star
