"""Multi-slice sparse imaging: phantoms, acquisition, and per-slice exponents.

WHAT IS BEING RECONSTRUCTED.  A stack of K neighbouring slices of one volume.
Each slice i is an image u_i on an NX x NX pixel grid; u_i[j] is the intensity
of pixel j.  The modality in mind is one whose images are sparse in the pixel
domain -- angiography, fluorescence molecular tomography, sparse-tracer PET --
because that is the setting where a sum_j |u_j|^p prior is the right model.

SLICE STRUCTURE.  Every slice is

    u_i  =  (shared anatomy)  +  (slice-specific lesions) ,

where the shared anatomy is a branching vessel tree plus a few organ blobs
that is COMMON to the whole stack -- adjacent slices of one volume show the
same vessels and organs -- and the lesions are small bright foci at distinct
locations whose NUMBER grows across the stack.  The slices therefore differ
exactly by their lesions, which are sparse.  That is deliberate: it is the
"common component plus sparse innovations" structure the reconstruction model
assumes, and it is what makes the private part genuinely sparse.  (An earlier
version perturbed the anatomy by independent per-pixel noise in each slice;
that forces the private part to carry a dense deviation spread over the whole
anatomy, which contradicts its sparsity prior and destroys the benefit of
sharing.  Slice-to-slice anatomical change in a real stack is a slow drift,
not per-pixel noise.)  The shared part is what makes joint reconstruction worthwhile; the
lesions are what make the slices genuinely different images, and what give
each slice its own measurable sparsity.

ACQUISITION.  y_i = M_i (F u_i) + noise, with F the orthonormal 2-D DFT and
M_i a variable-density k-space mask (denser at low frequencies, as in
compressed-sensing MRI).  Each slice gets its OWN independently drawn mask at
the same sampling fraction, which is what accelerated multi-slice protocols
do in practice.  This matters for the whole study: with one common mask the
same frequencies are missing from every slice and pooling the stack can only
average noise, whereas independently drawn masks give the slices
COMPLEMENTARY k-space coverage, so the anatomy they share is seen through the
union of the patterns.  Using a subsampled Fourier operator rather than a
dense Gaussian matrix is both more faithful to a scanner and cheap enough to
run at 64 x 64: every operator application is an FFT.
"""
import numpy as np

from exponents import ggd_tail_index

NX = 64                      # image side; images are NX x NX
K = 4                        # slices reconstructed together
N_LESION = [2, 5, 9, 14]     # slice-specific foci: sparse -> dense
SAMPLE_FRAC = 0.30           # fraction of k-space retained by the mask


# ----------------------------------------------------------------------
# phantom construction
# ----------------------------------------------------------------------
def _disc(img, cy, cx, rad, amp, soft=0.8):
    """Add a soft-edged disc (a blob or focal lesion)."""
    n = img.shape[0]
    yy, xx = np.mgrid[0:n, 0:n]
    r = np.sqrt((yy - cy) ** 2 + (xx - cx) ** 2)
    img += amp * np.clip((rad + soft - r) / soft, 0.0, 1.0)


def _segment(img, p0, p1, width, amp):
    """Add a straight vessel segment of the given width between two points."""
    n = img.shape[0]
    yy, xx = np.mgrid[0:n, 0:n]
    y0, x0 = p0
    y1, x1 = p1
    dy, dx = y1 - y0, x1 - x0
    L2 = dy * dy + dx * dx + 1e-12
    t = ((yy - y0) * dy + (xx - x0) * dx) / L2
    t = np.clip(t, 0.0, 1.0)
    py, px = y0 + t * dy, x0 + t * dx
    r = np.sqrt((yy - py) ** 2 + (xx - px) ** 2)
    img += amp * np.clip((width - r) / max(width, 1e-6), 0.0, 1.0)


def shared_anatomy(nx=NX):
    """A branching vessel tree plus two organ blobs, identical in every slice."""
    img = np.zeros((nx, nx))
    c = nx // 2
    # main trunk and branches
    _segment(img, (0.18 * nx, 0.50 * nx), (0.52 * nx, 0.50 * nx), 1.5, 1.00)
    _segment(img, (0.52 * nx, 0.50 * nx), (0.74 * nx, 0.30 * nx), 1.2, 0.90)
    _segment(img, (0.52 * nx, 0.50 * nx), (0.76 * nx, 0.70 * nx), 1.2, 0.90)
    _segment(img, (0.74 * nx, 0.30 * nx), (0.88 * nx, 0.22 * nx), 0.9, 0.75)
    _segment(img, (0.76 * nx, 0.70 * nx), (0.90 * nx, 0.80 * nx), 0.9, 0.75)
    _segment(img, (0.34 * nx, 0.50 * nx), (0.30 * nx, 0.72 * nx), 1.0, 0.80)
    # two organ blobs
    _disc(img, 0.28 * nx, 0.28 * nx, 0.055 * nx, 0.85)
    _disc(img, 0.66 * nx, 0.60 * nx, 0.045 * nx, 0.70)
    return np.clip(img, 0.0, 1.6)


def build_slices(rng, nx=NX, k=K, n_lesion=None, jitter=0.0):
    """The K ground-truth slices: shared anatomy + per-slice focal lesions."""
    n_lesion = N_LESION if n_lesion is None else n_lesion
    base = shared_anatomy(nx)
    support = base > 0.02
    truths, lesion_masks = [], []
    for i in range(k):
        img = base * (1.0 + jitter * rng.standard_normal(base.shape)) if jitter \
            else base.copy()
        les = np.zeros_like(img)
        placed = 0
        while placed < n_lesion[i]:
            cy, cx = rng.integers(int(0.12 * nx), int(0.88 * nx), 2)
            # keep lesions off the vessel tree so they are genuinely new detail
            if support[cy, cx]:
                continue
            _disc(les, cy, cx, rng.uniform(0.9, 1.5), rng.uniform(0.55, 0.85))
            placed += 1
        truths.append(np.clip(img + les, 0.0, None))
        lesion_masks.append(les > 0.02)
    return np.array(truths), np.array(lesion_masks), base


# ----------------------------------------------------------------------
# acquisition operator: subsampled 2-D DFT
# ----------------------------------------------------------------------
def kspace_mask(rng, nx=NX, frac=SAMPLE_FRAC, core=0.08):
    """Variable-density random mask.

    Frequencies are drawn INDEPENDENTLY with probability falling as
    1/(1+c r^2) in the normalised radius r, and the low-frequency core is
    always kept.  The density constant c is found by bisection so that the
    expected sampling fraction equals `frac`.  Drawing independently (rather
    than taking the highest-density entries) is what makes two masks from two
    different seeds genuinely different, which is the point of giving each
    slice its own.
    """
    fy = np.fft.fftfreq(nx)[:, None]
    fx = np.fft.fftfreq(nx)[None, :]
    r = np.sqrt(fy ** 2 + fx ** 2)
    r = r / r.max()
    keep_core = r < core

    def prob_at(c):
        p = 1.0 / (1.0 + c * r ** 2)
        p[keep_core] = 1.0
        return p

    lo, hi = 0.0, 1e4
    for _ in range(60):
        mid = 0.5 * (lo + hi)
        if prob_at(mid).mean() > frac:
            lo = mid
        else:
            hi = mid
    p = prob_at(0.5 * (lo + hi))
    return (rng.random((nx, nx)) < p) | keep_core


def fwd(u, mask):
    """y = M F u  (orthonormal 2-D DFT, then keep the sampled entries)."""
    return np.fft.fft2(u, norm="ortho") * mask


def adj(y, mask):
    """F^H M^H y, returned real (the images are real-valued)."""
    return np.real(np.fft.ifft2(y * mask, norm="ortho"))


def slice_masks(rng, k=K, nx=NX, frac=SAMPLE_FRAC):
    """One independently drawn mask per slice, all at the same rate."""
    return np.array([kspace_mask(rng, nx, frac) for _ in range(k)])


def acquire(truths, masks, noise, rng):
    """Noisy k-space measurements, one set per slice, each under its own mask."""
    ys = []
    for u, m in zip(truths, masks):
        y = fwd(u, m)
        nz = (rng.standard_normal(y.shape) + 1j * rng.standard_normal(y.shape))
        ys.append(y + noise * nz * m / np.sqrt(2.0))
    return np.array(ys)


# ----------------------------------------------------------------------
# per-slice exponents, measured (never chosen)
# ----------------------------------------------------------------------
def prior_scan(i, rng, nx=NX, n_lesion=None):
    """An independent realisation of slice i's tissue statistics, standing for
    a previously acquired scan under the same protocol.  The exponent is
    estimated from these, never from the image being reconstructed."""
    n_lesion = N_LESION if n_lesion is None else n_lesion
    t, _, _ = build_slices(rng, nx=nx, k=1, n_lesion=[n_lesion[i]])
    return t[0].ravel()


def measure_alphas(rng, k=K, reps=12, nx=NX, n_lesion=None):
    """Tail index of each slice's coefficient histogram (see exponents.py)."""
    out = []
    for i in range(k):
        est = [ggd_tail_index(prior_scan(i, rng, nx, n_lesion)) for _ in range(reps)]
        out.append(float(np.mean(est)))
    return out
