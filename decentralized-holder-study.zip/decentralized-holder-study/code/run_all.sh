#!/bin/bash
# Runs every experiment of the manuscript, then regenerates figures and tables.
# Raw outputs and logs go to ../results, figures to ../figures.
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
cd "$(dirname "$0")"
R=../results
mkdir -p $R ../figures
run() { echo "== $1 $(date +%T)"; python3 $1.py > $R/$1.log 2>&1; echo "done $1 $(date +%T)"; }
run exp_p2_protocol & run exp_r1_lipschitz_control & wait
run exp_p1_scaling & run exp_p3_newton & wait
run exp_c1_floor_controls
run exp_c2_mismatch
run exp_c3_validation
run exp_c4_exponent
run exp_c5_brain
run exp_r6_baselines & run exp_r7_repeats & wait
run exp_r5_mismatch & run exp_m1_medical & wait
run exp_m2_consensus & run exp_g1_exponent_estimation & wait
run exp_r2_heterogeneity & run exp_r3_work & wait
run exp_f_distributed
python3 make_figures.py
python3 make_tables.py
echo ALLDONE
