"""F -- process-per-node exactness and data-locality check.

Runs gradient tracking two ways on the same synthetic consensus problem:
in-process (W @ X) and as m separate OS processes exchanging vectors only
along graph edges (dist_dec.py).  Prints the final-mean discrepancy (should
be ~machine precision) and each worker's resident memory (each holds one
operator Q_i, none holds another's data).
"""
import numpy as np

import graphs, decentralized as dec, models_dec as md
from dist_dec import run_distributed


def main():
    m, n = 6, 60
    nodes, x0, xs = md.make_synth(n=n, m=m, alphas=[0.5] * m, lam=0.05, seed=0)
    A = graphs.ring(m)
    W = graphs.metropolis(A)
    eta, it = 0.01, 1500

    _, _, X_ip = dec.gt(nodes, W, eta, it, x0, xs)
    mean_ip = X_ip.mean(axis=0)

    mean_mp, mem = run_distributed(nodes, A, W, eta, it, x0)

    dev = np.linalg.norm(mean_mp - mean_ip) / (np.linalg.norm(mean_ip) + 1e-30)
    print(f"in-process vs process-per-node mean deviation: {dev:.2e}")
    print(f"per-worker RSS (MB): {[round(v, 1) for v in mem]}")
    print(f"each worker holds one {n}x{n} operator = "
          f"{n * n * 8 / 1e6:.3f} MB of data; no worker holds another's.")


if __name__ == "__main__":
    main()
