"""Genuine process-per-node decentralized gradient tracking.

Every node is a separate OS process that holds ONLY its own data (Q_i, q_i,
alpha_i) and talks solely to its graph neighbours over pipes -- there is no
master and no node ever sees another node's operator.  This is the literal
form of the scheme decentralized.py runs in-process with the matrix product
W @ X: here each neighbour average is assembled from messages that actually
travel edge by edge.

Two facts it certifies (see exp_f_distributed.py):
  * exactness: the process network's final mean equals the in-process
    gradient-tracking iterate to machine precision -- the abstraction is
    faithful, so the Holder findings hold for a real deployment;
  * data locality: each worker's resident memory holds one operator Q_i and
    O(n) vectors; no node holds the others' data.  Unlike branch2's
    row-partition (one object split m ways), here the m operators are
    genuinely distinct local data (finance desks, hospitals, drones), so the
    distributed win is parallelism + data locality, not memory division.
"""
import os

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")

import multiprocessing as mp
import numpy as np


def proc_mem_mb():
    with open("/proc/self/status") as fh:
        for line in fh:
            if line.startswith("VmRSS"):
                return float(line.split(":")[1].split()[0]) / 1024.0
    return -1.0


def _exchange(conns, tag, vec):
    """Send vec to every neighbour, then collect their vectors (no master).
    Pipe OS buffers make send-all-then-recv-all deadlock-free for O(n) msgs."""
    for c in conns.values():
        c.send((tag, vec))
    got = {}
    for j, c in conns.items():
        t, v = c.recv()
        assert t == tag
        got[j] = v
    return got


def worker(idx, Q, q, lam, alpha, kind, w_self, w_nb, conns,
           eta, iters, x0, result_conn):
    from decentralized import Node
    nd = Node(Q, q, lam, alpha, kind)
    x = x0.copy()
    s = nd.grad(x)
    g = s.copy()
    result_conn.send(("mem0", proc_mem_mb()))
    for _ in range(iters):
        xin = _exchange(conns, "x", x)
        xnew = w_self * x + sum(w_nb[j] * xin[j] for j in conns) - eta * s
        gnew = nd.grad(xnew)
        sin = _exchange(conns, "s", s)
        s = w_self * s + sum(w_nb[j] * sin[j] for j in conns) + gnew - g
        x, g = xnew, gnew
    result_conn.send(("final", x))
    result_conn.send(("mem1", proc_mem_mb()))
    result_conn.close()


def run_distributed(nodes, A_adj, W, eta, iters, x0):
    """Spawn one process per node; return (mean iterate, per-worker RSS MB)."""
    ctx = mp.get_context("spawn")
    m = len(nodes)
    # one duplex pipe per undirected edge, split between its endpoints
    conns = [dict() for _ in range(m)]
    for i in range(m):
        for j in range(i + 1, m):
            if A_adj[i, j]:
                a, b = ctx.Pipe()
                conns[i][j] = a
                conns[j][i] = b
    procs, results = [], []
    for i in range(m):
        parent, child = ctx.Pipe()
        w_nb = {j: W[i, j] for j in conns[i]}
        p = ctx.Process(target=worker,
                        args=(i, nodes[i].Q, nodes[i].q, nodes[i].lam,
                              nodes[i].alpha, nodes[i].kind, W[i, i], w_nb,
                              conns[i], eta, iters, x0, child))
        p.start()
        procs.append(p)
        results.append(parent)
    finals = [None] * m
    mem = [None] * m
    for i, r in enumerate(results):
        while True:
            tag, val = r.recv()
            if tag == "final":
                finals[i] = val
            elif tag == "mem1":
                mem[i] = val
                break
    for p in procs:
        p.join()
    return np.mean(finals, axis=0), mem
