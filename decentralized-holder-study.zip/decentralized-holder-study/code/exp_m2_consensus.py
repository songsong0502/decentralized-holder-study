"""M2 -- what decentralization costs, and how consensus behaves.

M1 established that sharing the anatomy across slices helps.  This script
asks the questions specific to doing that WITHOUT a central machine.

(a) Does the decentralized run reach the centralized solution?  Both solve
    the same model (*) at the same step size; we compare reconstruction
    quality and the distance between the two solutions.

(b) What does the network actually exchange?  We count the vectors crossing
    edges per iteration and confirm no worker ever holds another's data.

(c) How does consensus behave under a non-Lipschitz penalty?  Standard
    gradient-tracking theory (Lipschitz gradients) predicts the consensus
    error decays to zero.  Here the shared penalty is only alpha-Holder, and
    the consensus error instead settles on a floor.  We sweep the step size
    and fit the exponent of that floor, which is the same
    stagnation-and-oscillation phenomenon the PDE experiments show, now
    appearing in the consensus channel.

(d) Does the slice topology matter?  The natural graph is the chain of
    neighbouring slices; we compare it against an all-to-all network.
"""
import numpy as np
import matplotlib.pyplot as plt

from figstyle import PALETTE, LINESTYLES
import medmodel as mm
import medsolvers as ms
import imgmetrics as im
import exp_m1_medical as M1

FIGDIR = __import__("os").environ.get("FIGDIR", __import__("os").path.join(__import__("os").path.dirname(__import__("os").path.abspath(__file__)), "..", "figures"))

NOISE = 0.06
LAM_Z, LAM_D = 0.1, 0.06
ETA_D, ITERS = 0.30, 6000
ETA_MAIN = 0.15
# dense grid: five points cannot support a fitted exponent, and the
# review asks for the regression statistics that go with it
ETA_SWEEP = [0.28, 0.25, 0.22, 0.20, 0.17, 0.15, 0.13, 0.10, 0.08,
             0.06, 0.05, 0.04]


def main():
    truths, lesions, base, masks, alphas = M1.setup()
    a_z = float(np.mean(alphas))
    metric = M1.make_metric(truths)
    nx, K = mm.NX, mm.K
    ys = mm.acquire(truths, masks, NOISE, np.random.default_rng(M1.SEED_NOISE))

    # ---- (a) decentralized vs centralized, matched step ----
    h_cen, X_cen, _, _ = ms.centralized(ys, masks, alphas, LAM_Z, a_z, LAM_D,
                                        ETA_MAIN, ITERS, metric)
    h_dec, X_dec, Z, D, cons = ms.decentralized(ys, masks, alphas, LAM_Z, a_z,
                                                LAM_D, ETA_MAIN, ITERS,
                                                metric=metric,
                                                track_consensus=True, eta_d=ETA_D)
    nc, pc, sc = im.report(X_cen, truths, nx)
    nd, pd, sd = im.report(X_dec, truths, nx)
    print(f"(a) matched step {ETA_MAIN}, {ITERS} iterations")
    print(f"    centralized (data pooled) NRMSE={nc:.4f}  PSNR={pc:.2f} dB  SSIM={sc:.3f}")
    print(f"    decentralized (data local) NRMSE={nd:.4f}  PSNR={pd:.2f} dB  SSIM={sd:.3f}")
    print(f"    quality cost of locality: {pc-pd:+.2f} dB PSNR, "
          f"solutions differ by {np.linalg.norm(X_dec-X_cen)/np.linalg.norm(X_cen):.2e}")

    # ---- (b) what crosses an edge ----
    W = ms.path_mixing(K)
    edges = int((np.count_nonzero(W) - K) / 2)
    per_iter = 2 * edges * 2 * nx * nx        # z and s, both directions
    meas_per_worker = int(masks[0].sum())
    print(f"(b) slice chain: {K} workers, {edges} edges, rho={ms.spectral_gap(W):.3f}")
    print(f"    per iteration {per_iter} floats cross edges "
          f"(z and s, {nx*nx} each way per edge)")
    print(f"    each worker holds {meas_per_worker} k-space samples and its own "
          f"d_i; neither is ever transmitted")

    # ---- (c) consensus floor vs step size ----
    print("(c) consensus error floor against step size")
    floors = []
    for eta in ETA_SWEEP:
        h, X, Zs, Ds, cs = ms.decentralized(ys, masks, alphas, LAM_Z, a_z, LAM_D,
                                            eta, ITERS, metric=metric,
                                            track_consensus=True, eta_d=ETA_D)
        floors.append(cs[-1])
        print(f"    eta={eta:.2f}: NRMSE={h[-1]:.4f}  consensus floor={cs[-1]:.3e}")
    import baseline_solvers as rs
    fit = rs.loglog_fit(ETA_SWEEP, floors)
    slope = fit["slope"]
    print(f"    fitted floor ~ eta^{slope:.2f} (SE {fit['stderr']:.2f}, "
          f"95% CI [{fit['ci'][0]:.2f}, {fit['ci'][1]:.2f}], R2 {fit['r2']:.3f}, "
          f"n={fit['n']})")
    print(f"    single-machine Holder reference 1/(1-a_z) = {1/(1-a_z):.2f} "
          f"at the measured a_z = {a_z:.2f}")

    # ---- (d) topology ----
    W_full = np.full((K, K), 1.0 / K)
    h_full, X_full, _, _, c_full = ms.decentralized(ys, masks, alphas, LAM_Z, a_z,
                                                    LAM_D, ETA_MAIN, ITERS,
                                                    W=W_full, metric=metric,
                                                    track_consensus=True, eta_d=ETA_D)
    print(f"(d) topology at step {ETA_MAIN}: chain NRMSE={h_dec[-1]:.4f} "
          f"(consensus {cons[-1]:.2e}) vs all-to-all NRMSE={h_full[-1]:.4f} "
          f"(consensus {c_full[-1]:.2e})")

    # ---------------- figure ----------------
    fig, axes = plt.subplots(1, 3, figsize=(11.0, 3.4))

    ax = axes[0]
    ax.semilogy(h_cen, color=PALETTE[1], ls=LINESTYLES[1], lw=1.6,
                label="centralized (data pooled)")
    ax.semilogy(h_dec, color=PALETTE[2], ls=LINESTYLES[2], lw=1.6,
                label="decentralized (data local)")
    ax.set_xlabel("iterations"); ax.set_ylabel("mean NRMSE")
    ax.set_title("(a) decentralized vs centralized", fontsize=9)
    ax.legend(fontsize=6.8, loc="upper right")

    ax = axes[1]
    ax.semilogy(cons, color=PALETTE[0], ls=LINESTYLES[0], lw=1.5,
                label=rf"chain, $\eta={ETA_MAIN}$")
    ax.semilogy(c_full, color=PALETTE[3], ls=LINESTYLES[2], lw=1.5,
                label=rf"all-to-all, $\eta={ETA_MAIN}$")
    ax.set_xlabel("iterations")
    ax.set_ylabel(r"consensus error $\max_i\|z_i-\bar z\|/\|\bar z\|$")
    ax.set_title("(b) consensus error", fontsize=9)
    ax.legend(fontsize=6.8, loc="upper right")

    ax = axes[2]
    ax.loglog(ETA_SWEEP, floors, marker="o", ms=4.5, color=PALETTE[0],
              ls="none", label="measured floor")
    xs = np.array(ETA_SWEEP)
    fit = np.exp(np.polyval(np.polyfit(np.log(xs), np.log(floors), 1), np.log(xs)))
    ax.loglog(xs, fit, color=PALETTE[2], ls=LINESTYLES[2],
              label=rf"fit $\propto\eta^{{{slope:.2f}}}$")
    ax.set_xlabel(r"step size $\eta$")
    ax.set_ylabel("consensus floor")
    ax.set_title(r"(c) consensus floor vs step size", fontsize=9)
    ax.legend(fontsize=6.8, loc="lower right")

    fig.savefig(f"{FIGDIR}/fig_m2_consensus.pdf")
    fig.savefig(f"{FIGDIR}/fig_m2_consensus.png")
    plt.close(fig)


if __name__ == "__main__":
    main()
