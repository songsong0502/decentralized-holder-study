"""C1 -- controls that separate the Hoelder penalty from the shared/private
update architecture, and a robustness analysis of the fitted floor exponent.

Floor estimator throughout: median of the consensus error over the last 10%
of the iterations ("tail median"); the final value and the tail mean and the
tail range (oscillation envelope) are recorded as well.

(a) main step sweep, eta_d fixed at 0.30, 12 steps, 6000 and 12000 iterations
    (asymptotic check), fit statistics incl. leave-one-out slopes
(b) same sweep with eta_d = 2 eta (fixed ratio)
(c) eta = 0.15 with eta_d in {0.075, 0.15, 0.30, 0.60}
(d) no private variable (u_i = z): 8-step sweep at a_z = 0.21 and at a_z = 1
(e) private variable frozen after 6000 iterations, GT continued 6000 more
(f) three update orderings at eta = 0.15
(g) five further instances (phantom, masks, noise resampled): 8-step sweep each
"""
import os

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")

import json
import sys
import time
from multiprocessing import Pool

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import medmodel as mm
import ctrl_solver as cs
import baseline_solvers as rs
import exp_m1_medical as M1

RES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "results")
NOISE = 0.06
LAM_Z, LAM_D = 0.1, 0.06
ETAS12 = [0.28, 0.25, 0.22, 0.20, 0.17, 0.15, 0.13, 0.10, 0.08, 0.06, 0.05, 0.04]
ETAS8 = [0.28, 0.22, 0.17, 0.13, 0.10, 0.08, 0.06, 0.04]


def instance(r=None):
    if r is None:
        truths, lesions, base, masks, alphas = M1.setup()
        ys = mm.acquire(truths, masks, NOISE, np.random.default_rng(M1.SEED_NOISE))
    else:
        alphas = mm.measure_alphas(np.random.default_rng(M1.SEED_ALPHA))
        truths, _, _ = mm.build_slices(np.random.default_rng(100 + r))
        masks = mm.slice_masks(np.random.default_rng(200 + r))
        ys = mm.acquire(truths, masks, NOISE, np.random.default_rng(300 + r))
    return truths, masks, alphas, ys


def job(spec):
    tag, eta, eta_d, iters, kw, r, a_z_override = spec
    truths, masks, alphas, ys = instance(r)
    a_z = float(np.mean(alphas)) if a_z_override is None else a_z_override
    X, Z, D, cons = cs.run(ys, masks, alphas, LAM_Z, a_z, LAM_D, eta, eta_d, iters, **kw)
    nrmse = float(np.linalg.norm(X - truths) / np.linalg.norm(truths))
    out = dict(tag=tag, eta=eta, eta_d=eta_d, iters=iters, r=r, a_z=a_z,
               nrmse=nrmse, **cs.floor_stats(cons))
    if kw.get("freeze_at"):
        k = kw["freeze_at"]
        out["before_freeze"] = cs.floor_stats(cons[:k])
    # thinned consensus curve
    idx = np.unique(np.round(np.logspace(0, np.log10(iters), 200)).astype(int)) - 1
    out["curve_it"] = (idx + 1).tolist()
    out["curve"] = [float(cons[i]) for i in idx]
    print(tag, eta, eta_d, iters, r, f"{out['median']:.3e}", f"{nrmse:.4f}", flush=True)
    return out


def main():
    t0 = time.time()
    jobs = []
    for eta in ETAS12:
        jobs.append(("main6000", eta, 0.30, 6000, {}, None, None))
        jobs.append(("main12000", eta, 0.30, 12000, {}, None, None))
    for eta in ETAS8:
        jobs.append(("ratio2", eta, 2 * eta, 6000, {}, None, None))
    for ed in (0.075, 0.15, 0.30, 0.60):
        jobs.append(("etad", 0.15, ed, 6000, {}, None, None))
    for eta in ETAS8:
        jobs.append(("noprivate_a0.21", eta, 0.30, 6000, {"private": False}, None, None))
        jobs.append(("noprivate_a1", eta, 0.30, 6000, {"private": False}, None, 1.0))
    jobs.append(("freeze", 0.15, 0.30, 12000, {"freeze_at": 6000}, None, None))
    for od in ("zds", "dzs", "zsd"):
        jobs.append((f"order_{od}", 0.15, 0.30, 6000, {"order": od}, None, None))
    for r in range(5):
        for eta in ETAS8:
            jobs.append((f"seed{r}", eta, 0.30, 6000, {}, r, None))
    with Pool(2) as pool:
        res = pool.map(job, jobs, chunksize=1)

    def fit_of(rows, key="median"):
        x = [q["eta"] for q in rows]; y = [q[key] for q in rows]
        f = rs.loglog_fit(x, y)
        loo = [rs.loglog_fit([a for j, a in enumerate(x) if j != i],
                             [b for j, b in enumerate(y) if j != i])["slope"]
               for i in range(len(x))]
        f["loo_min"], f["loo_max"] = float(min(loo)), float(max(loo))
        f["range"] = (float(min(x)), float(max(x)))
        return f

    fits = {}
    for tag in ("main6000", "main12000", "ratio2", "noprivate_a0.21"):
        rows = [q for q in res if q["tag"] == tag]
        for key in ("median", "final", "mean"):
            fits[f"{tag}|{key}"] = fit_of(rows, key)
    seeds = []
    for r in range(5):
        rows = [q for q in res if q["tag"] == f"seed{r}"]
        f = fit_of(rows)
        fits[f"seed{r}"] = f
        seeds.append(f["slope"])
    fits["seeds_mean_sd"] = (float(np.mean(seeds)), float(np.std(seeds, ddof=1)))
    for k, v in fits.items():
        print(k, v)
    with open(os.path.join(RES, "c1_floor_controls.json"), "w") as fh:
        json.dump(dict(runs=res, fits=fits), fh, indent=1)
    print(f"[elapsed {time.time()-t0:.0f} s]")


if __name__ == "__main__":
    main()
