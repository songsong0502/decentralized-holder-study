"""P1 -- grid refinement and more workers with a consistent continuum scaling.

The matrix A built by models_dec is the unscaled five-point stencil A0
(4 on the diagonal, -1 off it), i.e. A0 ~ -h^2 Laplacian.  The discrete
equation  A0 u + gamma (1+alpha) u_+^alpha = q  is therefore h^2 times the
continuous equation  -Lap u + gamma_c (1+alpha) u^alpha = f  with
    gamma = gamma_c h^2,      q = h^2 f .
The base runs use gamma = 0.5 at h = 1/12, i.e. gamma_c = 72.  To refine the
grid while keeping the SAME continuous problem, gamma must shrink like h^2;
this script does exactly that (the earlier refinement kept gamma = 0.5 fixed,
which changes the continuous problem with the grid).

(a) N = 12, 16, 20, 24, 32, 48 (n = 121 ... 2209), m = 4 workers on a ring.
(b) m = 2, 4, 8, 16 workers at N = 20.
For gradient tracking we record iterations to relative field error 1e-3,
communication volume, wall time and consensus error; for forward and
backward Euler (sparse implementation) the iterations to the same accuracy.
"""
import os

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")

import json
import sys
import time

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import graphs, decentralized as dec, models_dec as md

RES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "results")
GAMMA_C = 0.5 * 12 ** 2        # continuum reaction coefficient of the base run
TOL = 1e-3
ETA_REF, LMAX_REF = 0.04, 7.864
TAU_F_REF = 0.12


def gamma_h(N):
    return GAMMA_C / N ** 2


def gt_to_tol(nodes, W, eta, x0, xs, cap=200000, chunk=50):
    m, n = len(nodes), len(x0)
    X = np.tile(x0, (m, 1)).astype(float)
    G = dec.grad_all(nodes, X); S = G.copy()
    den = np.linalg.norm(x0 - xs) + 1e-30
    edges = int((np.count_nonzero(W) - m) / 2)
    it = 0
    t0 = time.perf_counter()
    err = 1.0
    while it < cap and err > TOL:
        for _ in range(chunk):
            X = W @ X - eta * S
            Gn = dec.grad_all(nodes, X)
            S = W @ S + Gn - G
            G = Gn
            it += 1
        err = float(np.linalg.norm(X.mean(0) - xs) / den)
    dt = time.perf_counter() - t0
    xb = X.mean(0)
    cons = float(np.max(np.linalg.norm(X - xb, axis=1)) / (np.linalg.norm(xb) + 1e-30))
    floats = it * 2 * 2 * edges * n          # x and s, both directions, every edge
    return dict(iters=it, err=err, cons=cons, MB=floats * 8 / 1e6, sec=dt,
                sec_per_it=dt / max(it, 1), edges=edges)


def sparse_problem(nodes, owner):
    A = sp.csr_matrix(sum(nd.Q for nd in nodes))
    q = sum(nd.q for nd in nodes)
    gam = sum(np.asarray(nd.lam) for nd in nodes)
    alpha = np.array([nodes[o].alpha for o in owner], float)
    return A, q, gam, alpha


def fe_to_tol(A, q, gam, alpha, tau, xs, cap=400000):
    u = np.zeros(len(q)); den = np.linalg.norm(xs)
    for k in range(1, cap + 1):
        u = u - tau * (A @ u + gam * (1 + alpha) * np.maximum(u, 0) ** alpha - q)
        if k % 10 == 0 and np.linalg.norm(u - xs) / den <= TOL:
            return k
    return None


def be_to_tol(A, q, gam, alpha, tau, xs, newton=3, cap=500):
    n = len(q); u = np.zeros(n); den = np.linalg.norm(xs)
    I = sp.identity(n, format="csr")
    for k in range(1, cap + 1):
        uk = u.copy(); v = u.copy()
        for _ in range(newton):
            r = gam * (1 + alpha) * np.maximum(v, 0) ** alpha
            d = np.where(v > 0, gam * (1 + alpha) * alpha *
                         np.maximum(v, 1e-12) ** (alpha - 1), 0.0)
            Gv = v + tau * (A @ v + r - q) - uk
            J = (I + tau * (A + sp.diags(d))).tocsc()
            v = v - spla.spsolve(J, Gv)
        u = v
        if np.linalg.norm(u - xs) / den <= TOL:
            return k
    return None


def main():
    out = {"gamma_c": GAMMA_C, "grid": [], "workers": []}
    print(f"continuum coefficient gamma_c = {GAMMA_C}; gamma_h = gamma_c h^2")
    print(f"{'N':>4}{'n':>6}{'gamma_h':>9}{'lmax':>8}{'eta':>8}{'GT it':>8}"
          f"{'GT err':>10}{'cons':>10}{'MB':>9}{'ms/it':>8}{'FE it':>8}{'BE it':>7}")
    for N in (12, 16, 20, 24, 32, 48):
        m = 4
        nodes, x0, xs, owner = md.make_pde(N=N, m=m, alphas=[0.5] * m, gamma=gamma_h(N))
        A, q, gam, alpha = sparse_problem(nodes, owner)
        lmax = float(spla.eigsh(A, k=1, which="LA", return_eigenvectors=False)[0])
        scale = LMAX_REF / lmax
        W = graphs.metropolis(graphs.ring(m))
        r = gt_to_tol(nodes, W, ETA_REF * scale, x0, xs)
        itf = fe_to_tol(A, q, gam, alpha, TAU_F_REF * scale, xs)
        itb = be_to_tol(A, q, gam, alpha, 1.0, xs)
        row = dict(N=N, n=len(q), gamma=gamma_h(N), lmax=lmax, eta=ETA_REF * scale,
                   fe_iters=itf, be_iters=itb, **r)
        out["grid"].append(row)
        print(f"{N:>4}{len(q):>6}{gamma_h(N):>9.4f}{lmax:>8.3f}{ETA_REF*scale:>8.4f}"
              f"{r['iters']:>8d}{r['err']:>10.2e}{r['cons']:>10.2e}{r['MB']:>9.1f}"
              f"{1e3*r['sec_per_it']:>8.2f}{str(itf):>8}{str(itb):>7}", flush=True)
    print(f"\n{'m':>4}{'rho':>8}{'GT it':>8}{'GT err':>10}{'cons':>10}{'MB':>9}{'ms/it':>8}")
    for m in (2, 4, 8, 16):
        N = 20
        nodes, x0, xs, owner = md.make_pde(N=N, m=m, alphas=[0.5] * m, gamma=gamma_h(N))
        A, q, gam, alpha = sparse_problem(nodes, owner)
        lmax = float(spla.eigsh(A, k=1, which="LA", return_eigenvectors=False)[0])
        W = graphs.metropolis(graphs.ring(m))
        rho = graphs.spectral_gap(W)
        r = gt_to_tol(nodes, W, ETA_REF * LMAX_REF / lmax, x0, xs)
        out["workers"].append(dict(m=m, rho=rho, **r))
        print(f"{m:>4}{rho:>8.3f}{r['iters']:>8d}{r['err']:>10.2e}{r['cons']:>10.2e}"
              f"{r['MB']:>9.1f}{1e3*r['sec_per_it']:>8.2f}", flush=True)
    with open(os.path.join(RES, "p1_scaling.json"), "w") as fh:
        json.dump(out, fh, indent=1)


if __name__ == "__main__":
    main()
