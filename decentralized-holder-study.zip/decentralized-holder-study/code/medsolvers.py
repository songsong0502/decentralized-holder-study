"""Reconstruction algorithms for the multi-slice problem.

THE MODEL.  Neighbouring slices of one volume are nearly the same picture, but
they are not identical: each carries its own focal lesions.  Forcing the
workers to agree on the whole image would therefore be wrong, and simply
pulling neighbouring images toward each other (soft coupling) blurs exactly
the lesions one wants to see.  We instead split each slice into a shared part
and a private part,

    u_i  =  z  +  d_i ,

where z is the anatomy common to the stack -- a genuine CONSENSUS variable,
which every worker must agree on -- and d_i is slice-specific detail that
never leaves worker i.  The reconstruction problem is

    min_{z, d_1..d_K}   lam_z sum_j |z_j|^{1 + a_z}
        + sum_i [ 1/2 || M F (z + d_i) - y_i ||^2
                  + lam_d sum_j |d_ij|^{1 + alpha_i} ] ,                  (*)

which is jointly convex.  Both parts carry a sparsity prior because both are
sparse: the vessel tree that every slice shares, and the handful of focal
lesions that distinguish one slice from the next.  This is the "common
component plus sparse innovations" model of distributed compressed sensing
(Baron et al., JSM-1), with the bridge exponent of each part measured rather
than assumed.

Penalising d_i by a SPARSITY term rather than a ridge matters.  A ridge
shrinks every entry of d_i in proportion, which is precisely what blurs a
lesion; a sparsity penalty keeps the few large entries and suppresses the
noise-driven small ones.  The lesions live in d_i, which is never averaged
with any other worker's data.

SYMBOLS.  z, d_i, u_i in R^{n} (n = NX*NX, images held as NX x NX arrays);
M the k-space sampling mask; F the orthonormal 2-D DFT; y_i slice i's
measurements; lam2 the Tikhonov weight; lamp the sparsity weight; alpha_i the
measured Holder exponent of slice i (so the penalty exponent is p_i = 1+alpha_i);
lam_z the shared-part sparsity weight and a_z its exponent; lam_d the
private-part sparsity weight; eta the step size; W the mixing matrix.

THE THREE ALGORITHMS.
  independent   -- each worker solves its own slice alone; no z, no exchange.
  centralized   -- (*) solved with all K measurement sets on one machine.
  decentralized -- (*) solved by gradient tracking on z across the slice
                   chain, with d_i updated locally.  Worker i exchanges only
                   z_i and its tracking vector s_i with its two neighbours;
                   y_i and d_i never leave the worker.
"""
import numpy as np

import medmodel as mm


# ----------------------------------------------------------------------
def _psi_grad(v, alpha, eps=1e-12):
    """d/dv of sum_j |v_j|^{1+alpha}: the alpha-Holder (non-Lipschitz) term."""
    av = np.abs(v)
    return (1.0 + alpha) * np.where(av > eps, av ** alpha, 0.0) * np.sign(v)


def data_grad(x, y, mask):
    """d/dx of 1/2||M F x - y||^2 = F^H(M F x - y)."""
    return mm.adj(mm.fwd(x, mask) - y, mask)


def grad_x(x, y, mask, alpha, lam2, lamp, eps=1e-12):
    """Gradient of the single-slice objective (used by the independent
    baseline, which has no shared/private split)."""
    return data_grad(x, y, mask) + lam2 * x + lamp * _psi_grad(x, alpha, eps)


def path_mixing(k):
    """Metropolis weights on the chain 0-1-...-(k-1): the slice adjacency."""
    A = np.zeros((k, k))
    for i in range(k - 1):
        A[i, i + 1] = A[i + 1, i] = 1.0
    deg = A.sum(1)
    W = np.zeros((k, k))
    for i in range(k):
        for j in range(k):
            if i != j and A[i, j]:
                W[i, j] = 1.0 / (1.0 + max(deg[i], deg[j]))
        W[i, i] = 1.0 - W[i].sum()
    return W


def spectral_gap(W):
    ev = np.sort(np.abs(np.linalg.eigvals(W)))[::-1]
    return float(ev[1])


# ----------------------------------------------------------------------
def independent(ys, masks, alphas, lam2, lamp, eta, iters, metric=None):
    """Each slice reconstructed on its own.  No sharing of any kind."""
    K = len(ys)
    X = np.zeros((K,) + masks[0].shape)
    hist = [] if metric is None else [metric(X)]
    for _ in range(iters):
        for i in range(K):
            X[i] -= eta * grad_x(X[i], ys[i], masks[i], alphas[i], lam2, lamp)
        if metric is not None:
            hist.append(metric(X))
    return np.array(hist), X


def centralized(ys, masks, alphas, lam_z, a_z, lam_d, eta, iters, metric=None):
    """Objective (*) solved with every worker's data pooled on one machine.
    This is the accuracy ceiling the decentralized run is measured against."""
    K = len(ys)
    z = np.zeros(masks[0].shape)
    D = np.zeros((K,) + masks[0].shape)
    hist = [] if metric is None else [metric(z + D)]
    for _ in range(iters):
        gz = lam_z * _psi_grad(z, a_z)
        for i in range(K):
            gi = data_grad(z + D[i], ys[i], masks[i])
            gz = gz + gi
            D[i] -= eta * (gi + lam_d * _psi_grad(D[i], alphas[i]))
        z -= eta * gz / K
        if metric is not None:
            hist.append(metric(z + D))
    return np.array(hist), z + D, z, D


def decentralized(ys, masks, alphas, lam_z, a_z, lam_d, eta, iters, W=None,
                  metric=None, track_consensus=False, eta_d=None):
    """Objective (*) solved by DECENTRALIZED gradient tracking on the shared
    anatomy z, with the private detail d_i updated locally.

    Per iteration, worker i:
        z_i <- sum_j W_ij z_j  -  eta * s_i          (neighbour exchange)
        g_i <- grad_z f_i(z_i, d_i)
        s_i <- sum_j W_ij s_j  +  g_i^new - g_i^old  (neighbour exchange)
        d_i <- d_i - eta * ( data grad + lam_d psi'(d_i) )   (purely local)

    Only z_i and s_i cross an edge.  There is no master, no pooling, and no
    step in which any worker sees another worker's measurements y_j or
    private detail d_j.
    """
    K = len(ys)
    W = path_mixing(K) if W is None else W
    Z = np.zeros((K,) + masks[0].shape)
    D = np.zeros((K,) + masks[0].shape)

    def gz_local(i):
        """Worker i's gradient with respect to the SHARED variable."""
        return (data_grad(Z[i] + D[i], ys[i], masks[i])
                + (lam_z / K) * _psi_grad(Z[i], a_z))

    G = np.array([gz_local(i) for i in range(K)])
    S = G.copy()
    hist = [] if metric is None else [metric(Z + D)]
    cons = []
    eta_d = eta if eta_d is None else eta_d
    for _ in range(iters):
        # 1. mix with neighbours, then step along the tracked average gradient
        Z = np.einsum("ij,jyx->iyx", W, Z) - eta * S
        # 2. private detail: purely local, never communicated
        for i in range(K):
            D[i] -= eta_d * (data_grad(Z[i] + D[i], ys[i], masks[i])
                             + lam_d * _psi_grad(D[i], alphas[i]))
        # 3. re-evaluate the shared gradient at the CURRENT (Z, D) and track it.
        #    Evaluating after the private update keeps the tracked quantity
        #    consistent with the current state; doing it before leaves a
        #    persistent mismatch that stalls consensus.
        Gnew = np.array([gz_local(i) for i in range(K)])
        S = np.einsum("ij,jyx->iyx", W, S) + Gnew - G
        G = Gnew
        if metric is not None:
            hist.append(metric(Z + D))
        if track_consensus:
            zbar = Z.mean(0)
            cons.append(float(np.max(np.linalg.norm((Z - zbar).reshape(K, -1), axis=1))
                              / (np.linalg.norm(zbar) + 1e-30)))
    return np.array(hist), Z + D, Z, D, np.array(cons)
