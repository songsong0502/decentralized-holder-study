"""Copy the ICBM 2009a T1 template used in Section 3.2.5 into code/data/.

The template is not redistributed in this repository. It ships with nilearn
(tested with nilearn 0.14.1) as
nilearn/datasets/data/mni_icbm152_t1_tal_nlin_sym_09a_converted.nii.gz.

    pip install nilearn
    python get_template.py
"""
import os
import shutil

import nilearn

NAME = "mni_icbm152_t1_tal_nlin_sym_09a_converted.nii.gz"
src = os.path.join(os.path.dirname(nilearn.__file__), "datasets", "data", NAME)
dst_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
os.makedirs(dst_dir, exist_ok=True)
shutil.copyfile(src, os.path.join(dst_dir, NAME))
print("copied", src, "->", os.path.join(dst_dir, NAME))
