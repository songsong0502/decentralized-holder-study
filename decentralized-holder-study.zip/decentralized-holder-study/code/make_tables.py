"""Write every table of the revised manuscript as a LaTeX fragment, directly
from the raw outputs in results/, so that no number is copied by hand.

Output: results/tables/<NAME>.tex, one file per placeholder in manuscript.tex.
"""
import json
import os
import re

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "..", "results")
OUT = os.path.join(RES, "tables")
os.makedirs(OUT, exist_ok=True)


def J(name):
    return json.load(open(os.path.join(RES, name)))


def log(name):
    return open(os.path.join(RES, name)).read()


def sci(x, d=1):
    if x is None:
        return "n/a"
    if x == 0:
        return "$0$"
    e = int(np.floor(np.log10(abs(x))))
    m = x / 10 ** e
    if round(m, d) >= 10:
        m /= 10; e += 1
    return f"${m:.{d}f}\\times10^{{{e}}}$"


def table(name, caption, colspec, header, rows, small=True, note=None):
    body = "\n".join(" & ".join(r) + r"\\" for r in rows)
    s = (f"\\begin{{table}}[H]\n\\caption{{{caption}\\label{{tab:{name}}}}}\n"
         + ("\\small\n" if small else "")
         + "\\setlength{\\tabcolsep}{4pt}\n"
         + f"\\begin{{tabular}}{{@{{}}{colspec}@{{}}}}\n\\toprule\n{header}\\\\\n\\midrule\n"
         + body + "\n\\bottomrule\n\\end{tabular}\n"
         + (f"\n\\noindent{{\\footnotesize {note}}}\n" if note else "")
         + "\\end{table}\n")
    return s


def write(key, s):
    open(os.path.join(OUT, key + ".tex"), "w").write(s)


# ----------------------------------------------------------------------- PDE
p2 = J("p2_protocol.json")
d = p2["alpha0.5"]
NAMES = {"fe": "forward Euler (\\ref{eq:fwd})", "imex": "IMEX Euler (\\ref{eq:imex})",
         "be": "backward Euler, BE-N3", "bels": "backward Euler, BE-LS",
         "gt": "gradient tracking (\\ref{eq:gt})"}
REF = {"fe": 0.12, "imex": 0.3, "be": 1.0, "bels": 1.0, "gt": 0.04}
GLOBAL = {"fe": "no", "imex": "yes, prefactored", "be": "yes, every Newton step",
          "bels": "yes, every Newton step", "gt": "no"}


def pick(k, step):
    return next(x for x in d[k] if abs(x["step"] - step) < 1e-12)


rows = []
for k in NAMES:
    r = pick(k, REF[k])
    rows.append([NAMES[k], f"{REF[k]:g}", str(r["it3"]), sci(r["tail_median"]),
                 sci(r["core"]), sci(r["residual"]), GLOBAL[k]])
write("PDECOMPARETABLE", table(
    "pde-compare",
    "The discrete reaction-diffusion problem ($n=121$, $\\alpha_i\\equiv0.5$) solved at the "
    "speed-oriented steps. Final error: median of the relative field error over the last 10\\% "
    "of the iterations (20\\,000 iterations; 2000 time steps for BE-N3, 200 for BE-LS). "
    "Dead-core error: the same error restricted to the 8 nodes where $\\ustar=0$ (last iterate). "
    "Residual: $\\norm{\\nabla J(u)}/\\norm{q}$ at the last iterate. Global system: whether a step "
    "solves a linear system coupling all $n$ nodes.",
    "lrrrrrl", "\\textbf{Method} & \\textbf{Step} & \\textbf{It. to $\\mathbf{10^{-3}}$} & "
    "\\textbf{Final} & \\textbf{Dead core} & \\textbf{Residual} & \\textbf{Global system}", rows))

rows = []
for k in NAMES:
    st = [x for x in d[k] if x["stable"]]
    best = min(st, key=lambda x: x["tail_median"])
    f3 = [x for x in st if x["it3"] is not None]
    f4 = [x for x in st if x["it4"] is not None]
    b3 = min(f3, key=lambda x: x["it3"]) if f3 else None
    b4 = min(f4, key=lambda x: x["it4"]) if f4 else None
    unstable = [x["step"] for x in d[k] if not x["stable"]]
    rows.append([NAMES[k],
                 f"{min(x['step'] for x in d[k]):g} to {max(x['step'] for x in d[k]):g}",
                 f"{best['step']:g}", sci(best["tail_median"]),
                 f"{b3['it3']} ({b3['step']:g})" if b3 else "n/a",
                 f"{b4['it4']} ({b4['step']:g})" if b4 else "n/a",
                 ", ".join(f"{u:g}" for u in unstable) if unstable else "none"])
write("PDEACCTABLE", table(
    "pde-accuracy",
    "Step sweeps. Best final error: the smallest tail-median error over the sweep and the step "
    "that attains it. Iterations to $10^{-3}$ and $10^{-4}$: the smallest count over the sweep, "
    "with the step in parentheses. Unstable: steps at which the run diverged or ended above "
    "its initial error.",
    "lrrrrrr", "\\textbf{Method} & \\textbf{Steps} & \\textbf{Best step} & \\textbf{Best final} & "
    "\\textbf{It. to $\\mathbf{10^{-3}}$} & \\textbf{It. to $\\mathbf{10^{-4}}$} & "
    "\\textbf{Unstable}", rows))

p3 = J("p3_newton.json")
rows = []
for r in p3:
    if r["newton"] == "line search":
        lab = f"line search, $\\tau={r['tau']:g}$"
        nits = f"{r['avg_newton']:.1f}"
        gl = "n/a"
    else:
        lab = f"plain Newton, {r['newton'].replace('<=1e-12', 'up to 50')} it."
        nits = f"{r['avg_newton']:.0f}"
        gl = sci(r["G_last"])
    rows.append([lab, f"$10^{{{int(np.log10(r['floor']))}}}$", sci(r["final"]),
                 sci(r["core"]), gl, sci(r["G_max"]), nits])
write("NEWTONTABLE", table(
    "newton",
    "Backward Euler with different inner solvers ($\\tau=1$ unless stated). Plain Newton: "
    "2000 time steps; line search: 200 time steps, tolerance $10^{-10}$, at most 100 "
    "iterations. Floor: value at which the reaction derivative is evaluated for $0<v<$ floor. "
    "$\\norm{G}$: Newton residual at the end of the last time step, and its maximum over all "
    "steps. Errors are last-iterate values.",
    "lrrrrrr", "\\textbf{Inner solver} & \\textbf{Floor} & \\textbf{Final} & "
    "\\textbf{Dead core} & \\textbf{$\\norm{G}$ last} & \\textbf{$\\norm{G}$ max} & "
    "\\textbf{Newton it./step}", rows))

# work table from the r3 log
t = log("exp_r3_work.log")
rows = []
for line in t.splitlines():
    m = re.match(r"(forward Euler|IMEX Euler|backward Euler|decentralized GT)\s+([\d.]+)\s+(\d+)"
                 r"\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+([\d.]+)", line)
    if m:
        g = m.groups()
        rows.append([g[0], g[1], g[2], g[3], g[5], g[6], g[7], g[8], g[9]])
write("WORKTABLE", table(
    "work",
    "Operations to reach a relative field error of $10^{-3}$ at the speed-oriented steps "
    "(BE-N3 for backward Euler). Gradient evaluations count full or local gradients as "
    "evaluated (four local ones per gradient-tracking iteration); factorizations and solves "
    "involve the $n\\times n$ system; a communication round is one exchange of vectors with "
    "the ring neighbours.",
    "lrrrrrrrr", "\\textbf{Method} & \\textbf{Step} & \\textbf{Iter.} & \\textbf{Grad. ev.} & "
    "\\textbf{Factor.} & \\textbf{Solves} & \\textbf{Newton} & \\textbf{Comm. rounds} & "
    "\\textbf{MB moved}", rows))

# placement from the r2 log
t = log("exp_r2_heterogeneity.log")
rows = []
for line in t.splitlines():
    m = re.match(r"\[([\d., ]+)\]\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\de.+-]+)\s+([\de.+-]+)"
                 r"\s+([\de.+-]+)\s+(.*)", line)
    if m:
        g = m.groups()
        rows.append([f"({g[0]})", g[1], g[2], g[3], sci(float(g[4])), sci(float(g[5])),
                     sci(float(g[6])), g[7].strip().replace("->", "to")])
write("PLACEMENTTABLE", table(
    "placement",
    "Gradient tracking ($\\eta=0.04$, 12\\,000 iterations) for sixteen exponent vectors "
    "$(\\alpha_0,\\dots,\\alpha_3)$; strip 0 holds the dead core, and $q$ is recomputed for every "
    "vector. Errors are last-iterate values.",
    "lrrrrrrl", "\\textbf{Exponents} & \\textbf{Min} & \\textbf{Spread} & \\textbf{Strip 0} & "
    "\\textbf{Field err.} & \\textbf{Dead core} & \\textbf{Consensus} & \\textbf{Configuration}",
    rows, note=None))

p1 = J("p1_scaling.json")
rows = []
for r in p1["grid"]:
    rows.append([str(r["N"]), str(r["n"]), f"{r['gamma']:.4f}", f"{r['eta']:.4f}", str(r["iters"]),
                 sci(r["cons"]), f"{r['MB']:.1f}", f"{1e3*r['sec_per_it']:.2f}",
                 str(r["fe_iters"]), str(r["be_iters"])])
rows2 = []
for r in p1["workers"]:
    rows2.append([str(r["m"]), f"{r['rho']:.3f}", str(r["iters"]), sci(r["cons"]),
                  f"{r['MB']:.1f}", f"{1e3*r['sec_per_it']:.2f}"])
s = table("scaling",
          "Grid refinement at $\\gamma_c=72$ (so $\\gamma=72h^2$) with $m=4$ workers on a ring, "
          "iterations to a relative field error of $10^{-3}$. FE: forward Euler, BE: backward "
          "Euler (three Newton iterations, sparse solves), both at steps scaled like those of "
          "Table~\\ref{tab:pde-compare}. MB: traffic of gradient tracking; ms/it: single-process "
          "time per iteration. Convergence is checked every 50 iterations for gradient tracking "
          "and every 10 for forward Euler, so the counts are rounded up to these multiples (850 "
          "and 70 at $N=12$, against 828 and 67 in Table~\\ref{tab:pde-compare}).",
          "rrrrrrrrrr", "$N$ & $n$ & $\\gamma$ & $\\eta$ & \\textbf{GT it.} & \\textbf{Consensus} & "
          "\\textbf{MB} & \\textbf{ms/it} & \\textbf{FE it.} & \\textbf{BE it.}", rows)
s += table("workers",
           "More workers at $N=20$ ($n=361$), ring topology, gradient tracking to $10^{-3}$.",
           "rrrrrr", "$m$ & $\\rho(W)$ & \\textbf{GT it.} & \\textbf{Consensus} & \\textbf{MB} & "
           "\\textbf{ms/it}", rows2)
write("SCALINGTABLE", s)

# --------------------------------------------------------------------- imaging
t = log("exp_m1_medical.log")
op = {}
for name in ("independent", "centralized", "decentralized"):
    m = re.search(name + r"\s+NRMSE=([\d.]+)\s+PSNR=([\d.]+) dB\s+SSIM=([\d.]+)", t)
    op[name] = m.groups()
t7 = log("exp_r7_repeats.log")
rep = {}
for name in ("independent", "centralized", "decentralized"):
    m = re.search(r"^" + name + r"\s+([\d.]+) \+- ([\d.]+) \[[^\]]*\]([\d.]+) \+- ([\d.]+) \[[^\]]*\]"
                  r"([\d.]+) \+- ([\d.]+)", t7, re.M)
    rep[name] = m.groups()
rows = []
for name, lab, held in (("independent", "per slice", "local"),
                        ("centralized", "pooled-data reference", "pooled"),
                        ("decentralized", "decentralized GT", "local")):
    a, r = op[name], rep[name]
    rows.append([lab, a[0], a[1], a[2], f"{float(r[0]):.4f} $\\pm$ {float(r[1]):.4f}",
                 f"{float(r[2]):.2f} $\\pm$ {float(r[3]):.2f}",
                 f"{float(r[4]):.3f} $\\pm$ {float(r[5]):.3f}", held])
write("IMGTABLE", table(
    "img-compare",
    "Multi-slice reconstruction, noise 0.06, $\\eta=0.15$, 4000 iterations. Operating point: "
    "one instance, oracle-tuned weights. Repeated: mean $\\pm$ standard deviation over 25 "
    "instances with phantom, masks and noise resampled and the weights fixed. NRMSE and PSNR "
    "are averages over the slices.",
    "lrrrrrrl", "\\textbf{Algorithm} & \\multicolumn{3}{c}{\\textbf{Operating point}} & "
    "\\multicolumn{3}{c}{\\textbf{25 instances}} & \\textbf{Data}\\\\\n & NRMSE & PSNR & SSIM & "
    "NRMSE & PSNR & SSIM &", rows))

c3 = J("c3_validation.json")
rows = []
for r in c3:
    inst = "operating point" if r["r"] is None else f"instance {r['r'] + 1}"
    for k in ("validation", "oracle", "fixed"):
        w = r["selected"][k]
        x = r[k]
        rows.append([f"{inst}, noise {r['noise']:g}" if k == "validation" else "", k,
                     f"({w[0]:g}, {w[1]:g}, {w[2]:g})", f"{x['ind']['psnr']:.2f}",
                     f"{x['cen']['psnr']:.2f}", f"{x['dec']['psnr']:.2f}",
                     f"{x['dec']['psnr'] - x['ind']['psnr']:+.2f}"])
write("VALTABLE", table(
    "validation",
    "Weights $(\\lambda_p,\\lambda_z,\\lambda_d)$ selected by k-space hold-out validation, by the "
    "oracle, and fixed at the operating-point values; PSNR in dB of the final reconstructions "
    "(4000 iterations). Last column: gain of the decentralized over the per-slice "
    "reconstruction.",
    "llrrrrr", "\\textbf{Instance} & \\textbf{Weights} & $(\\lambda_p,\\lambda_z,\\lambda_d)$ & "
    "\\textbf{Per slice} & \\textbf{Pooled} & \\textbf{Decentr.} & \\textbf{Gain}", rows,
    small=True))

c2 = J("c2_mismatch.json")
lab = {"baseline": "phantom (no mismatch)", "shift": "misregistration, up to {} px",
       "gain": "intensity variation $\\pm{:.0%}$", "overlap": "lesions at common positions",
       "frac": "sampling fraction {:.0%}", "commonmask": "one common mask (30\\%)"}
rows = []
for r in c2:
    k = r["kind"]
    t_ = lab[k].format(r["level"]).replace("%", "\\%") if "{" in lab[k] else lab[k]
    rows.append([t_, f"{r['union']:.2f}", f"{r['ind']['psnr']:.2f}", f"{r['cen']['psnr']:.2f}",
                 f"{r['dec']['psnr']:.2f}", f"{r['gain']:.3f}",
                 f"{r['dec']['psnr'] - r['cen']['psnr']:+.2f}"])
t5 = log("exp_r5_mismatch.log")
for line in t5.splitlines():
    m = re.match(r"\s+([\d.]+)\s+[\d.]+/([\d.]+)\s+[\d.]+/([\d.]+)\s+[\d.]+/([\d.]+)\s+([\d.]+)\s+"
                 r"([-+\d.]+)", line)
    if m and float(m.group(1)) in (1.0, 2.0):
        g = m.groups()
        rows.append([f"smooth drift {float(g[0]):g} px (oracle weights)", "0.68", g[1], g[2], g[3],
                     g[4], f"{float(g[3]) - float(g[2]):+.2f}"])
write("MISMATCHTABLE", table(
    "mismatch",
    "Departures from the shared/private model, noise 0.06, fixed weights unless stated. "
    "Union: fraction of k-space covered by the union of the masks. PSNR in dB. Gain: NRMSE of "
    "per-slice over decentralized reconstruction (above 1: sharing helps). Last column: "
    "decentralized minus pooled PSNR.",
    "lrrrrrr", "\\textbf{Variant} & \\textbf{Union} & \\textbf{Per slice} & \\textbf{Pooled} & "
    "\\textbf{Decentr.} & \\textbf{Gain} & \\textbf{Dec.$-$pool.}", rows))

c4 = J("c4_exponent.json")
rows = []
for r in c4["runs"]:
    a = "measured" if r["a"] == "measured" else f"{r['a']:g}"
    for s in ("fixed", "retuned"):
        x = r[s]
        rows.append([a if s == "fixed" else "", s, f"({x['weights'][0]:g}, {x['weights'][1]:g}, "
                     f"{x['weights'][2]:g})", f"{x['ind']:.4f}", f"{x['cen']:.4f}",
                     f"{x['dec']:.4f}", f"{x['gain']:.3f}", sci(x["floor"])])
write("SENSTABLE", table(
    "sens",
    "All exponents replaced by a common value $a$ (measured: the per-slice estimates and their "
    "mean). NRMSE of the whole stack, $\\norm{U-U^{\\star}}/\\norm{U^{\\star}}$, after 4000 "
    "iterations; weights fixed or re-selected against the ground truth on a $3\\times3$ grid; "
    "floor: consensus error, tail median.",
    "llrrrrrr", "$a$ & \\textbf{Weights} & $(\\lambda_p,\\lambda_z,\\lambda_d)$ & "
    "\\textbf{Per slice} & \\textbf{Pooled} & \\textbf{Decentr.} & \\textbf{Gain} & "
    "\\textbf{Floor}", rows))

# -------------------------------------------------------------- consensus
c1 = J("c1_floor_controls.json")
runs = c1["runs"]
rows = []
for eta in sorted({x["eta"] for x in runs if x["tag"] == "main6000"}, reverse=True):
    a = next(x for x in runs if x["tag"] == "main6000" and x["eta"] == eta)
    b = next(x for x in runs if x["tag"] == "main12000" and x["eta"] == eta)
    rows.append([f"{eta:.2f}", sci(a["median"], 2), sci(a["lo"], 2) + " to " + sci(a["hi"], 2),
                 sci(b["median"], 2), f"{100 * (b['median'] / a['median'] - 1):+.2f}\\%",
                 f"{a['nrmse']:.4f}"])
write("FLOORTABLE", table(
    "floor",
    "Consensus floor on the slice chain, $\\eta_d=0.30$: tail median over the last 10\\% of "
    "6000 and of 12\\,000 iterations, the tail range at 6000, the relative change, and the "
    "stack NRMSE.",
    "rrrrrr", "$\\eta$ & \\textbf{Floor (6000)} & \\textbf{Tail range (6000)} & "
    "\\textbf{Floor (12\\,000)} & \\textbf{Change} & \\textbf{NRMSE}", rows))

fits = c1["fits"]


def fitrow(lab, f):
    return [lab, f"{f['slope']:.3f}", f"{f['stderr']:.3f}",
            f"[{f['ci'][0]:.2f}, {f['ci'][1]:.2f}]", f"{f['intercept']:.2f}", f"{f['r2']:.3f}",
            f"{f['loo_min']:.2f} to {f['loo_max']:.2f}", str(f["n"])]


rows = [fitrow("$\\eta_d=0.30$ fixed, 6000 it.", fits["main6000|median"]),
        fitrow("$\\eta_d=0.30$ fixed, 12\\,000 it.", fits["main12000|median"]),
        fitrow("$\\eta_d=0.30$ fixed, final value", fits["main6000|final"]),
        fitrow("$\\eta_d=2\\eta$", fits["ratio2|median"]),
        fitrow("no private variable", fits["noprivate_a0.21|median"])]
for r in range(5):
    rows.append(fitrow(f"instance {r + 1}", fits[f"seed{r}"]))
get = lambda tag, **kw: next(x for x in runs if x["tag"] == tag and
                             all(abs(x[k] - v) < 1e-12 for k, v in kw.items()))
ctrl = [("paper order (\\ref{eq:img-z}) to (\\ref{eq:img-s})", get("order_zds")["median"]),
        ("private update before mixing", get("order_dzs")["median"]),
        ("tracked gradient before private update", get("order_zsd")["median"]),
        ("$\\eta_d=0.075$", get("etad", eta_d=0.075)["median"]),
        ("$\\eta_d=0.15$", get("etad", eta_d=0.15)["median"]),
        ("$\\eta_d=0.60$", get("etad", eta_d=0.6)["median"]),
        ("private part frozen after 6000 it.", get("freeze")["median"])]
rows2 = [[a, sci(b, 2)] for a, b in ctrl]
s = table("fits",
          "Fits of $\\log(\\text{floor})$ on $\\log\\eta$ over $\\eta\\in[0.04,0.28]$: slope, standard "
          "error, 95\\% interval, intercept, $R^2$, range of leave-one-out slopes, number of "
          "steps. Instances 1 to 5 resample phantom, masks and noise.",
          "lrrrrrrr", "\\textbf{Sweep} & \\textbf{Slope} & \\textbf{SE} & \\textbf{95\\% CI} & "
          "\\textbf{Intercept} & $R^2$ & \\textbf{Leave one out} & $n$", rows)
s += table("controls",
           "Consensus floor (tail median, 6000 iterations; 12\\,000 for the frozen run) at "
           "$\\eta=0.15$ under changes of the update order and of the private step.",
           "lr", "\\textbf{Variant} & \\textbf{Floor}", rows2)
write("CONTROLTABLE", s)

t6 = log("exp_r6_baselines.log")
rows = []
for name, lab in (("DGD", "DGD"), ("EXTRA", "EXTRA"), ("prox-GT", "proximal GT"),
                  ("GT", "gradient tracking")):
    m = re.search(r"^" + re.escape(name) + r"\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\de.+-]+)\s+"
                  r"([\d.]+)$", t6, re.M)
    g = m.groups()
    rows.append([lab, g[0], g[1], g[2], sci(float(g[3])), g[4]])
write("BASELINETABLE", table(
    "baselines",
    "Decentralized methods on the shared/private model at the operating point (noise 0.06, "
    "$\\eta=0.15$, 4000 iterations). Time: single-process wall-clock time of the whole run.",
    "lrrrrr", "\\textbf{Method} & \\textbf{NRMSE} & \\textbf{PSNR (dB)} & \\textbf{SSIM} & "
    "\\textbf{Consensus} & \\textbf{Time (s)}", rows))

# ----------------------------------------------------------------- brain
if os.path.exists(os.path.join(RES, "c5_brain.json")):
    c5 = J("c5_brain.json")
    rows = []
    for r in sorted(c5["runs"], key=lambda q: (q["noise"], q["seed"])):
        for k in ("validation", "oracle"):
            if k not in r:
                continue
            x = r[k]
            w = x["weights"]
            rows.append([f"{r['noise']:g}", str(r["seed"] + 1), k,
                         f"({w[0]:g}, {w[1]:g}, {w[2]:g})", f"{x['ind']['psnr']:.2f}",
                         f"{x['cen']['psnr']:.2f}", f"{x['dec']['psnr']:.2f}",
                         f"{x['dec']['ssim']:.3f}", f"{x['gain']:.3f}", sci(x["consensus"])])
    write("BRAINTABLE", table(
        "brain",
        "Eight slices of the ICBM 2009a T1 template, $128\\times128$, independent 30\\% masks. "
        "Realisation 1 selects the weights by validation on the grid $\\lambda_p\\in\\{0.02,0.05,0.1\\}$, "
        "$\\lambda_z\\in\\{0.05,0.1,0.2\\}$, $\\lambda_d\\in\\{0.03,0.1\\}$ with 1000 iterations per candidate "
        "(and, for reference, by the oracle on the same grid); "
        "realisations 2 and 3 resample masks and noise and reuse the validation weights. PSNR "
        "in dB averaged over slices; SSIM of the decentralized reconstruction; gain: NRMSE "
        "ratio; consensus: floor (tail median).",
        "rrlrrrrrrr", "\\textbf{Noise} & \\textbf{Real.} & \\textbf{Weights} & "
        "$(\\lambda_p,\\lambda_z,\\lambda_d)$ & \\textbf{Per slice} & \\textbf{Pooled} & "
        "\\textbf{Decentr.} & \\textbf{SSIM} & \\textbf{Gain} & \\textbf{Consensus}", rows))
print("tables written to", OUT)
