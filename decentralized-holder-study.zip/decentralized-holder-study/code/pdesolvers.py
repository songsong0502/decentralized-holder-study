"""Classical time-marching solvers for the steady reaction-diffusion problem.

THE PROBLEM.  On the unit square Omega, with s = (s1, s2) the SPATIAL
coordinate and u(s) >= 0 the reactant CONCENTRATION field, the steady
reaction-diffusion equation with fractional reaction order alpha is

    -Laplacian u(s) + gamma (1+alpha) u(s)^alpha = f(s),   s in Omega,   (PDE)

with u = 0 on the boundary.  Here
    gamma  -- weight of the reaction energy; the reaction coefficient of the
              PDE is gamma (1+alpha), a Thiele-type constant,
    alpha  -- the fractional reaction order of the medium at s,
    f      -- a prescribed source (forcing) term.

VARIATIONAL FORM -- why this is an optimization problem.  (PDE) is the
Euler-Lagrange equation of the energy

    J(u) = 1/2 * Integral |grad u|^2  +  gamma * Integral u^{1+alpha}
           -  Integral f*u ,

whose reaction term is the Holder penalty psi(t;alpha) = (t_+)^{1+alpha}
weighted by gamma.  Its first variation is gamma (1+alpha) u^alpha, so the
Euler-Lagrange equation carries that factor as well.

Setting the first variation of J to zero returns (PDE) exactly, so solving
the PDE and minimising J are the same task.  After discretising Omega on a
grid of n interior nodes and stacking the nodal values into a VECTOR
u in R^n, the energy becomes

    J(u) = 1/2 u' A u  +  sum_j gamma_j * (u_j)_+^{1+alpha_j}  -  q' u ,

    A  -- the discrete Laplacian (an n x n matrix; A u approximates -Lap u),
    q  -- the discretised source, q_j ~ f(s_j) * (cell area).  It is a FIXED
          VECTOR OF DATA, not the derivative of anything: differentiating
          -q'u with respect to u simply returns the constant -q.
    grad J(u) = A u + gamma (1+alpha) (u)_+^alpha - q,   and grad J(u)=0 is
    precisely the discrete form of (PDE).

This module solves grad J(u) = 0 by marching the gradient flow
u_t = -grad J(u) to steady state with three classical schemes, so the
decentralized method can be compared against standard practice.
"""
import numpy as np


class SteadyRD:
    """Aggregate discrete steady reaction-diffusion problem.

    Built from the per-subdomain Node objects, so the centralized solvers
    below and the decentralized method solve provably the SAME equations.
    """

    def __init__(self, nodes, owner):
        self.A = sum(nd.Q for nd in nodes)          # discrete Laplacian (+ridge)
        self.q = sum(nd.q for nd in nodes)          # discretised source f
        self.gam = sum(np.asarray(nd.lam) for nd in nodes)   # gamma per node point
        # each grid point carries the reaction order of the subdomain owning it
        self.alpha = np.array([nodes[o].alpha for o in owner], float)
        self.n = self.A.shape[0]
        self.lmax = float(np.linalg.eigvalsh(self.A).max())

    # reaction term gamma (1+alpha) u_+^alpha  and its derivative
    def react(self, u):
        return self.gam * (1.0 + self.alpha) * np.maximum(u, 0.0) ** self.alpha

    def react_prime(self, u, floor=1e-12):
        a = self.alpha
        up = np.maximum(u, floor)
        d = self.gam * (1.0 + a) * a * up ** (a - 1.0)
        return np.where(u > 0.0, d, 0.0)

    def residual(self, u):
        """grad J(u); zero exactly at the discrete solution."""
        return self.A @ u + self.react(u) - self.q

    def stable_step(self):
        """Largest step for which explicit Euler on the linear part is stable."""
        return 2.0 / self.lmax


# ----------------------------------------------------------------------
def forward_euler(prob, tau, iters, metric, u0=None):
    """Explicit (forward) Euler on u_t = -grad J(u).

    u^{k+1} = u^k - tau ( A u^k + react(u^k) - q ).
    One matrix-vector product per step, no linear solve, but the step is
    capped by 2/lambda_max(A) -- the classical explicit stability limit.
    """
    u = np.zeros(prob.n) if u0 is None else u0.copy()
    hist = [metric(u)]
    # a step above the stability limit is expected to blow up; overflow there
    # is the phenomenon being measured, not an error
    with np.errstate(over="ignore", invalid="ignore"):
        for _ in range(iters):
            u = u - tau * prob.residual(u)
            if not np.all(np.isfinite(u)):
                hist.append(np.inf)
                break
            hist.append(metric(u))
    return np.array(hist), u


def imex(prob, tau, iters, metric, u0=None):
    """Semi-implicit (IMEX) Euler: implicit in the stiff Laplacian, explicit
    in the reaction term.

        (I + tau A) u^{k+1} = u^k - tau ( react(u^k) - q ).

    One prefactorisation, then one triangular solve per step.  Removes the
    diffusion stability limit, so tau may be taken far larger.  The price is
    a GLOBAL linear solve coupling every grid point -- which is exactly what
    a decentralized method cannot do without extra machinery.
    """
    u = np.zeros(prob.n) if u0 is None else u0.copy()
    M = np.eye(prob.n) + tau * prob.A
    lu = np.linalg.inv(M)              # small n: explicit inverse is fine
    hist = [metric(u)]
    for _ in range(iters):
        rhs = u - tau * (prob.react(u) - prob.q)
        u = lu @ rhs
        if not np.all(np.isfinite(u)):
            hist.append(np.inf)
            break
        hist.append(metric(u))
    return np.array(hist), u


def backward_euler(prob, tau, iters, metric, u0=None, newton=3):
    """Fully implicit (backward) Euler, each step solved by Newton.

        u^{k+1} + tau ( A u^{k+1} + react(u^{k+1}) - q ) = u^k .

    Newton needs the Jacobian of the reaction term, react'(u) ~ u^{alpha-1},
    which BLOWS UP as u -> 0 when alpha < 1.  Exactly on the dead core
    (u = 0) the Jacobian is unbounded, so the derivative must be floored to
    keep the solve finite -- a concrete instance of the non-Lipschitz
    difficulty this report is about.
    """
    u = np.zeros(prob.n) if u0 is None else u0.copy()
    I = np.eye(prob.n)
    hist = [metric(u)]
    for _ in range(iters):
        uk = u.copy()
        v = u.copy()
        for _ in range(newton):
            G = v + tau * (prob.A @ v + prob.react(v) - prob.q) - uk
            J = I + tau * (prob.A + np.diag(prob.react_prime(v)))
            try:
                v = v - np.linalg.solve(J, G)
            except np.linalg.LinAlgError:
                break
        u = v
        if not np.all(np.isfinite(u)):
            hist.append(np.inf)
            break
        hist.append(metric(u))
    return np.array(hist), u


def iters_to_tol(hist, tol):
    """First index at which the metric drops below tol (None if never)."""
    idx = np.where(np.asarray(hist) <= tol)[0]
    return int(idx[0]) if idx.size else None
