"""Shared matplotlib style for all report figures.

Palette: validated categorical palette (fixed slot order, CVD-safe with
line styles as secondary encoding). Slots are never reassigned between
figures: series 1 always gets slot 1, etc.
"""
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

# Fixed categorical order (light surface): blue, aqua, yellow, green
# four clearly distinct hues: blue, teal-green, amber, purple.
# (the old fourth entry was a second green and was indistinguishable
# from the second entry in printed figures)
PALETTE = ["#2a78d6", "#1baf7a", "#eda100", "#7b3fb5"]
LINESTYLES = ["-", "--", "-.", ":"]

plt.rcParams.update({
    "figure.dpi": 150,
    "savefig.dpi": 300,
    "font.size": 10,
    "axes.labelsize": 10,
    "axes.titlesize": 10,
    "legend.fontsize": 9,
    "xtick.labelsize": 9,
    "ytick.labelsize": 9,
    "lines.linewidth": 1.4,
    "axes.linewidth": 0.8,
    "legend.framealpha": 0.9,
    "legend.edgecolor": "0.8",
    "axes.grid": False,
    "figure.constrained_layout.use": True,
})


def semilogy_curves(ax, curves, labels, xlabel="Iterations", ylabel="Relative Error Norm",
                    title=None, xmax=None):
    """Plot a family of convergence curves in the paper's visual idiom."""
    from matplotlib.ticker import MaxNLocator
    for i, (y, lab) in enumerate(zip(curves, labels)):
        ax.semilogy(y, color=PALETTE[i % 4], linestyle=LINESTYLES[i % 4], label=lab)
    ax.xaxis.set_major_locator(MaxNLocator(nbins=6))
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    if title:
        ax.set_title(title)
    if xmax is not None:
        ax.set_xlim(0, xmax)
    ax.legend()
    return ax
