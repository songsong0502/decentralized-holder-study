"""R6 -- gradient tracking against the other decentralized first-order methods.

The introduction discusses consensus subgradient methods, EXTRA and the
decentralized proximal/tracking family, but the experiments only ever run
gradient tracking, so the report shows that the method can be applied to the
problem without showing that it is the right choice.  Here the same
shared/private model, the same data, the same weights and the same step are
given to four decentralized schemes:

  DGD     decentralized gradient descent -- the classical fixed-step method,
          which is known to converge only to a neighbourhood;
  EXTRA   the exact first-order correction of Shi et al.;
  P-GT    proximal gradient tracking, the composite scheme of Wang and
          co-authors: the non-smooth penalty is handled by its proximal
          operator rather than by a gradient step;
  GT      gradient tracking (DIGing) -- the method the report uses.

The comparison is run at the operating point of Table 4 and, because the
methods do not all tolerate the same step, over a small step sweep as well.
The single-machine universal and adaptive Holder methods discussed in the
introduction are not decentralized and cannot be run on this problem without
first being given a consensus mechanism, so they are out of scope here; that
is stated in the text rather than papered over.
"""
import time

import numpy as np
import matplotlib.pyplot as plt

from figstyle import PALETTE, LINESTYLES
import medmodel as mm
import medsolvers as ms
import imgmetrics as im
import baseline_solvers as rs
import exp_m1_medical as M1

import os
FIGDIR = os.environ.get("FIGDIR", os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "figures"))

NOISE = 0.06
LAM_Z, LAM_D = 0.1, 0.06
ETA_D, ITERS = 0.30, 4000
ETA_MAIN = 0.15
ETA_SWEEP = [0.25, 0.15, 0.08, 0.04]


def main():
    t0 = time.time()
    truths, lesions, base, masks, alphas = M1.setup()
    a_z = float(np.mean(alphas))
    metric = M1.make_metric(truths)
    ys = mm.acquire(truths, masks, NOISE, np.random.default_rng(M1.SEED_NOISE))

    def run(method, eta, iters=ITERS, keep=False):
        if method == "pgt":
            return rs.decentralized_prox(ys, masks, alphas, LAM_Z, a_z, LAM_D,
                                         eta, iters, metric=metric if keep else None,
                                         eta_d=ETA_D, cons_every=1 if keep else 25)
        return rs.decentralized(ys, masks, alphas, LAM_Z, a_z, LAM_D,
                                rs.const_step(eta), iters,
                                metric=metric if keep else None, eta_d=ETA_D,
                                method=method, cons_every=1 if keep else 25)

    NAMES = [("dgd", "DGD"), ("extra", "EXTRA"), ("pgt", "prox-GT"), ("gt", "GT")]

    print(f"at the operating point (noise {NOISE}, eta={ETA_MAIN}, {ITERS} iterations)\n")
    print(f"{'method':<10}{'NRMSE':>9}{'PSNR (dB)':>11}{'SSIM':>8}"
          f"{'consensus':>12}{'time (s)':>10}")
    curves, cons_curves = {}, {}
    for key, name in NAMES:
        t1 = time.perf_counter()
        h, X, Z, D, cs = run(key, ETA_MAIN, keep=True)
        dt = time.perf_counter() - t1
        n_, p_, s_ = im.report(X, truths, mm.NX)
        curves[name] = h; cons_curves[name] = cs
        print(f"{name:<10}{n_:>9.4f}{p_:>11.2f}{s_:>8.3f}{cs[-1]:>12.2e}{dt:>10.1f}")

    print("\nstep sweep (final NRMSE; 'div' = diverged)\n")
    print(f"{'method':<10}" + "".join(f"{e:>11.2f}" for e in ETA_SWEEP))
    for key, name in NAMES:
        cells = []
        for eta in ETA_SWEEP:
            h, X, Z, D, cs = run(key, eta, iters=2000, keep=True)
            v = h[-1]
            cells.append("div" if not np.isfinite(v) or v > 1e3 else f"{v:.4f}")
        print(f"{name:<10}" + "".join(f"{c:>11}" for c in cells))

    fig, axes = plt.subplots(1, 2, figsize=(8.4, 3.4))
    ax = axes[0]
    for i, (_, name) in enumerate(NAMES):
        ax.semilogy(curves[name], color=PALETTE[i], ls=LINESTYLES[i], lw=1.4,
                    label=name)
    ax.set_xlabel("iterations"); ax.set_ylabel("mean NRMSE")
    ax.set_title(rf"(a) reconstruction error, $\eta={ETA_MAIN}$", fontsize=9)
    ax.legend(fontsize=7)
    ax.set_ylim(0.1, 1.2)

    ax = axes[1]
    for i, (_, name) in enumerate(NAMES):
        ax.semilogy(cons_curves[name], color=PALETTE[i], ls=LINESTYLES[i], lw=1.4,
                    label=name)
    ax.set_xlabel("iterations"); ax.set_ylabel("consensus error")
    ax.set_title("(b) consensus error", fontsize=9)
    ax.legend(fontsize=7)

    fig.savefig(f"{FIGDIR}/fig_r6_baselines.pdf")
    fig.savefig(f"{FIGDIR}/fig_r6_baselines.png")
    plt.close(fig)
    print(f"\n[elapsed {time.time()-t0:.0f} s]")


if __name__ == "__main__":
    main()
