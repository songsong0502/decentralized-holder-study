"""Backward Euler with a globally convergent inner solve.

One backward-Euler step from u^k is the minimiser of the strongly convex
function
    Phi(v) = 1/2 ||v - u^k||^2 + tau J(v),
    J(v)   = 1/2 v'Av + sum_j gamma_j (v_j)_+^{1+alpha_j} - q'v,
whose gradient is G(v) = v - u^k + tau (A v + gamma(1+alpha) v_+^alpha - q).
Plain Newton on G = 0 can cycle near the dead core, where the reaction
derivative is unbounded.  Here each Newton direction (with the derivative
floored at eps for 0 < v < eps and set to zero for v <= 0) is followed by an
Armijo backtracking line search on Phi, which makes every step a descent
step for a strongly convex function; the iteration stops when ||G|| <= tol.
"""
import numpy as np


def phi(prob, v, uk, tau):
    vp = np.maximum(v, 0.0)
    J = (0.5 * v @ (prob.A @ v) + np.sum(prob.gam * vp ** (1.0 + prob.alpha))
         - prob.q @ v)
    return 0.5 * np.sum((v - uk) ** 2) + tau * J


def be_step_ls(prob, uk, tau, eps=1e-12, tol=1e-12, maxit=100):
    v = uk.copy()
    I = np.eye(prob.n)
    it = 0
    while True:
        G = v - uk + tau * (prob.A @ v + prob.react(v) - prob.q)
        gn = float(np.linalg.norm(G))
        if gn <= tol or it >= maxit:
            return v, gn, it
        J = I + tau * (prob.A + np.diag(prob.react_prime(v, floor=eps)))
        d = -np.linalg.solve(J, G)
        f0 = phi(prob, v, uk, tau)
        slope = float(G @ d)
        if slope >= 0:                      # safeguard: fall back to gradient
            d = -G
            slope = -gn * gn
        t = 1.0
        while phi(prob, v + t * d, uk, tau) > f0 + 1e-4 * t * slope and t > 1e-16:
            t *= 0.5
        v = v + t * d
        it += 1


def backward_euler_ls(prob, tau, steps, metric, eps=1e-12, tol=1e-12, u0=None):
    u = np.zeros(prob.n) if u0 is None else u0.copy()
    hist = [metric(u)]
    gmax, its = 0.0, 0
    for _ in range(steps):
        u, gn, k = be_step_ls(prob, u, tau, eps, tol)
        gmax = max(gmax, gn)
        its += k
        hist.append(metric(u))
    return np.array(hist), u, gmax, its / max(steps, 1)
