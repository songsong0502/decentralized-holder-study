"""R1 -- does the consensus floor come from the Holder penalty?

The report observes that the consensus error of gradient tracking stops
falling and settles on a non-zero floor, and attributes that to the
non-Lipschitz shared penalty.  Observing a plateau is not enough to support
that attribution: a fixed step, or an implementation defect, can produce a
plateau on its own.  This script runs the four controls that separate the
possible causes, on exactly the same reconstruction problem:

  (a) exponent control.  The shared penalty exponent is set to a common
      value a for every worker and swept from the measured a = 0.21 up to
      a = 1, where |v|^{1+a} = v^2 is smooth and its gradient IS Lipschitz.
      If the floor is caused by the Holder structure it must disappear at
      a = 1 and grow as a falls.

  (b) step-size law, at a = 1 and at the measured exponent.  A dense grid of
      step sizes (12 values against the 5 of the original table), fitted in
      log-log with standard error, 95% interval and R^2.

  (c) diminishing step.  eta_k = eta_0 (1+k)^{-p}: if the plateau is an
      artefact of the fixed step, a decaying step must drive it to zero at
      the measured exponent too.

  (d) smoothing.  Replacing |v|^{1+a} by (v^2+eps^2)^{(1+a)/2} makes the
      gradient Lipschitz with constant ~ eps^{a-1}.  Sweeping eps
      interpolates continuously between the two regimes.

Verification: with eps = 0, a fixed step and method="gt", baseline_solvers
reproduces medsolvers.decentralized exactly; that identity is checked first.
"""
import time

import numpy as np
import matplotlib.pyplot as plt

from figstyle import PALETTE, LINESTYLES
import medmodel as mm
import medsolvers as ms
import baseline_solvers as rs
import exp_m1_medical as M1

import os
FIGDIR = os.environ.get("FIGDIR", os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "figures"))

NOISE = 0.06
LAM_Z, LAM_D = 0.1, 0.06
ETA_D, ITERS = 0.30, 6000
ETA_MAIN = 0.15

ALPHA_GRID = [1.00, 0.80, 0.60, 0.40, 0.21, 0.10]
ETA_DENSE = [0.28, 0.25, 0.22, 0.20, 0.17, 0.15, 0.13, 0.10, 0.08, 0.06, 0.05, 0.04]
DECAY_POWERS = [0.0, 0.15, 0.30, 0.50]
EPS_GRID = [1e-1, 3e-2, 1e-2, 3e-3, 1e-3, 0.0]


def main():
    t0 = time.time()
    truths, lesions, base, masks, alphas = M1.setup()
    a_meas = float(np.mean(alphas))
    metric = M1.make_metric(truths)
    K = mm.K
    ys = mm.acquire(truths, masks, NOISE, np.random.default_rng(M1.SEED_NOISE))

    # ---- consistency check against the shipped solver -----------------
    h_ref, X_ref, _, _, c_ref = ms.decentralized(
        ys, masks, alphas, LAM_Z, a_meas, LAM_D, ETA_MAIN, 400,
        metric=metric, track_consensus=True, eta_d=ETA_D)
    h_new, X_new, _, _, c_new = rs.decentralized(
        ys, masks, alphas, LAM_Z, a_meas, LAM_D, rs.const_step(ETA_MAIN), 400,
        metric=metric, eta_d=ETA_D)
    print("(0) generalised solver reproduces medsolvers.decentralized: "
          f"max |NRMSE diff| = {np.max(np.abs(h_ref-h_new)):.3e}, "
          f"max |consensus diff| = {np.max(np.abs(c_ref-c_new)):.3e}")

    # ---- (a) exponent control ----------------------------------------
    print("\n(a) common shared exponent a, fixed step "
          f"eta={ETA_MAIN}, {ITERS} iterations")
    floors_a, nrmse_a, curves_a = [], [], {}
    for a in ALPHA_GRID:
        al = [a] * K
        h, X, Z, D, cs = rs.decentralized(ys, masks, al, LAM_Z, a, LAM_D,
                                          rs.const_step(ETA_MAIN), ITERS,
                                          metric=metric, eta_d=ETA_D)
        floors_a.append(cs[-1]); nrmse_a.append(h[-1]); curves_a[a] = cs
        tail = cs[-1] / cs[len(cs) // 2]          # still decaying, or flat?
        print(f"    a={a:.2f}  NRMSE={h[-1]:.4f}  consensus(final)={cs[-1]:.3e}"
              f"  cs(end)/cs(half)={tail:.3f}")

    # ---- (b) step-size law at a=1 and at the measured exponent --------
    print("\n(b) consensus floor against step size (dense grid)")
    fits = {}
    floors_by_a = {}
    for a in (1.00, a_meas):
        al = [a] * K
        fl = []
        for eta in ETA_DENSE:
            h, X, Z, D, cs = rs.decentralized(ys, masks, al, LAM_Z, a, LAM_D,
                                              rs.const_step(eta), ITERS,
                                              metric=None, eta_d=ETA_D,
                                              cons_every=50)
            fl.append(cs[-1])
        floors_by_a[a] = fl
        f = rs.loglog_fit(ETA_DENSE, fl)
        fits[a] = f
        print(f"    a={a:.2f}: exponent {f['slope']:.2f} "
              f"(SE {f['stderr']:.2f}, 95% CI [{f['ci'][0]:.2f}, {f['ci'][1]:.2f}], "
              f"R2={f['r2']:.3f}, n={f['n']})")
        print("       floors: " + ", ".join(f"{e:.2f}:{v:.2e}"
                                            for e, v in zip(ETA_DENSE, fl)))
    print(f"    single-machine Holder reference 1/(1-a) at a={a_meas:.2f} "
          f"is {1/(1-a_meas):.2f}")

    # ---- (c) diminishing step ----------------------------------------
    print("\n(c) diminishing step eta_k = eta_0 (1+k)^-p at the measured exponent")
    decay_curves = {}
    for p in DECAY_POWERS:
        rule = rs.const_step(ETA_MAIN) if p == 0 else rs.decaying_step(ETA_MAIN, p)
        h, X, Z, D, cs = rs.decentralized(ys, masks, alphas, LAM_Z, a_meas,
                                          LAM_D, rule, ITERS, metric=metric,
                                          eta_d=ETA_D)
        decay_curves[p] = cs
        print(f"    p={p:.2f}: NRMSE={h[-1]:.4f}  consensus(final)={cs[-1]:.3e}"
              f"  cs(end)/cs(half)={cs[-1]/cs[len(cs)//2]:.3f}")

    # ---- (d) smoothing -----------------------------------------------
    print("\n(d) smoothed penalty (v^2+eps^2)^{(1+a)/2} at the measured exponent")
    eps_floors = []
    for eps in EPS_GRID:
        h, X, Z, D, cs = rs.decentralized(ys, masks, alphas, LAM_Z, a_meas,
                                          LAM_D, rs.const_step(ETA_MAIN), ITERS,
                                          metric=metric, eta_d=ETA_D,
                                          smooth_eps=eps, cons_every=50)
        eps_floors.append(cs[-1])
        print(f"    eps={eps:.0e}: NRMSE={h[-1]:.4f}  consensus(final)={cs[-1]:.3e}")

    # ---------------- figure ------------------------------------------
    fig, axes = plt.subplots(1, 3, figsize=(11.0, 3.4))

    ax = axes[0]
    for i, a in enumerate([1.00, 0.60, 0.21]):
        ax.loglog(np.arange(1, len(curves_a[a]) + 1), curves_a[a],
                  color=PALETTE[i], ls=LINESTYLES[i], lw=1.5,
                  label=rf"$\alpha={a:.2f}$")
    ax.set_xlabel("iterations")
    ax.set_ylabel(r"consensus error")
    ax.set_title(r"(a) exponent control, $\eta=0.15$", fontsize=9)
    ax.legend(fontsize=6.8, loc="lower left")

    ax = axes[1]
    for i, a in enumerate([1.00, a_meas]):
        lab = "Lipschitz " + rf"$\alpha=1$" if a == 1.0 else rf"measured $\alpha={a:.2f}$"
        ax.loglog(ETA_DENSE, floors_by_a[a], marker="o", ms=4, ls="none",
                  color=PALETTE[i], label=lab)
        f = fits[a]
        xs = np.array(ETA_DENSE)
        ax.loglog(xs, np.exp(f["intercept"]) * xs ** f["slope"],
                  color=PALETTE[i], ls=LINESTYLES[i + 1], lw=1.2,
                  label=rf"fit $\propto\eta^{{{f['slope']:.2f}}}$")
    ax.set_xlabel(r"step size $\eta$")
    ax.set_ylabel("consensus floor")
    ax.set_title("(b) floor vs step size", fontsize=9)
    ax.legend(fontsize=6.2, loc="lower right")

    ax = axes[2]
    for i, p in enumerate(DECAY_POWERS):
        lab = "fixed step" if p == 0 else rf"$p={p:.2f}$"
        ax.loglog(np.arange(1, len(decay_curves[p]) + 1), decay_curves[p],
                  color=PALETTE[i % 4], ls=LINESTYLES[i % 4], lw=1.4, label=lab)
    ax.set_xlabel("iterations")
    ax.set_ylabel("consensus error")
    ax.set_title(r"(c) diminishing step $\eta_k=\eta_0(1+k)^{-p}$", fontsize=9)
    ax.legend(fontsize=6.5, loc="lower left")

    fig.savefig(f"{FIGDIR}/fig_r1_control.pdf")
    fig.savefig(f"{FIGDIR}/fig_r1_control.png")
    plt.close(fig)
    print(f"\n[elapsed {time.time()-t0:.0f} s]")


if __name__ == "__main__":
    main()
