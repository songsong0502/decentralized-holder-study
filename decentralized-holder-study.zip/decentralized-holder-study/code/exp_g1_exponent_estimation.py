"""G1 -- checks of the two exponent estimators of Section 2.3.

(a) Reaction order.  A synthetic kinetics experiment (initial rate at a dozen
    reactant concentrations, 8% multiplicative noise) is fitted by the
    log-log slope, for true orders 0.50 and 0.20, with a Monte-Carlo check of
    bias and interval coverage.  The PDE runs of the paper use the planted
    orders; Section 3.1.2 repeats them with the estimate 0.491.

(b) Effective shape index.  The moment-ratio estimator of the generalized
    Gaussian shape is checked on samples of known shape, and its value is
    shown as a function of the sparsity of a synthetic tissue model.

(c) A check of (b) on the earlier tissue model of tissue.py.  These values
    are not used in the paper; the indices of the phantom slices quoted in
    Section 2.3 are printed by exp_m1_medical.py.
"""
import numpy as np
import matplotlib.pyplot as plt

from figstyle import PALETTE, LINESTYLES
from exponents import fit_reaction_order, ggd_tail_index, ggd_sample
import tissue

FIGDIR = __import__("os").environ.get("FIGDIR", __import__("os").path.join(__import__("os").path.dirname(__import__("os").path.abspath(__file__)), "..", "figures"))

MEDIA = [("half-order catalyst", 0.50, 1.4),
         ("strongly adsorbing medium", 0.20, 0.9)]
RATE_NOISE = 0.08          # 8% relative error on each rate reading
VALIDATE_BETAS = [0.3, 0.5, 0.8, 1.2, 1.6, 2.0]


# ----------------------------------------------------------------------
def panel_kinetics(ax, rng):
    print("(a) PDE reaction order, fitted from a synthetic kinetics experiment:")
    u = np.logspace(-2, 0, 12)
    for i, (name, alpha_true, k_true) in enumerate(MEDIA):
        r = k_true * u ** alpha_true
        r_obs = r * np.exp(RATE_NOISE * rng.standard_normal(u.size))
        a_hat, k_hat, se = fit_reaction_order(u, r_obs)
        reps = np.array([fit_reaction_order(
            u, r * np.exp(RATE_NOISE * rng.standard_normal(u.size)))[0]
            for _ in range(400)])
        cover = float(np.mean(np.abs(reps - alpha_true) <= 1.96 * se))
        print(f"    {name:26s} true={alpha_true:.2f}  fitted={a_hat:.3f}+/-{se:.3f}"
              f"  MC mean={reps.mean():.3f} sd={reps.std():.3f}  95% cover={cover:.2f}")
        ax.loglog(u, r_obs, "o", ms=4, color=PALETTE[i], alpha=0.85)
        ax.loglog(u, k_hat * u ** a_hat, color=PALETTE[i], ls=LINESTYLES[i],
                  label=rf"{name}: $\hat\alpha={a_hat:.2f}\pm{se:.2f}$")
    ax.set_xlabel(r"reactant concentration $u$")
    ax.set_ylabel(r"initial rate $r$")
    ax.set_title(r"(a) reaction order $=$ slope of $\log r$ vs $\log u$", fontsize=9)
    ax.legend(fontsize=7)


# ----------------------------------------------------------------------
def panel_tailindex(ax, rng):
    print("(b) tail-index estimator: validation, then sparsity dependence:")
    for b in VALIDATE_BETAS:
        est = [ggd_tail_index(ggd_sample(b, 4000, rng)) for _ in range(25)]
        print(f"    known shape {b:.2f} -> fitted {np.mean(est):.3f} "
              f"+/- {np.std(est):.3f}")
    ks = np.array([4, 8, 16, 32, 64, 120])
    n = 256
    means, sds = [], []
    for k in ks:
        est = []
        for _ in range(60):
            x = np.zeros(n)
            idx = rng.choice(n, k, replace=False)
            x[idx] = (0.6 + 0.8 * rng.random(k)) * rng.choice([-1.0, 1.0], k)
            est.append(ggd_tail_index(x))
        means.append(np.mean(est)); sds.append(np.std(est))
        print(f"    {k:3d} active of {n} -> measured alpha = {means[-1]:.3f}"
              f" +/- {sds[-1]:.3f}")
    means, sds = np.array(means), np.array(sds)
    ax.errorbar(ks, means, yerr=sds, marker="o", ms=4, capsize=2,
                color=PALETTE[0], ls=LINESTYLES[0])
    ax.set_xscale("log")
    ax.set_xlabel("active sources per slice (tissue density)")
    ax.set_ylabel(r"measured tail index $\hat\alpha$")
    ax.set_title("(b) sparser tissue $\\Rightarrow$ smaller exponent", fontsize=9)


# ----------------------------------------------------------------------
def panel_slices(ax, rng):
    print("(c) per-slice exponents measured from independent prior scans:")
    alphas, labels = [], []
    for i in range(tissue.K):
        est = [ggd_tail_index(tissue.prior_scan(i, rng)) for _ in range(40)]
        a = float(np.mean(est))
        alphas.append(a); labels.append(f"slice {i}")
        print(f"    slice {i}: {tissue.n_sources(i):3d} sources -> "
              f"alpha_hat = {a:.3f} +/- {np.std(est):.3f}  (p = {1+a:.2f})")
    ax.bar(range(tissue.K), [1 + a for a in alphas],
           color=[PALETTE[i % 4] for i in range(tissue.K)])
    for i, a in enumerate(alphas):
        ax.text(i, 1 + a + 0.012, f"{1+a:.2f}", ha="center", fontsize=8)
    ax.set_xticks(range(tissue.K)); ax.set_xticklabels(labels, fontsize=8)
    ax.set_ylim(1.0, max(1 + a for a in alphas) + 0.10)
    ax.set_ylabel(r"bridge exponent $p_i=1+\hat\alpha_i$")
    ax.set_title("(c) exponents used by D3", fontsize=9)
    return alphas


def main():
    rng = np.random.default_rng(11)
    fig, axes = plt.subplots(1, 3, figsize=(11.6, 3.3))
    panel_kinetics(axes[0], rng)
    panel_tailindex(axes[1], rng)
    alphas = panel_slices(axes[2], rng)
    print(f"  => indices of the earlier tissue model (not used in the paper) = {[round(a,3) for a in alphas]}")
    fig.savefig(f"{FIGDIR}/fig_g1_exponents.pdf")
    fig.savefig(f"{FIGDIR}/fig_g1_exponents.png")
    plt.close(fig)


if __name__ == "__main__":
    main()
