"""P3 -- is the backward-Euler result an artefact of its nonlinear solver?

Backward Euler at tau = 1 solves at every time step
    G(v) = v + tau (A v + gamma(1+alpha) v_+^alpha - q) - u^k = 0
by Newton.  The reaction derivative gamma(1+alpha) alpha v^(alpha-1) is
unbounded as v -> 0+, so it is evaluated at max(v, eps) for v > 0 (and is
zero for v <= 0, where the positive-part reaction is identically zero).
We vary the number of Newton iterations per step (3, 5, 10, 20, and
"until ||G|| <= 1e-12 or 50 iterations") and the floor eps (1e-12, 1e-8,
1e-4, 1e-2), and record the final field error, the dead-core error, and the
Newton residual ||G|| at the end of the last time step and its maximum over
all time steps.  2000 time steps throughout.
"""
import os

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")

import json
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import models_dec as md, pdesolvers as ps, pde_extra as pe

RES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "results")


def be(prob, tau, steps, newton, eps, tol=None):
    n = prob.n
    u = np.zeros(n); I = np.eye(n)
    gmax, glast, nits = 0.0, 0.0, 0
    for _ in range(steps):
        uk = u.copy(); v = u.copy()
        k = 0
        while True:
            Gv = v + tau * (prob.A @ v + prob.react(v) - prob.q) - uk
            gn = float(np.linalg.norm(Gv))
            if (tol is not None and gn <= tol) or k >= newton:
                break
            J = I + tau * (prob.A + np.diag(prob.react_prime(v, floor=eps)))
            v = v - np.linalg.solve(J, Gv)
            k += 1
        nits += k
        u = v
        glast = gn
        gmax = max(gmax, gn)
    return u, glast, gmax, nits / steps


def main():
    nodes, x0, xs, owner = md.make_pde(N=12, m=4, alphas=[0.5] * 4)
    prob = ps.SteadyRD(nodes, owner)
    den = np.linalg.norm(xs); core = xs == 0.0
    out = []
    configs = [(3, 1e-12, None), (5, 1e-12, None), (10, 1e-12, None),
               (20, 1e-12, None), (50, 1e-12, 1e-12),
               (3, 1e-8, None), (3, 1e-4, None), (3, 1e-2, None),
               (50, 1e-8, 1e-12), (50, 1e-4, 1e-12), (50, 1e-2, 1e-12)]
    print(f"{'newton':>8}{'floor':>8}{'final':>11}{'core':>11}{'|G| last':>11}"
          f"{'|G| max':>11}{'avg it':>8}")
    for newton, eps, tol in configs:
        u, gl, gm, avg = be(prob, 1.0, 2000, newton, eps, tol)
        fin = float(np.linalg.norm(u - xs) / den)
        ce = float(np.linalg.norm(u[core] - xs[core]) / den)
        lab = f"{newton}" if tol is None else f"<=1e-12"
        out.append(dict(newton=lab, floor=eps, final=fin, core=ce, G_last=gl,
                        G_max=gm, avg_newton=avg))
        print(f"{lab:>8}{eps:>8.0e}{fin:>11.3e}{ce:>11.3e}{gl:>11.2e}{gm:>11.2e}{avg:>8.1f}",
              flush=True)
    # globally convergent inner solve (Newton + Armijo line search on the
    # strongly convex step function), 200 time steps, tolerance 1e-10
    met = lambda u: float(np.linalg.norm(u - xs) / den)
    for eps in (1e-12, 1e-8, 1e-4, 1e-2):
        for tau in (1.0, 10.0):
            h, u, gm, avg = pe.backward_euler_ls(prob, tau, 200, met, eps=eps, tol=1e-10)
            fin = float(h[-1]); ce = float(np.linalg.norm(u[core] - xs[core]) / den)
            it3 = int(np.argmax(np.asarray(h) <= 1e-3)) if (np.asarray(h) <= 1e-3).any() else None
            out.append(dict(newton="line search", floor=eps, tau=tau, final=fin, core=ce,
                            G_max=gm, avg_newton=avg, it3=it3, umin=float(u.min())))
            print(f"{'LS':>8}{eps:>8.0e} tau={tau:<5}{fin:>11.3e}{ce:>11.3e}{gm:>11.2e}"
                  f"{avg:>8.1f} it3={it3}", flush=True)
    with open(os.path.join(RES, "p3_newton.json"), "w") as fh:
        json.dump(out, fh, indent=1)


if __name__ == "__main__":
    main()
