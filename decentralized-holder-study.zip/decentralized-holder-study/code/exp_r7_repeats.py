"""R7 -- repeat the imaging comparison over many random instances.

Table 4 is a single planted instance: one phantom, one set of masks, one
noise realisation.  Some of the differences it reports are small -- the
0.04 dB between the centralized and the decentralized solution most of all --
and a single draw cannot say whether they are real.  Here the whole pipeline
is repeated over independent instances, resampling

    the phantom (lesion positions and sizes),
    the k-space masks, one per slice,
    the measurement noise,

and we report the mean, the sample standard deviation and a 95% confidence
interval for each method, plus the PAIRED difference between the centralized
and decentralized runs, which is the quantity the 0.04 dB claim is about.
Pairing matters: both methods see the same instance, so the difference has
far less spread than either measurement on its own.

Weights are fixed at the values tuned at the operating point of Table 4 and
are NOT retuned per instance -- retuning on the true image at every draw
would be oracle tuning repeated 25 times.  That choice is reported.
"""
import time

import numpy as np
from scipy import stats

import medmodel as mm
import medsolvers as ms
import imgmetrics as im
import baseline_solvers as rs
import exp_m1_medical as M1

REPS = 25
NOISE = 0.06
LAM_P, LAM_Z, LAM_D = 0.05, 0.1, 0.06        # tuned once, at the operating point
ETA_Z, ETA_D, ITERS = 0.15, 0.30, 4000


def main():
    t0 = time.time()
    alphas = mm.measure_alphas(np.random.default_rng(M1.SEED_ALPHA))
    a_z = float(np.mean(alphas))
    rec = {k: [] for k in ("ni", "nc", "nd", "pi", "pc", "pd", "si", "sc", "sd")}

    for r in range(REPS):
        truths, lesions, base = mm.build_slices(np.random.default_rng(100 + r))
        masks = mm.slice_masks(np.random.default_rng(200 + r))
        ys = mm.acquire(truths, masks, NOISE, np.random.default_rng(300 + r))
        metric = M1.make_metric(truths)

        _, X_i = ms.independent(ys, masks, alphas, 1e-4, LAM_P, ETA_Z, ITERS)
        _, X_c, _, _ = ms.centralized(ys, masks, alphas, LAM_Z, a_z, LAM_D,
                                      ETA_Z, ITERS)
        _, X_d, _, _, _ = ms.decentralized(ys, masks, alphas, LAM_Z, a_z, LAM_D,
                                           ETA_Z, ITERS, eta_d=ETA_D)
        for tag, X in (("i", X_i), ("c", X_c), ("d", X_d)):
            n_, p_, s_ = im.report(X, truths, mm.NX)
            rec["n" + tag].append(n_); rec["p" + tag].append(p_)
            rec["s" + tag].append(s_)
        print(f"  instance {r+1:2d}/{REPS}: "
              f"ind {rec['pi'][-1]:.2f}  cen {rec['pc'][-1]:.2f}  "
              f"dec {rec['pd'][-1]:.2f} dB", flush=True)

    print(f"\n{REPS} independent instances (phantom, masks and noise all resampled)")
    print(f"{'method':<16}{'NRMSE':>26}{'PSNR (dB)':>26}{'SSIM':>26}")
    for tag, name in (("i", "independent"), ("c", "centralized"),
                      ("d", "decentralized")):
        cells = []
        for m in ("n", "p", "s"):
            s = rs.mean_ci(rec[m + tag])
            cells.append(f"{s['mean']:.4f} +- {s['sd']:.4f} "
                         f"[{s['ci'][0]:.4f},{s['ci'][1]:.4f}]")
        print(f"{name:<16}" + "".join(f"{c:>26}" for c in cells))

    print("\npaired differences (same instance, so the pairing removes "
          "instance-to-instance spread)")
    for m, lab, unit in (("p", "PSNR", " dB"), ("n", "NRMSE", ""),
                         ("s", "SSIM", "")):
        d_cd = np.array(rec[m + "c"]) - np.array(rec[m + "d"])
        s = rs.mean_ci(d_cd)
        t = stats.ttest_rel(rec[m + "c"], rec[m + "d"])
        print(f"  centralized - decentralized, {lab:<6}: "
              f"{s['mean']:+.4f}{unit} +- {s['sd']:.4f}, 95% CI "
              f"[{s['ci'][0]:+.4f}, {s['ci'][1]:+.4f}], paired p = {t.pvalue:.2g}")
    for m, lab, unit in (("p", "PSNR", " dB"), ("n", "NRMSE", "")):
        d_id = np.array(rec[m + "d"]) - np.array(rec[m + "i"])
        s = rs.mean_ci(d_id)
        t = stats.ttest_rel(rec[m + "d"], rec[m + "i"])
        print(f"  decentralized - independent, {lab:<6}: "
              f"{s['mean']:+.4f}{unit} +- {s['sd']:.4f}, 95% CI "
              f"[{s['ci'][0]:+.4f}, {s['ci'][1]:+.4f}], paired p = {t.pvalue:.2g}")
    g = np.array(rec["ni"]) / np.array(rec["nd"])
    s = rs.mean_ci(g)
    print(f"  NRMSE gain independent/decentralized: {s['mean']:.3f} "
          f"+- {s['sd']:.3f}, 95% CI [{s['ci'][0]:.3f}, {s['ci'][1]:.3f}]")
    print(f"\n[elapsed {time.time()-t0:.0f} s]")


if __name__ == "__main__":
    main()
