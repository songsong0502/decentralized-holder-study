"""The four medical slices: one tissue model per slice, shared anatomy.

Slices of one volume are NOT copies and NOT unrelated.  Each slice here is

    (shared anatomy)  +  (slice-specific lesions)

The shared anatomy occupies the SAME locations in every slice with only a
small amplitude jitter -- adjacent CT/MRI slices really are nearly
identical in their bulk structure, and that is what makes joint
reconstruction across the stack worth attempting.  On top of it each slice
carries its own focal lesions: distinct LOCATIONS, and a distinct NUMBER,
at an amplitude COMPARABLE to the anatomy so they are clearly visible
rather than buried.  Those lesions are what make the four slices genuinely
different images, and their differing count is what gives each slice its
own measurable tail index (exponents.ggd_tail_index): the slice with fewer
active sources measures a smaller exponent.

An earlier version of this model kept the private detail at ~10% of the
anatomy's amplitude.  It produced a healthy-looking joint-reconstruction
gain, but the four slices were then visually indistinguishable (the private
part carried under 3% of the image energy) -- the gain was an artifact of
the slices being nearly the same picture.  The amplitudes below are chosen
so the slices differ visibly; Section 5.6 of the report then measures the
joint-vs-independent comparison honestly, including the regime where
coupling HURTS.

`prior_scan` draws an independent realisation of a slice's tissue model.
It stands for a previous scan acquired under the same protocol, and it is
what the exponent is estimated from -- never the unknown image itself.
"""
import numpy as np

NX = 16
N = NX * NX
K = 4

N_SHARED = 14                      # anatomy common to every slice
N_PRIVATE = [5, 11, 19, 31]        # slice-specific lesions: sparse -> dense

# lesions are as bright as the anatomy, so the slices differ VISIBLY
PRIV_LO, PRIV_HI = 0.7, 1.3


def n_sources(i):
    return N_SHARED + N_PRIVATE[i]


def prior_scan(i, rng):
    """An independent realisation of slice i's tissue statistics."""
    x = np.zeros(N)
    idx = rng.choice(N, n_sources(i), replace=False)
    x[idx] = (0.6 + 0.8 * rng.random(idx.size)) * rng.choice([-1.0, 1.0], idx.size)
    return x


def build_slices(rng):
    """The K ground-truth slices actually reconstructed in D3.

    Returns (truths, shared_idx) so callers can quantify how much of each
    slice is shared and how much is its own.
    """
    shared_idx = rng.choice(N, N_SHARED, replace=False)
    shared_amp = 0.9 + rng.random(N_SHARED)
    used = set(shared_idx.tolist())
    truths = []
    for i in range(K):
        x = np.zeros(N)
        # shared anatomy: same locations every slice, +-5% amplitude jitter
        x[shared_idx] = shared_amp * (1.0 + 0.05 * rng.standard_normal(N_SHARED))
        # slice-specific lesions: distinct locations, fully visible amplitude
        pool = np.array([k for k in range(N) if k not in used])
        uidx = rng.choice(pool, N_PRIVATE[i], replace=False)
        x[uidx] = PRIV_LO + (PRIV_HI - PRIV_LO) * rng.random(N_PRIVATE[i])
        used.update(uidx.tolist())
        truths.append(x)
    return np.array(truths), shared_idx


def distinctness(truths, shared_idx):
    """How different are the slices?  Returns (mean private energy share,
    mean pairwise relative difference)."""
    sh = np.zeros(N, bool); sh[shared_idx] = True
    pe = float(np.mean([(t[(t != 0) & ~sh] ** 2).sum() / (t ** 2).sum()
                        for t in truths]))
    pd = float(np.mean([np.linalg.norm(truths[i] - truths[j]) / np.linalg.norm(truths[i])
                        for i in range(K) for j in range(i + 1, K)]))
    return pe, pd
