"""C4 -- how the imaging results depend on the exponent.

Every exponent of the model (the four private exponents and the shared one)
is replaced by a common value a in {0.1, 0.4, 0.6, 0.8, 1.0}; the measured
vector is run as well.  Two weight settings: the fixed operating-point
weights, and weights re-selected for each a on a 3 x 3 grid (3 values for the
independent baseline) against the ground truth (oracle).  Reported: NRMSE of
the independent, centralized and decentralized reconstructions, the gain from
sharing, and the consensus floor (tail median).  Also: the shape index of the
shared anatomy itself, estimated directly, against the mean of the per-slice
estimates that the paper uses for a_z.
"""
import os

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")

import json
import sys
from multiprocessing import Pool

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import medmodel as mm
import medsolvers as ms
import ctrl_solver as cs
import exponents as ex
import exp_m1_medical as M1

RES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "results")
NOISE, ITERS, TUNE_IT = 0.06, 4000, 1500
ETA, ETA_D = 0.15, 0.30
LP = [0.02, 0.05, 0.1]
LZ = [0.05, 0.1, 0.2]
LD = [0.03, 0.06, 0.12]


def nrmse(X, T):
    return float(np.linalg.norm(X - T) / np.linalg.norm(T))


def job(a):
    truths, lesions, base, masks, alphas_m = M1.setup()
    ys = mm.acquire(truths, masks, NOISE, np.random.default_rng(M1.SEED_NOISE))
    if a == "measured":
        alphas, a_z = alphas_m, float(np.mean(alphas_m))
    else:
        alphas, a_z = [a] * len(alphas_m), a
    out = dict(a=a)
    for setting in ("fixed", "retuned"):
        if setting == "fixed":
            lp, lz, ld = 0.05, 0.1, 0.06
        else:
            lp = min((nrmse(ms.independent(ys, masks, alphas, 1e-4, p, ETA, TUNE_IT)[1],
                            truths), p) for p in LP)[1]
            best = min((nrmse(ms.decentralized(ys, masks, alphas, z, a_z, d, ETA, TUNE_IT,
                                               eta_d=ETA_D)[1], truths), z, d)
                       for z in LZ for d in LD)
            lz, ld = best[1], best[2]
        Xi = ms.independent(ys, masks, alphas, 1e-4, lp, ETA, ITERS)[1]
        Xc = ms.centralized(ys, masks, alphas, lz, a_z, ld, ETA, ITERS)[1]
        Xd, _, _, cons = cs.run(ys, masks, alphas, lz, a_z, ld, ETA, ETA_D, ITERS)
        out[setting] = dict(weights=(lp, lz, ld), ind=nrmse(Xi, truths),
                            cen=nrmse(Xc, truths), dec=nrmse(Xd, truths),
                            floor=cs.floor_stats(cons)["median"])
        out[setting]["gain"] = out[setting]["ind"] / out[setting]["dec"]
        print(a, setting, out[setting], flush=True)
    return out


def main():
    _, _, base, _, alphas_m = M1.setup()
    anat = ex.ggd_tail_index(base.ravel())
    print("shape index of the shared anatomy", anat, "mean of slice estimates",
          float(np.mean(alphas_m)))
    with Pool(2) as pool:
        res = pool.map(job, ["measured", 0.1, 0.4, 0.6, 0.8, 1.0], chunksize=1)
    with open(os.path.join(RES, "c4_exponent.json"), "w") as fh:
        json.dump(dict(runs=res, anatomy_shape=anat,
                       slice_mean=float(np.mean(alphas_m))), fh, indent=1)


if __name__ == "__main__":
    main()
