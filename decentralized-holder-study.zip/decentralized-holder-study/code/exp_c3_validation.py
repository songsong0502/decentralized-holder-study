"""C3 -- regularisation weights chosen without the ground truth.

Each worker holds out a random 10% of its own sampled k-space entries.  For
every candidate weight the method is run on the remaining 90% (2000
iterations), and the candidate with the smallest held-out misfit
sum_i ||M_val,i (F u_i) - y_val,i||^2 is kept.  The misfit is computed by each
worker from its own data and the K numbers are added, so the selection itself
needs only a scalar sum across workers.  The selected weights are then used
on the full data (4000 iterations).  For reference the same grid is also
searched with the ground truth (oracle, 2000 iterations), and the fixed
operating-point weights are run as well.

Instances: the operating point and four further instances at noise 0.06, and
the operating point at noise 0.02 and 0.12.
"""
import os

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")

import json
import sys
from multiprocessing import Pool

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import medmodel as mm
import medsolvers as ms
import imgmetrics as im
import exp_m1_medical as M1

RES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "results")
ETA, ETA_D = 0.15, 0.30
SEL_IT, FIN_IT = 2000, 4000
LP = [0.02, 0.05, 0.1, 0.2]
LZ = [0.05, 0.1, 0.2]
LD = [0.03, 0.06, 0.12]
FIXED = (0.05, 0.1, 0.06)


def instance(r, noise):
    alphas = mm.measure_alphas(np.random.default_rng(M1.SEED_ALPHA))
    if r is None:
        truths, _, _, masks, _ = M1.setup()
        ys = mm.acquire(truths, masks, noise, np.random.default_rng(M1.SEED_NOISE))
    else:
        truths, _, _ = mm.build_slices(np.random.default_rng(100 + r))
        masks = mm.slice_masks(np.random.default_rng(200 + r))
        ys = mm.acquire(truths, masks, noise, np.random.default_rng(300 + r))
    return truths, masks, alphas, ys


def split(masks, rng, frac=0.1):
    tr, va = [], []
    for m in masks:
        v = m & (rng.random(m.shape) < frac)
        tr.append(m & ~v); va.append(v)
    return np.array(tr), np.array(va)


def misfit(X, ys, va):
    return float(sum(np.sum(np.abs(mm.fwd(X[i], va[i]) - ys[i] * va[i]) ** 2)
                     for i in range(len(ys))))


def nrmse(X, truths):
    return float(np.linalg.norm(X - truths) / np.linalg.norm(truths))


def job(spec):
    r, noise = spec
    truths, masks, alphas, ys = instance(r, noise)
    a_z = float(np.mean(alphas))
    tr, va = split(masks, np.random.default_rng(500 + (0 if r is None else r)))
    ytr = ys * tr
    out = dict(r=r, noise=noise)
    # independent: validation and oracle
    vi = [(misfit(ms.independent(ytr, tr, alphas, 1e-4, lp, ETA, SEL_IT)[1], ys, va), lp)
          for lp in LP]
    oi = [(nrmse(ms.independent(ys, masks, alphas, 1e-4, lp, ETA, SEL_IT)[1], truths), lp)
          for lp in LP]
    lp_v, lp_o = min(vi)[1], min(oi)[1]
    vd, od = [], []
    for lz in LZ:
        for ld in LD:
            X = ms.decentralized(ytr, tr, alphas, lz, a_z, ld, ETA, SEL_IT, eta_d=ETA_D)[1]
            vd.append((misfit(X, ys, va), lz, ld))
            X = ms.decentralized(ys, masks, alphas, lz, a_z, ld, ETA, SEL_IT, eta_d=ETA_D)[1]
            od.append((nrmse(X, truths), lz, ld))
    _, lz_v, ld_v = min(vd); _, lz_o, ld_o = min(od)
    out["selected"] = dict(validation=(lp_v, lz_v, ld_v), oracle=(lp_o, lz_o, ld_o),
                           fixed=FIXED)
    for name, (lp, lz, ld) in out["selected"].items():
        Xi = ms.independent(ys, masks, alphas, 1e-4, lp, ETA, FIN_IT)[1]
        Xc = ms.centralized(ys, masks, alphas, lz, a_z, ld, ETA, FIN_IT)[1]
        Xd = ms.decentralized(ys, masks, alphas, lz, a_z, ld, ETA, FIN_IT, eta_d=ETA_D)[1]
        rec = {}
        for tag, X in (("ind", Xi), ("cen", Xc), ("dec", Xd)):
            n_, p_, s_ = im.report(X, truths, mm.NX)
            rec[tag] = dict(nrmse=n_, psnr=p_, ssim=s_)
        out[name] = rec
        print(r, noise, name, (lp, lz, ld), f"ind {rec['ind']['psnr']:.2f} "
              f"cen {rec['cen']['psnr']:.2f} dec {rec['dec']['psnr']:.2f}", flush=True)
    return out


def main():
    specs = [(None, 0.06), (0, 0.06), (1, 0.06), (2, 0.06), (3, 0.06),
             (None, 0.02), (None, 0.12)]
    with Pool(2) as pool:
        res = pool.map(job, specs, chunksize=1)
    with open(os.path.join(RES, "c3_validation.json"), "w") as fh:
        json.dump(res, fh, indent=1)


if __name__ == "__main__":
    main()
