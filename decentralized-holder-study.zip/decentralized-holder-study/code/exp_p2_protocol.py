"""P2 -- the PDE comparison under step-size protocols that do not trade
accuracy for speed, plus the quantities the review asks to be reported.

For each method a sweep of step sizes is run to a fixed horizon (20000
iterations for forward Euler, IMEX and gradient tracking; 2000 time steps for
backward Euler).  For every run we record
    final error       relative field error of the LAST iterate at the horizon
    dead-core error   the same restricted to the 8 nodes with u* = 0
    residual          ||grad J(u)|| / ||q||  at the last iterate
    min u             smallest entry of any iterate (negative values allowed,
                      since the positive-part extension is part of the model)
    it to 1e-3, 1e-4  first iteration below these errors
    stable            finite and below the initial error at the horizon
From the sweeps we read off (i) the step that is fastest to 1e-3, (ii) the
step that gives the smallest final error, and (iii) the error-against-
iteration Pareto front of each method.

Also: (iv) the main comparison repeated with the ESTIMATED reaction order
0.491 instead of the planted 0.5; (v) the nonlinear explicit stability range
of forward Euler on a fine grid of steps.
"""
import os

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")

import json
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import graphs, decentralized as dec, models_dec as md, pdesolvers as ps, pde_extra as pe

RES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "results")
H = 20000
HB = 2000
HBL = 200


def first_below(h, tol):
    idx = np.nonzero(np.asarray(h) <= tol)[0]
    return int(idx[0]) if idx.size else None


def run_classical(kind, prob, tau, xs, core, den, iters):
    met = lambda u: float(np.linalg.norm(u - xs) / den)
    u = np.zeros(prob.n)
    hist = [met(u)]
    umin = 0.0
    if kind == "imex":
        M = np.linalg.inv(np.eye(prob.n) + tau * prob.A)
    with np.errstate(over="ignore", invalid="ignore"):
        for _ in range(iters):
            if kind == "fe":
                u = u - tau * prob.residual(u)
            elif kind == "imex":
                u = M @ (u - tau * (prob.react(u) - prob.q))
            elif kind == "be":
                _, u = ps.backward_euler(prob, tau, 1, met, u0=u)
            else:
                u, _, _ = pe.be_step_ls(prob, u, tau, tol=1e-10)
            if not np.all(np.isfinite(u)):
                hist.append(np.inf)
                break
            umin = min(umin, float(u.min()))
            hist.append(met(u))
    return summarise(hist, u, prob, xs, core, den, umin)


def summarise(hist, u, prob, xs, core, den, umin):
    h = np.asarray(hist)
    ok = bool(np.isfinite(h[-1]) and h[-1] < h[0])
    res = float(np.linalg.norm(prob.residual(u)) / np.linalg.norm(prob.q)) if ok else None
    tail = h[-max(1, (len(h) - 1) // 10):]
    return dict(final=float(h[-1]) if ok else None,
                tail_median=float(np.median(tail)) if ok else None,
                tail_lo=float(tail.min()) if ok else None,
                tail_hi=float(tail.max()) if ok else None,
                core=float(np.linalg.norm(u[core] - xs[core]) / den) if ok else None,
                residual=res, umin=umin, it3=first_below(h, 1e-3),
                it4=first_below(h, 1e-4), stable=ok, hist=h)


def run_gt(nodes, prob, eta, xs, core, den, iters):
    W = graphs.metropolis(graphs.ring(len(nodes)))
    m = len(nodes)
    X = np.tile(np.zeros(prob.n), (m, 1))
    G = dec.grad_all(nodes, X); S = G.copy()
    hist = [1.0]
    umin = 0.0
    with np.errstate(over="ignore", invalid="ignore"):
        for _ in range(iters):
            X = W @ X - eta * S
            Gn = dec.grad_all(nodes, X)
            S = W @ S + Gn - G
            G = Gn
            if not np.all(np.isfinite(X)):
                hist.append(np.inf)
                break
            umin = min(umin, float(X.min()))
            hist.append(float(np.linalg.norm(X.mean(0) - xs) / den))
    out = summarise(hist, X.mean(0), prob, xs, core, den, umin)
    xb = X.mean(0)
    out["consensus"] = float(np.max(np.linalg.norm(X - xb, axis=1)) / np.linalg.norm(xb)) \
        if out["stable"] else None
    return out


SWEEPS = dict(
    fe=[0.01, 0.02, 0.04, 0.06, 0.08, 0.10, 0.12, 0.14, 0.16, 0.18, 0.20, 0.22, 0.24],
    imex=[0.05, 0.1, 0.2, 0.3, 0.5, 1.0, 2.0, 5.0],
    be=[0.1, 0.3, 1.0, 3.0, 10.0],
    bels=[0.1, 0.3, 1.0, 3.0, 10.0],
    gt=[0.005, 0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08],
)


def sweep(alpha):
    nodes, x0, xs, owner = md.make_pde(N=12, m=4, alphas=[alpha] * 4)
    prob = ps.SteadyRD(nodes, owner)
    den = np.linalg.norm(xs)
    core = xs == 0.0
    res = {}
    for kind, steps in SWEEPS.items():
        res[kind] = []
        for t in steps:
            if kind == "gt":
                r = run_gt(nodes, prob, t, xs, core, den, H)
            else:
                r = run_classical(kind, prob, t, xs, core, den,
                                  HB if kind == "be" else (HBL if kind == "bels" else H))
            h = r.pop("hist")
            r["step"] = t
            # thinned curve for the Pareto figure
            idx = np.unique(np.round(np.logspace(0, np.log10(len(h) - 1), 300)).astype(int))
            r["curve_it"] = idx.tolist()
            r["curve_err"] = [float(h[i]) for i in idx]
            res[kind].append(r)
            print(alpha, kind, t, r["stable"], r["final"], r["it3"], r["it4"],
                  r["umin"], flush=True)
    return res, prob


def stability_fine(prob_alpha=0.5):
    nodes, x0, xs, owner = md.make_pde(N=12, m=4, alphas=[prob_alpha] * 4)
    prob = ps.SteadyRD(nodes, owner)
    den = np.linalg.norm(xs); core = xs == 0.0
    out = []
    for t in np.round(np.arange(0.20, 0.2601, 0.005), 3):
        r = run_classical("fe", prob, float(t), xs, core, den, H)
        r.pop("hist")
        out.append(dict(step=float(t), stable=r["stable"], final=r["final"]))
    return out, float(prob.stable_step())


def main():
    out = {}
    out["alpha0.5"], prob = sweep(0.5)
    out["alpha_est0.491"], _ = sweep(0.491)
    out["fe_stability_fine"], out["linear_threshold"] = stability_fine()
    out["dead_core_nodes"] = 8
    with open(os.path.join(RES, "p2_protocol.json"), "w") as fh:
        json.dump(out, fh, indent=1)


if __name__ == "__main__":
    main()
