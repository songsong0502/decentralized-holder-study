"""Figures 1, 4, 5 and 6 of the revised manuscript, from results/*.json.

Figure 1  PDE comparison under step sweeps      (p2_protocol.json)
Figure 4  gain from sharing under mismatch       (exp_r5_mismatch.log, c2_mismatch.json)
Figure 5  real brain template, montage           (c5_brain.json, c5_images_noise0.03.npz)
Figure 6  consensus floor and its controls       (c1_floor_controls.json, exp_r1 log values)
Figures 2, 3 and 7 are written by exp_r2_heterogeneity.py, exp_m1_medical.py and
exp_r6_baselines.py.
"""
import json
import os
import re

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from figstyle import PALETTE, LINESTYLES

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "..", "results")
FIG = os.environ.get("FIGDIR", os.path.join(HERE, "..", "figures"))
C5 = ["#2a78d6", "#1baf7a", "#eda100", "#7b3fb5", "#d6492a"]


def fig1():
    d = json.load(open(os.path.join(RES, "p2_protocol.json")))["alpha0.5"]
    names = {"fe": "forward Euler", "imex": "IMEX Euler", "be": "backward Euler (BE-N3)",
             "bels": "backward Euler (BE-LS)", "gt": "decentralized GT"}
    ref = {"fe": 0.12, "imex": 0.3, "be": 1.0, "bels": 1.0, "gt": 0.04}
    fig, ax = plt.subplots(1, 3, figsize=(12.2, 3.6))
    for c, k in zip(C5, names):
        r = next(x for x in d[k] if abs(x["step"] - ref[k]) < 1e-12)
        ax[0].loglog(r["curve_it"], np.maximum(r["curve_err"], 1e-17), color=c, label=names[k])
        st = [x for x in d[k] if x["stable"]]
        s = [x["step"] for x in st]
        med = np.array([x["tail_median"] for x in st])
        lo = np.array([x["tail_lo"] for x in st])
        hi = np.array([x["tail_hi"] for x in st])
        ax[1].errorbar(s, med, yerr=[med - lo, hi - med], color=c, marker="o", ms=3.5,
                       lw=1.1, capsize=2, label=names[k])
        for key, mk in (("it3", "o"), ("it4", "s")):
            pts = [(x["tail_median"], x[key]) for x in st if x[key] is not None]
            if pts:
                e, it = zip(*pts)
                ax[2].loglog(e, it, mk, color=c, ms=4.5, mfc="none" if key == "it4" else c)
    ax[0].axhline(1e-3, color="0.6", lw=0.8, ls=":")
    ax[0].set_xlabel("iteration (time step)"); ax[0].set_ylabel("relative field error")
    ax[0].set_title("(a) speed-oriented steps"); ax[0].legend(fontsize=7)
    ax[1].set_xscale("log"); ax[1].set_yscale("log")
    ax[1].set_xlabel("step size"); ax[1].set_ylabel("final error (tail median)")
    ax[1].set_title("(b) final error against step")
    ax[2].set_xlabel("final error (tail median)"); ax[2].set_ylabel("iterations to target")
    ax[2].set_title(r"(c) iterations to $10^{-3}$ (filled), $10^{-4}$ (open)")
    fig.savefig(os.path.join(FIG, "figure1.pdf")); plt.close(fig)


def r5_rows():
    rows = []
    for line in open(os.path.join(RES, "exp_r5_mismatch.log")):
        m = re.match(r"\s+([\d.]+)\s+[\d.]+/[\d.]+\s+[\d.]+/[\d.]+\s+[\d.]+/[\d.]+\s+([\d.]+)", line)
        if m:
            rows.append((float(m.group(1)), float(m.group(2))))
    return rows


def fig4():
    c2 = json.load(open(os.path.join(RES, "c2_mismatch.json")))
    fig, ax = plt.subplots(1, 2, figsize=(11.0, 3.5), gridspec_kw={"width_ratios": [1, 2.2]})
    r5 = r5_rows()
    ax[0].plot([a for a, g in r5], [g for a, g in r5], "o-", color=PALETTE[0])
    ax[0].axhline(1.0, color="0.5", lw=0.8, ls="--")
    ax[0].set_xlabel("drift at the last slice (pixels)"); ax[0].set_ylabel("gain from sharing")
    ax[0].set_title("(a) smooth anatomical drift")
    lab = {"baseline": "phantom", "shift": "shift {} px", "gain": "gain field {:.0%}",
           "overlap": "common lesion sites", "frac": "sampling {:.0%}",
           "commonmask": "one common mask"}
    names, vals, cols = [], [], []
    for r in c2:
        k, l = r["kind"], r["level"]
        t = lab[k].format(l) if "{" in lab[k] else lab[k]
        names.append(t); vals.append(r["gain"])
        cols.append(PALETTE[3] if r["gain"] < 1 else PALETTE[0])
    y = np.arange(len(names))[::-1]
    ax[1].barh(y, vals, color=cols, height=0.6)
    ax[1].axvline(1.0, color="0.3", lw=0.9, ls="--")
    ax[1].set_yticks(y); ax[1].set_yticklabels(names, fontsize=8)
    for yy, v in zip(y, vals):
        ax[1].text(v + 0.01, yy, f"{v:.2f}", va="center", fontsize=7.5)
    ax[1].set_xlim(0, 1.6); ax[1].set_xlabel("gain from sharing (NRMSE per-slice / decentralized)")
    ax[1].set_title("(b) other departures, fixed weights")
    fig.savefig(os.path.join(FIG, "figure4.pdf")); plt.close(fig)


def fig5():
    d = json.load(open(os.path.join(RES, "c5_brain.json")))
    run = next(r for r in d["runs"] if r["noise"] == 0.03 and "oracle" in r)
    im = np.load(os.path.join(RES, "c5_images_noise0.03.npz"))
    T, Xi, Xd = im["truth"], im["ind"], im["dec"]
    show = [0, 2, 5, 7]
    fig, ax = plt.subplots(3, 4, figsize=(9.0, 7.0))
    pk = float(T.max())
    for j, s in enumerate(show):
        for i, (X, name) in enumerate(((T, "truth"), (Xi, "per-slice"), (Xd, "decentralized"))):
            a = ax[i, j]
            a.imshow(np.clip(X[s], 0, pk), cmap="gray", vmin=0, vmax=pk)
            a.set_xticks([]); a.set_yticks([])
            if i == 0:
                a.set_title(f"slice z = {d['slices'][s]}", fontsize=9)
            else:
                key = "ind" if i == 1 else "dec"
                a.text(3, 12, f"{run['validation'][key]['psnr_slices'][s]:.2f} dB",
                       color="yellow", fontsize=8)
            if j == 0:
                a.set_ylabel(name)
    fig.savefig(os.path.join(FIG, "figure5.pdf")); plt.close(fig)


def r1_values():
    """Final consensus errors printed by exp_r1_lipschitz_control.py."""
    out = {}
    for line in open(os.path.join(RES, "exp_r1_lipschitz_control.log")):
        m = re.match(r"\s+a=1\.00\s+NRMSE=[\d.]+\s+consensus\(final\)=([\de.+-]+)", line)
        if m:
            out["a1"] = float(m.group(1))
        m = re.match(r"\s+eps=1e-02: NRMSE=[\d.]+\s+consensus\(final\)=([\de.+-]+)", line)
        if m:
            out["eps1e-02"] = float(m.group(1))
        m = re.match(r"\s+p=0\.50: NRMSE=[\d.]+\s+consensus\(final\)=([\de.+-]+)", line)
        if m:
            out["p0.50"] = float(m.group(1))
    return out


def fig6():
    r1 = r1_values()
    c1 = json.load(open(os.path.join(RES, "c1_floor_controls.json")))
    runs, fits = c1["runs"], c1["fits"]
    fig, ax = plt.subplots(1, 3, figsize=(12.4, 3.7))
    for c, eta in zip(PALETTE, (0.28, 0.15, 0.06)):
        r = next(x for x in runs if x["tag"] == "main6000" and x["eta"] == eta)
        ax[0].loglog(r["curve_it"], r["curve"], color=c, label=rf"$\eta={eta}$")
    ax[0].set_xlabel("iteration"); ax[0].set_ylabel("consensus error")
    ax[0].set_title("(a) consensus error"); ax[0].legend(fontsize=8)
    series = [("main6000", r"$\eta_d=0.30$ fixed", PALETTE[0], "o"),
              ("ratio2", r"$\eta_d=2\eta$", PALETTE[1], "s"),
              ("noprivate_a0.21", "no private variable", PALETTE[2], "^")]
    for tag, lab, c, mk in series:
        rs = sorted([x for x in runs if x["tag"] == tag], key=lambda q: q["eta"])
        f = fits[f"{tag}|median"]
        ax[1].loglog([q["eta"] for q in rs], [q["median"] for q in rs], mk, color=c,
                     label=f"{lab} (slope {f['slope']:.2f})")
        e = np.array([q["eta"] for q in rs])
        ax[1].loglog(e, np.exp(f["intercept"]) * e ** f["slope"], color=c, lw=0.9)
    for r in range(5):
        rs = sorted([x for x in runs if x["tag"] == f"seed{r}"], key=lambda q: q["eta"])
        ax[1].loglog([q["eta"] for q in rs], [q["median"] for q in rs], ".", color="0.55",
                     ms=4, label="five resampled instances" if r == 0 else None)
    ax[1].set_xlabel(r"step size $\eta$"); ax[1].set_ylabel("floor (tail median)")
    ax[1].set_title("(b) floor against step"); ax[1].legend(fontsize=7)
    # controls at eta = 0.15
    get = lambda tag, **kw: next(x for x in runs if x["tag"] == tag and
                                 all(abs(x[k] - v) < 1e-12 for k, v in kw.items()))
    bars = [("paper order", get("order_zds")["median"]),
            (r"$d$ before mixing", get("order_dzs")["median"]),
            (r"gradient before $d$", get("order_zsd")["median"]),
            (r"$\eta_d=0.075$", get("etad", eta_d=0.075)["median"]),
            (r"$\eta_d=0.60$", get("etad", eta_d=0.6)["median"]),
            (r"$d$ frozen", get("freeze")["median"]),
            ("no private variable", get("noprivate_a0.21", eta=0.13)["median"]),
            (r"no private, $\alpha_z=1$", max(get("noprivate_a1", eta=0.13)["median"], 1e-17)),
            (r"$\alpha=1$", r1["a1"]), (r"smoothed, $\varepsilon=10^{-2}$", r1["eps1e-02"]),
            (r"diminishing, $p=0.5$", r1["p0.50"])]
    y = np.arange(len(bars))[::-1]
    ax[2].barh(y, [b[1] for b in bars], color=[PALETTE[0]] * 6 + [PALETTE[2]] * 2 +
               [PALETTE[1]] * 3, height=0.6)
    ax[2].set_xscale("log"); ax[2].set_xlim(1e-17, 1)
    ax[2].set_yticks(y); ax[2].set_yticklabels([b[0] for b in bars], fontsize=7.5)
    ax[2].set_xlabel("consensus error at the end of the run")
    ax[2].set_title("(c) controls at the operating step")
    fig.savefig(os.path.join(FIG, "figure6.pdf")); plt.close(fig)


if __name__ == "__main__":
    os.makedirs(FIG, exist_ok=True)
    fig1(); fig4(); fig6()
    if os.path.exists(os.path.join(RES, "c5_brain.json")):
        fig5()
    # figures 2, 3 and 7 are drawn by their experiment scripts; copy them to the
    # names used in the manuscript
    import shutil
    for src, dst in (("fig_r2_heterogeneity.pdf", "figure2.pdf"),
                     ("fig_m1_medical.pdf", "figure3.pdf"),
                     ("fig_r6_baselines.pdf", "figure7.pdf")):
        if os.path.exists(os.path.join(FIG, src)):
            shutil.copyfile(os.path.join(FIG, src), os.path.join(FIG, dst))
