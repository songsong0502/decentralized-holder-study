"""In-process decentralized solvers over a mixing matrix W.

The network state is a stacked array X of shape (m, n): row i is node i's
local copy x_i of the shared variable.  Neighbour averaging is the single
matrix product W @ X; because W is supported on the graph, row i of W @ X
mixes only x_i with its neighbours -- the product is a faithful stand-in
for one round of neighbour communication (the process-per-node version in
dist_dec.py performs exactly the same arithmetic over OS pipes).

Two methods:
  dgd  : decentralized gradient descent, x_i <- sum_j W_ij x_j - eta grad_i.
         With a fixed step it converges to a neighbourhood of the optimum
         whose radius does not vanish -- the classic consensus bias.
  gt   : gradient tracking (DIGing), which carries an auxiliary variable
         s_i tracking the average gradient and removes that bias.  This is
         the scheme underlying Wang's decentralized proximal/double
         tracking; here every node's gradient is only alpha_i-Holder.

Each `node` object exposes grad(x) and (optionally) obj(x); the network's
`grad_all` stacks the per-node gradients.  Problems plant an exact global
minimiser x_star (see models_dec.py), so the reported error is the true
distance of the network mean to the optimum, not a proxy.
"""
import numpy as np


def grad_all(nodes, X):
    """Stack per-node gradients: row i = grad f_i evaluated at x_i = X[i]."""
    return np.stack([nd.grad(X[i]) for i, nd in enumerate(nodes)])


def _metrics(X, x_star, denom):
    xbar = X.mean(axis=0)
    err = np.linalg.norm(xbar - x_star) / denom
    # consensus error: how far the nodes are from agreeing, relative to
    # the size of the shared iterate
    cons = np.sqrt(((X - xbar) ** 2).sum(axis=1)).max()
    cons /= (np.linalg.norm(xbar) + 1e-30)
    return err, cons


def dgd(nodes, W, eta, iters, x0, x_star):
    m = len(nodes)
    X = np.tile(x0, (m, 1)).astype(float)
    denom = np.linalg.norm(x0 - x_star) + 1e-30
    err, cons = [], []
    e, c = _metrics(X, x_star, denom)
    err.append(e); cons.append(c)
    for _ in range(iters):
        X = W @ X - eta * grad_all(nodes, X)
        e, c = _metrics(X, x_star, denom)
        err.append(e); cons.append(c)
    return np.array(err), np.array(cons), X


def gt(nodes, W, eta, iters, x0, x_star):
    """Gradient tracking (DIGing) with a fixed step eta."""
    m = len(nodes)
    X = np.tile(x0, (m, 1)).astype(float)
    G = grad_all(nodes, X)
    S = G.copy()
    denom = np.linalg.norm(x0 - x_star) + 1e-30
    err, cons = [], []
    e, c = _metrics(X, x_star, denom)
    err.append(e); cons.append(c)
    for _ in range(iters):
        X = W @ X - eta * S
        Gnew = grad_all(nodes, X)
        S = W @ S + Gnew - G
        G = Gnew
        e, c = _metrics(X, x_star, denom)
        err.append(e); cons.append(c)
    return np.array(err), np.array(cons), X


def coupled_descent(nodes, L, beta, eta, iters, x0_stack, metric):
    """Decentralized gradient descent for a *soft*-coupled network:

        min sum_i f_i(x_i) + (beta/2) sum_{(i,j) in E} ||x_i - x_j||^2 .

    Each node keeps its OWN variable x_i (they need not agree); the coupling
    gradient at node i is beta * (L X)_i = beta * sum_{j~i}(x_i - x_j), a pure
    neighbour exchange (L is the graph Laplacian).  beta = 0 is K fully
    independent problems run in one batch; beta -> infinity forces hard
    consensus.  Used for multi-image reconstruction, where images are
    distinct but neighbouring slices/frames share structure.
    """
    X = x0_stack.copy().astype(float)
    hist = [metric(X)]
    for _ in range(iters):
        X = X - eta * (grad_all(nodes, X) + beta * (L @ X))
        hist.append(metric(X))
    return np.array(hist), X


class Node:
    """Local strongly-convex objective with an alpha-Holder gradient term.

        f_i(x) = 1/2 x' Q_i x - q_i' x
                 + sum_j lam_{i,j} * psi(x_j; alpha_i),
    where psi is either |t|^{1+a} (two-sided, kind='abs') or (t_+)^{1+a}
    (one-sided, kind='pos').  Q_i is the node's local data operator.  The
    weight lam_i may be a scalar or a length-n vector: a vector lets a node
    apply its Holder penalty only on the coordinates it owns (used by the
    domain-decomposition PDE, where subdomain i carries exponent alpha_i on
    its own grid points only).  The linear term q_i is planted by the model
    so a chosen x_star is the exact minimiser of sum_i f_i.
    """

    def __init__(self, Q, q, lam, alpha, kind="abs"):
        self.Q, self.q, self.lam, self.alpha, self.kind = Q, q, lam, alpha, kind

    def _hgrad(self, x):
        a = self.alpha
        if self.kind == "abs":
            return (1.0 + a) * np.abs(x) ** a * np.sign(x)
        return (1.0 + a) * np.maximum(x, 0.0) ** a

    def grad(self, x):
        return self.Q @ x - self.q + self.lam * self._hgrad(x)

    def _psi(self, x):
        a = self.alpha
        if self.kind == "abs":
            return np.abs(x) ** (1.0 + a)
        return np.maximum(x, 0.0) ** (1.0 + a)

    def obj(self, x):
        return 0.5 * x @ (self.Q @ x) - self.q @ x + np.sum(self.lam * self._psi(x))


def plant_linear_terms(Qs, lams, alphas, kinds, x_star):
    """Return per-node q_i so that x_star minimises sum_i f_i exactly.

    grad F(x_star) = (sum_i Q_i) x_star + sum_i lam_i h_i(x_star) - sum_i q_i
    must vanish.  We distribute the requirement node-by-node:
        q_i = Q_i x_star + lam_i h_i(x_star),
    which each node can form locally from x_star and its own data.  Then
    sum_i q_i = (sum Q_i) x_star + sum lam_i h_i(x_star) = grad of the
    smooth+Holder parts at x_star, so grad F(x_star) = 0.
    """
    qs = []
    for Q, lam, a, kind in zip(Qs, lams, alphas, kinds):
        if kind == "abs":
            h = (1.0 + a) * np.abs(x_star) ** a * np.sign(x_star)
        else:
            h = (1.0 + a) * np.maximum(x_star, 0.0) ** a
        qs.append(Q @ x_star + lam * h)
    return qs
