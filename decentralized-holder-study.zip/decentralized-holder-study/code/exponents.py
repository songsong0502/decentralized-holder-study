"""Estimating the Holder exponent alpha from data.

Neither application exponent in this report is a free knob: each is a
quantity its own field measures.  This module implements the two standard
estimation procedures, so the alpha_i used in the experiments are OUTPUTS
of an estimator applied to data.

(1) fit_reaction_order -- chemical kinetics.
    A power-law rate law r = k u^alpha becomes a straight line in log-log
    coordinates, log r = log k + alpha log u, so the reaction order alpha is
    the ordinary-least-squares SLOPE of log r on log u.  This is the routine
    laboratory determination of a fractional reaction order (Temkin 1975;
    Garcia-Ochoa & Romero 1988).  Returns the slope, the prefactor, and the
    slope's standard error.

(2) ggd_tail_index -- sparse imaging.
    Sparsity-promoting reconstruction penalties are the MAP terms of a
    generalized Gaussian prior: a coefficient density proportional to
    exp(-|x/sigma|^beta) yields the penalty sum_j |x_j|^beta.  The shape
    parameter beta is therefore the exponent the data ask for, and it is
    estimated from the coefficient histogram by moment matching: for a
    zero-mean generalized Gaussian,

        E[X^2] / (E|X|)^2 = Gamma(3/beta) Gamma(1/beta) / Gamma(2/beta)^2,

    a strictly decreasing function of beta, so the sample ratio inverts to a
    unique beta (the classical Mallat / Sharifi--Leon-Garcia estimator).
    Heavy-tailed (sparse) tissue gives small beta; diffuse tissue gives beta
    approaching 2.

    Relation to the exponent used here.  The MAP penalty |x|^beta with the
    measured beta < 1 is NON-convex and non-differentiable -- the regime
    imaging practice does use (p = 1/2 in Chartrand 2007, Zhu & Li 2014) but
    which lies outside the strongly-convex-plus-Holder framework of Chen,
    Kelley and Wang.  The convex bridge member admitted by that framework is
    psi(t) = |t|^{1+alpha}; setting

        alpha_i = beta_i   (measured)   i.e.   p_i = 1 + beta_i in (1,2)

    is the convexification that preserves the measured quantity: the amount
    by which the exponent exceeds the l1 limit is exactly the measured tail
    index.  Sparser tissue therefore gets a p closer to 1, reproducing the
    empirical rule quoted in the imaging literature -- but derived from a
    measurement rather than assumed.
"""
import numpy as np
from math import lgamma


# ----------------------------------------------------------------------
def fit_reaction_order(u, r):
    """OLS slope of log r on log u: the fractional reaction order.

    Returns (alpha_hat, k_hat, se) where se is the standard error of the
    slope under the usual log-scale (multiplicative) error model.
    """
    X = np.log(np.asarray(u, float))
    Y = np.log(np.asarray(r, float))
    n = X.size
    xbar, ybar = X.mean(), Y.mean()
    Sxx = ((X - xbar) ** 2).sum()
    alpha_hat = ((X - xbar) * (Y - ybar)).sum() / Sxx
    logk_hat = ybar - alpha_hat * xbar
    resid = Y - (logk_hat + alpha_hat * X)
    s2 = (resid ** 2).sum() / (n - 2)
    return float(alpha_hat), float(np.exp(logk_hat)), float(np.sqrt(s2 / Sxx))


# ----------------------------------------------------------------------
def _moment_ratio(b):
    """E[X^2]/(E|X|)^2 for a generalized Gaussian of shape b."""
    return float(np.exp(lgamma(3.0 / b) + lgamma(1.0 / b) - 2.0 * lgamma(2.0 / b)))


def ggd_tail_index(x, lo=0.15, hi=5.0, iters=90):
    """Moment-matching estimate of the generalized-Gaussian shape parameter.

    x is the full coefficient vector of an image (zeros included -- they are
    what make a sparse image heavy-tailed).  The ratio E[X^2]/(E|X|)^2 is
    strictly decreasing in the shape, so bisection inverts it uniquely.
    """
    x = np.asarray(x, float).ravel()
    m1 = np.abs(x).mean()
    if m1 <= 0:
        return float("nan")
    r = (x ** 2).mean() / m1 ** 2
    if r <= _moment_ratio(hi):
        return float(hi)
    if r >= _moment_ratio(lo):
        return float(lo)
    a, b = lo, hi
    for _ in range(iters):
        mid = 0.5 * (a + b)
        if _moment_ratio(mid) > r:
            a = mid
        else:
            b = mid
    return float(0.5 * (a + b))


def ggd_sample(beta, size, rng, scale=1.0):
    """Draw from a zero-mean generalized Gaussian of shape beta."""
    g = rng.gamma(1.0 / beta, 1.0, size)
    return scale * np.sign(rng.standard_normal(size)) * g ** (1.0 / beta)
