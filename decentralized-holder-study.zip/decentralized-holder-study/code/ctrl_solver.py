"""Gradient tracking for the shared/private model with the switches needed to
isolate the consensus floor.

    private   True: u_i = z_i + d_i as in the paper;  False: u_i = z_i (no
              private variable), which makes the problem a plain finite sum
              f(z) = sum_i [ l_i(z) + (lam_z/K) psi(z; a_z) ] solved by standard GT
    order     "zds": mix z, update d, evaluate the tracked gradient at (z, d_new)
                     (the order used in the paper)
              "dzs": update d first (with the old z), then mix z, then evaluate
              "zsd": mix z, evaluate the tracked gradient at (z, d_old), then d
    freeze_at iteration after which d is frozen (no further private updates)
    eta_d     private step, independent of eta

The consensus error max_i ||z_i - zbar|| / ||zbar|| is recorded at every
iteration.  With private=True, order="zds" and freeze_at=None this routine
performs the same arithmetic as medsolvers.decentralized.
"""
import numpy as np

import medsolvers as ms


def run(ys, masks, alphas, lam_z, a_z, lam_d, eta, eta_d, iters, W=None,
        private=True, order="zds", freeze_at=None):
    K = len(ys)
    W = ms.path_mixing(K) if W is None else W
    Z = np.zeros((K,) + masks[0].shape)
    D = np.zeros((K,) + masks[0].shape)
    mix = lambda A: np.einsum("ij,jyx->iyx", W, A)

    def gz(i):
        return (ms.data_grad(Z[i] + D[i], ys[i], masks[i])
                + (lam_z / K) * ms._psi_grad(Z[i], a_z))

    def d_update():
        for i in range(K):
            D[i] -= eta_d * (ms.data_grad(Z[i] + D[i], ys[i], masks[i])
                             + lam_d * ms._psi_grad(D[i], alphas[i]))

    G = np.array([gz(i) for i in range(K)])
    S = G.copy()
    cons = np.empty(iters)
    for k in range(iters):
        upd = private and (freeze_at is None or k < freeze_at)
        if order == "dzs" and upd:
            d_update()
        Z = mix(Z) - eta * S
        if order == "zds" and upd:
            d_update()
        Gn = np.array([gz(i) for i in range(K)])
        S = mix(S) + Gn - G
        G = Gn
        if order == "zsd" and upd:
            d_update()
        zb = Z.mean(0)
        cons[k] = float(np.max(np.linalg.norm((Z - zb).reshape(K, -1), axis=1))
                        / (np.linalg.norm(zb) + 1e-30))
    return Z + D, Z, D, cons


def floor_stats(cons, frac=0.1):
    """Floor estimators on the last `frac` of the run."""
    c = np.asarray(cons)
    t = c[-max(1, int(len(c) * frac)):]
    return dict(final=float(c[-1]), median=float(np.median(t)),
                mean=float(np.mean(t)), lo=float(t.min()), hi=float(t.max()))
