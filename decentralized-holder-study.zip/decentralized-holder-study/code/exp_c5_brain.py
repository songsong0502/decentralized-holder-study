"""C5 -- the imaging comparison on real brain anatomy.

Data: the ICBM 2009a nonlinear symmetric T1-weighted template (1 mm, 197 x 233
x 189 voxels), as distributed with nilearn (file
mni_icbm152_t1_tal_nlin_sym_09a_converted.nii.gz, copied to code/data).  The
template is an average of real T1 scans, so the anatomy is real while the
k-space sampling and noise below are simulated.

Slices: K = 8 axial slices z = 80, 82, ..., 94 (2 mm apart), each zero-padded
to 233 x 233, centre-cropped to 200 x 200, resampled to 128 x 128 and scaled
to [0, 1].  Neighbouring slices differ by genuine, dense anatomical change, so
the shared/private split is NOT exact here.

Exponents: the shape index of slice i is estimated from the adjacent slice
z_i + 1 (1 mm away, not reconstructed); the shared exponent from the voxel-wise
mean of those eight adjacent slices.

Acquisition: independent variable-density masks at 30% per slice; complex
noise of standard deviation 0.03 and 0.06 per sampled coefficient.

Weights: chosen by k-space hold-out validation (10% of each worker's samples,
1000 iterations per candidate); the oracle choice on the same grid is
reported for reference.  Final runs: 4000 iterations, eta = 0.15,
eta_d = 0.30, chain of 8 workers.  Two further mask/noise realisations reuse
the validation-selected weights.
"""
import os

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")

import json
import sys
import time
from multiprocessing import Pool

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import medmodel as mm
import medsolvers as ms
import ctrl_solver as cs
import imgmetrics as im
import exponents as ex

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "..", "results")
DATA = os.path.join(HERE, "data", "mni_icbm152_t1_tal_nlin_sym_09a_converted.nii.gz")
NX, K = 128, 8
ZS = list(range(80, 96, 2))
ETA, ETA_D, SEL_IT, FIN_IT = 0.15, 0.30, 1000, 4000
LP = [0.02, 0.05, 0.1]
LZ = [0.05, 0.1, 0.2]
LD = [0.03, 0.1]


def load_slices():
    import nibabel as nb
    from skimage.transform import resize
    v = nb.load(DATA).get_fdata() / 255.0

    def prep(z):
        s = v[:, :, z]
        pad = np.zeros((233, 233))
        off = (233 - s.shape[0]) // 2
        pad[off:off + s.shape[0], :] = s
        c = (233 - 200) // 2
        crop = pad[c:c + 200, c:c + 200]
        return np.clip(resize(crop, (NX, NX), anti_aliasing=True, order=1), 0, None)
    truths = np.array([prep(z) for z in ZS])
    priors = np.array([prep(z + 1) for z in ZS])
    m = max(truths.max(), priors.max())
    return truths / m, priors / m


def nrmse(X, T):
    return float(np.linalg.norm(X - T) / np.linalg.norm(T))


def misfit(X, ys, va):
    return float(sum(np.sum(np.abs(mm.fwd(X[i], va[i]) - ys[i] * va[i]) ** 2)
                     for i in range(len(ys))))


def acquire(truths, noise, seed):
    masks = np.array([mm.kspace_mask(np.random.default_rng([seed, i]), nx=NX)
                      for i in range(K)])
    ys = mm.acquire(truths, masks, noise, np.random.default_rng([seed, 99]))
    return masks, ys


def select(truths, masks, ys, alphas, a_z, seed):
    rng = np.random.default_rng([seed, 7])
    va = np.array([m & (rng.random(m.shape) < 0.1) for m in masks])
    tr = masks & ~va
    ytr = ys * tr
    vi = min((misfit(ms.independent(ytr, tr, alphas, 1e-4, p, ETA, SEL_IT)[1], ys, va), p)
             for p in LP)
    oi = min((nrmse(ms.independent(ys, masks, alphas, 1e-4, p, ETA, SEL_IT)[1], truths), p)
             for p in LP)
    vd, od = [], []
    for z in LZ:
        for d in LD:
            X = ms.decentralized(ytr, tr, alphas, z, a_z, d, ETA, SEL_IT, eta_d=ETA_D)[1]
            vd.append((misfit(X, ys, va), z, d))
            X = ms.decentralized(ys, masks, alphas, z, a_z, d, ETA, SEL_IT, eta_d=ETA_D)[1]
            od.append((nrmse(X, truths), z, d))
    v, o = min(vd), min(od)
    return (vi[1], v[1], v[2]), (oi[1], o[1], o[2])


def final(truths, masks, ys, alphas, a_z, w):
    lp, lz, ld = w
    t0 = time.perf_counter()
    Xi = ms.independent(ys, masks, alphas, 1e-4, lp, ETA, FIN_IT)[1]
    ti = time.perf_counter() - t0
    Xc = ms.centralized(ys, masks, alphas, lz, a_z, ld, ETA, FIN_IT)[1]
    t0 = time.perf_counter()
    Xd, Z, D, cons = cs.run(ys, masks, alphas, lz, a_z, ld, ETA, ETA_D, FIN_IT)
    td = time.perf_counter() - t0
    out = dict(weights=w, consensus=cs.floor_stats(cons)["median"],
               sec_per_it_dec=td / FIN_IT, sec_per_it_ind=ti / FIN_IT)
    for tag, X in (("ind", Xi), ("cen", Xc), ("dec", Xd)):
        n_, p_, s_ = im.report(X, truths, NX)
        out[tag] = dict(nrmse=n_, psnr=p_, ssim=s_,
                        psnr_slices=[im.psnr(X[i], truths[i], peak=float(truths.max()))
                                     for i in range(K)])
    out["gain"] = out["ind"]["nrmse"] / out["dec"]["nrmse"]
    return out, Xi, Xd


def job(spec):
    noise, seed, w_given = spec
    truths, priors = load_slices()
    alphas = [ex.ggd_tail_index(p.ravel()) for p in priors]
    a_z = ex.ggd_tail_index(priors.mean(0).ravel())
    masks, ys = acquire(truths, noise, seed)
    res = dict(noise=noise, seed=seed, alphas=alphas, a_z=a_z,
               sampled=[float(m.mean()) for m in masks],
               union=float(np.mean(np.any(masks, axis=0))))
    if w_given is None:
        wv, wo = select(truths, masks, ys, alphas, a_z, seed)
        res["validation"], Xi, Xd = final(truths, masks, ys, alphas, a_z, wv)
        res["oracle"], _, _ = final(truths, masks, ys, alphas, a_z, wo)
        np.savez_compressed(os.path.join(RES, f"c5_images_noise{noise}.npz"),
                            truth=truths, ind=Xi, dec=Xd)
    else:
        res["validation"], _, _ = final(truths, masks, ys, alphas, a_z, w_given)
    print(noise, seed, {k: (v["ind"]["psnr"], v["cen"]["psnr"], v["dec"]["psnr"], v["weights"])
                        for k, v in res.items() if k in ("validation", "oracle")}, flush=True)
    return res


def main():
    t0 = time.time()
    truths, priors = load_slices()
    print("slices", ZS, "alphas", [round(ex.ggd_tail_index(p.ravel()), 3) for p in priors],
          "a_z", round(ex.ggd_tail_index(priors.mean(0).ravel()), 3))
    rel = [float(np.linalg.norm(truths[i + 1] - truths[i]) / np.linalg.norm(truths[i]))
           for i in range(K - 1)]
    print("relative change between neighbouring slices", np.round(rel, 3))
    with Pool(2) as pool:
        first = pool.map(job, [(0.03, 0, None), (0.06, 0, None)], chunksize=1)
        more = []
        specs = []
        for f in first:
            for s in (1, 2):
                specs.append((f["noise"], s, f["validation"]["weights"]))
        more = pool.map(job, specs, chunksize=1)
    with open(os.path.join(RES, "c5_brain.json"), "w") as fh:
        json.dump(dict(slices=ZS, neighbour_change=rel, runs=first + more), fh, indent=1)
    print(f"[elapsed {time.time()-t0:.0f} s]")


if __name__ == "__main__":
    main()
