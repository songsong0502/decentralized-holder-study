"""R2 -- how much does the pattern of exponents across subdomains matter?

D1 made one comparison: move a single subdomain from alpha = 0.5 to 0.2 and
see whether it matters that the subdomain holds the dead core.  That is a
two-point contrast, and it is not enough to say which feature of the
exponent vector -- its minimum, its spread, or where the minimum sits --
governs the accuracy the network reaches.

Here the same domain-decomposed problem is run over sixteen exponent
vectors chosen to separate those three features:

  uniform         alpha_i = a for all i, a in {0.2 .. 0.8}: pure level effect;
  one low worker  a_min placed in subdomain 0 (which holds the dead core)
                  and, separately, in subdomains 1, 2, 3: pure placement
                  effect at fixed minimum and fixed spread;
  graded          alpha increasing or decreasing across the strips;
  split           two low workers and two high ones, on either side.

For each vector we record the field error, the error restricted to the dead
core, and the consensus error the network settles at, and then check which
scalar summary of the vector predicts them.
"""
import time

import numpy as np
import matplotlib.pyplot as plt

from figstyle import PALETTE, LINESTYLES
import graphs, decentralized as dec, models_dec as md

import os
FIGDIR = os.environ.get("FIGDIR", os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "figures"))

N, M = 12, 4
ETA, ITERS = 0.04, 12000

CONFIGS = [
    ([0.8, 0.8, 0.8, 0.8], "uniform 0.8"),
    ([0.6, 0.6, 0.6, 0.6], "uniform 0.6"),
    ([0.5, 0.5, 0.5, 0.5], "uniform 0.5"),
    ([0.4, 0.4, 0.4, 0.4], "uniform 0.4"),
    ([0.3, 0.3, 0.3, 0.3], "uniform 0.3"),
    ([0.2, 0.2, 0.2, 0.2], "uniform 0.2"),
    ([0.4, 0.5, 0.5, 0.5], "0.4 in subdomain 0 (dead core)"),
    ([0.3, 0.5, 0.5, 0.5], "0.3 in subdomain 0 (dead core)"),
    ([0.2, 0.5, 0.5, 0.5], "0.2 in subdomain 0 (dead core)"),
    ([0.5, 0.2, 0.5, 0.5], "0.2 in subdomain 1"),
    ([0.5, 0.5, 0.2, 0.5], "0.2 in subdomain 2"),
    ([0.5, 0.5, 0.5, 0.2], "0.2 in subdomain 3"),
    ([0.2, 0.4, 0.6, 0.8], "graded 0.2 -> 0.8"),
    ([0.8, 0.6, 0.4, 0.2], "graded 0.8 -> 0.2"),
    ([0.2, 0.2, 0.8, 0.8], "split, low half holds dead core"),
    ([0.8, 0.8, 0.2, 0.2], "split, high half holds dead core"),
]


def main():
    t0 = time.time()
    W = graphs.metropolis(graphs.ring(M))
    rows = []
    print(f"{'exponent vector':<22}{'a_min':>7}{'a_max-a_min':>13}{'core a':>8}"
          f"{'field err':>12}{'dead-core err':>15}{'consensus':>12}  label")
    for al, lab in CONFIGS:
        nodes, x0, xs, owner = md.make_pde(N=N, m=M, alphas=al)
        core = xs == 0.0
        err, cons, X = dec.gt(nodes, W, ETA, ITERS, x0, xs)
        xbar = X.mean(0)
        core_err = float(np.linalg.norm((xbar - xs)[core]) / np.linalg.norm(xs))
        core_strips = sorted(set(owner[core].tolist()))
        # strips that hold the near-zero part of the field: the dead core
        # itself and the ring around it, where the reaction term is closest
        # to its non-Lipschitz kink
        near = xs <= 0.05 * xs.max()
        near_strips = sorted(set(owner[near].tolist()))
        rows.append(dict(alphas=al, label=lab, a_min=min(al),
                         spread=max(al) - min(al), a_core=al[core_strips[0]],
                         a_near=min(al[s] for s in near_strips),
                         err=float(err[-1]), core_err=core_err,
                         cons=float(cons[-1])))
        r = rows[-1]
        print(f"{str(al):<22}{r['a_min']:>7.2f}{r['spread']:>13.2f}"
              f"{r['a_core']:>8.2f}{r['err']:>12.2e}{r['core_err']:>15.2e}"
              f"{r['cons']:>12.2e}  {lab}")
    print(f"\ndead core occupies strips {core_strips} of {M}; "
          f"the near-zero region (u* <= 5% of max) spans {near_strips}")

    # ---- which scalar predicts the plateau? --------------------------
    from scipy import stats
    a_min = np.array([r["a_min"] for r in rows])
    a_core = np.array([r["a_core"] for r in rows])
    spread = np.array([r["spread"] for r in rows])
    y = np.log10([r["err"] for r in rows])
    a_near = np.array([r["a_near"] for r in rows])
    for name, v in (("global minimum a_min", a_min),
                    ("exponent of the dead-core strip", a_core),
                    ("smallest exponent on the near-zero region", a_near),
                    ("spread a_max - a_min", spread)):
        r = stats.linregress(v, y)
        print(f"  log10(field error) vs {name:<32}: "
              f"slope {r.slope:+.2f}, R2 = {r.rvalue**2:.3f}")

    # ---------------- figure ------------------------------------------
    fig, axes = plt.subplots(1, 2, figsize=(8.4, 3.4))
    ax = axes[0]
    uni = [r for r in rows if r["label"].startswith("uniform")]
    ax.semilogy([r["a_core"] for r in uni], [r["err"] for r in uni],
                marker="o", ms=4.5, color=PALETTE[0], ls=LINESTYLES[0],
                label="uniform exponent")
    place = [r for r in rows if r["a_min"] == 0.2 and r["spread"] == 0.3]
    ax.semilogy([r["a_core"] for r in place], [r["err"] for r in place],
                marker="s", ms=4.5, color=PALETTE[2], ls="none",
                label=r"one worker at $0.2$, rest $0.5$")
    ax.set_xlabel(r"exponent of the strip holding the dead core")
    ax.set_ylabel("relative field error")
    ax.set_title("(a) field error", fontsize=9)
    ax.legend(fontsize=6.8, loc="upper right")

    ax = axes[1]
    ax.semilogy([r["a_core"] for r in rows], [r["cons"] for r in rows],
                marker="o", ms=4.5, ls="none", color=PALETTE[1])
    ax.set_xlabel(r"exponent of the strip holding the dead core")
    ax.set_ylabel("consensus error at 12000 iterations")
    ax.set_title("(b) consensus error", fontsize=9)

    fig.savefig(f"{FIGDIR}/fig_r2_heterogeneity.pdf")
    fig.savefig(f"{FIGDIR}/fig_r2_heterogeneity.png")
    plt.close(fig)
    print(f"[elapsed {time.time()-t0:.0f} s]")


if __name__ == "__main__":
    main()
