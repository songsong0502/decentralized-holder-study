"""M1 -- multi-slice sparse reconstruction: does sharing pay, and when?

Reconstructs K = 4 neighbouring slices of one volume from independently
undersampled k-space, three ways:

  independent    each slice on its own (the usual practice);
  centralized    the shared/private model (*) of medsolvers.py, all data
                 pooled on one machine -- the accuracy ceiling;
  decentralized  the same model solved by gradient tracking on the shared
                 anatomy, private detail kept local (this report's method).

Reports NRMSE, PSNR and SSIM (imgmetrics.py), sweeps the measurement noise to
locate where sharing helps, and writes the montage figure.

Every constant used is defined at the top of this file; nothing is tuned
inside the run except the per-method regularisation weights, which are chosen
by the sweep described in tune() and reported.
"""
import numpy as np
import matplotlib.pyplot as plt

from figstyle import PALETTE, LINESTYLES
import medmodel as mm
import medsolvers as ms
import imgmetrics as im

FIGDIR = __import__("os").environ.get("FIGDIR", __import__("os").path.join(__import__("os").path.dirname(__import__("os").path.abspath(__file__)), "..", "figures"))

SEED_PHANTOM, SEED_MASK, SEED_ALPHA, SEED_NOISE = 0, 3, 1, 7
NOISE_OP = 0.06                    # operating point
NOISE_SWEEP = [0.02, 0.04, 0.06, 0.09, 0.12, 0.18]
TUNE_ITERS = 600                   # short runs are enough to rank weights
ETA_Z, ETA_D, ITERS = 0.15, 0.30, 4000
LAMP_GRID = [0.008, 0.02, 0.05, 0.1, 0.2]          # independent baseline
LAMZ_GRID = [0.02, 0.05, 0.1, 0.2]                 # shared part
LAMD_GRID = [0.01, 0.03, 0.06, 0.12]               # private part


def setup():
    truths, lesions, base = mm.build_slices(np.random.default_rng(SEED_PHANTOM))
    masks = mm.slice_masks(np.random.default_rng(SEED_MASK))
    alphas = mm.measure_alphas(np.random.default_rng(SEED_ALPHA))
    return truths, lesions, base, masks, alphas


def make_metric(truths):
    den = np.array([np.linalg.norm(t) for t in truths])
    return lambda X: float(np.mean([np.linalg.norm(X[i] - truths[i]) / den[i]
                                    for i in range(len(truths))]))


def tune(ys, masks, alphas, a_z, metric, iters=TUNE_ITERS):
    """Pick each method's regularisation weights by best NRMSE, so that no
    method is handicapped by the other's tuning."""
    best_i = min(((ms.independent(ys, masks, alphas, 1e-4, lp, 0.5, iters,
                                  metric)[0][-1], lp) for lp in LAMP_GRID),
                 key=lambda t: t[0])
    best_c = None
    for lz in LAMZ_GRID:
        for ld in LAMD_GRID:
            e = ms.centralized(ys, masks, alphas, lz, a_z, ld, 0.3, iters,
                               metric)[0][-1]
            if np.isfinite(e) and (best_c is None or e < best_c[0]):
                best_c = (e, lz, ld)
    return best_i[1], best_c[1], best_c[2]


def main():
    truths, lesions, base, masks, alphas = setup()
    a_z = float(np.mean(alphas))
    metric = make_metric(truths)
    nx = mm.NX

    print(f"phantom: {mm.K} slices of {nx}x{nx}; shared anatomy "
          f"{int((base > 0.02).sum())} px; lesions per slice {mm.N_LESION}")
    for i, t in enumerate(truths):
        d = t - base
        print(f"  slice {i}: private energy {np.linalg.norm(d)/np.linalg.norm(t):.2f}"
              f"  lesion px {int(np.count_nonzero(np.abs(d) > 1e-6))}"
              f"  measured alpha {alphas[i]:.3f} (p = {1+alphas[i]:.2f})")
    print(f"per-slice k-space sampling {[round(float(m.mean()),3) for m in masks]}"
          f"; union coverage {float(np.any(masks,0).mean()):.3f}")

    ys = mm.acquire(truths, masks, NOISE_OP, np.random.default_rng(SEED_NOISE))
    lamp, lam_z, lam_d = tune(ys, masks, alphas, a_z, metric)
    print(f"tuned weights: independent lam_p={lamp}; shared lam_z={lam_z}, "
          f"private lam_d={lam_d}")

    h_ind, X_ind = ms.independent(ys, masks, alphas, 1e-4, lamp, ETA_Z, ITERS, metric)
    h_cen, X_cen, _, _ = ms.centralized(ys, masks, alphas, lam_z, a_z, lam_d,
                                        ETA_Z, ITERS, metric)
    h_dec, X_dec, Z, D, cons = ms.decentralized(ys, masks, alphas, lam_z, a_z,
                                                lam_d, ETA_Z, ITERS, metric=metric,
                                                track_consensus=True, eta_d=ETA_D)
    print(f"\nat noise {NOISE_OP} (step {ETA_Z}, {ITERS} iterations):")
    for name, X in (("independent", X_ind), ("centralized", X_cen),
                    ("decentralized", X_dec)):
        nr, ps, ss = im.report(X, truths, nx)
        print(f"  {name:14s} NRMSE={nr:.4f}  PSNR={ps:.2f} dB  SSIM={ss:.3f}")
    print(f"  decentralized vs centralized: image difference "
          f"{np.linalg.norm(X_dec-X_cen)/np.linalg.norm(X_cen):.2e}, "
          f"consensus error {cons[-1]:.2e}")

    print("\nnoise sweep (each method retuned at each level):")
    sweep = []
    for nz in NOISE_SWEEP:
        y = mm.acquire(truths, masks, nz, np.random.default_rng(SEED_NOISE))
        lp, lz, ld = tune(y, masks, alphas, a_z, metric)
        ei = ms.independent(y, masks, alphas, 1e-4, lp, ETA_Z, ITERS, metric)[0][-1]
        ed = ms.decentralized(y, masks, alphas, lz, a_z, ld, ETA_Z, ITERS,
                              metric=metric, eta_d=ETA_D)[0][-1]
        sweep.append((nz, ei, ed))
        print(f"  noise={nz:.2f}: independent={ei:.4f}  decentralized={ed:.4f}"
              f"  gain={ei/ed:.2f}x")

    # ---------------- figure ----------------
    fig = plt.figure(figsize=(11.2, 4.5))
    gs = fig.add_gridspec(3, mm.K + 2, width_ratios=[1.25] + [1] * mm.K + [1.25])

    ax = fig.add_subplot(gs[:, 0])
    ax.semilogy(h_ind, color=PALETTE[0], ls=LINESTYLES[0], label="independent")
    ax.semilogy(h_cen, color=PALETTE[1], ls=LINESTYLES[1], label="centralized")
    ax.semilogy(h_dec, color=PALETTE[2], ls=LINESTYLES[2], label="decentralized")
    ax.set_xlabel("iterations"); ax.set_ylabel("mean NRMSE")
    ax.set_title("(a) convergence", fontsize=9)
    ax.legend(fontsize=6.5, loc="upper right")

    vmax = float(truths.max())
    rows = [("truth", truths), ("independent", X_ind), ("decentralized", X_dec)]
    for r, (name, imgs) in enumerate(rows):
        for i in range(mm.K):
            axi = fig.add_subplot(gs[r, i + 1])
            axi.imshow(imgs[i], origin="lower", cmap="gray", vmin=0, vmax=vmax)
            axi.set_xticks([]); axi.set_yticks([])
            if r == 0:
                axi.set_title(f"slice {i}\n$p={1+alphas[i]:.2f}$", fontsize=7.5)
            else:
                axi.set_xlabel(f"{im.psnr(imgs[i], truths[i], peak=vmax):.1f} dB",
                               fontsize=6.5, labelpad=1.5)
            if i == 0:
                axi.set_ylabel(name, fontsize=8)

    ax = fig.add_subplot(gs[:, -1])
    nzs = [s[0] for s in sweep]
    gains = [s[1] / s[2] for s in sweep]
    ax.plot(nzs, gains, marker="o", ms=4, color=PALETTE[0], ls=LINESTYLES[0])
    ax.axhline(1.0, color="0.5", lw=0.8, ls=":")
    ax.set_xlabel("measurement noise")
    ax.set_ylabel("gain = independent / decentralized")
    ax.set_title("(c) gain vs measurement noise", fontsize=9)
    ax.set_ylim(0.95, max(gains) * 1.06)

    fig.savefig(f"{FIGDIR}/fig_m1_medical.pdf")
    fig.savefig(f"{FIGDIR}/fig_m1_medical.png")
    plt.close(fig)


if __name__ == "__main__":
    main()
