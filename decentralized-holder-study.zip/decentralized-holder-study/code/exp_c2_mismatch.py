"""C2 -- departures of the phantom from the shared/private assumption.

All runs use the weights tuned once at the operating point (lam_p = 0.05,
lam_z = 0.1, lam_d = 0.06; no retuning), noise 0.06, eta = 0.15,
eta_d = 0.30, 4000 iterations, and the measured exponents.

(a) registration error: slice i's anatomy is shifted by an integer offset
    drawn uniformly from [-S, S]^2 (slice 0 is the reference), S = 1, 2, 3 px
(b) non-sparse slice differences: slice i's anatomy is multiplied by a smooth
    gain field 1 + g F_i (F_i smooth, max |F_i| = 1, independent per slice),
    g = 0.05, 0.10, 0.20
(c) lesion overlap: every slice's lesions at the same locations (slice i uses
    the first n_i of one common set of 14 positions) against the default
    distinct locations
(d) sampling fraction 0.15, 0.20, 0.30, 0.40 per slice (independent masks)
(e) one common mask for all slices against independent masks (fraction 0.30)
"""
import os

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")

import json
import sys
from multiprocessing import Pool

import numpy as np
from scipy import ndimage

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import medmodel as mm
import medsolvers as ms
import imgmetrics as im
import exp_m1_medical as M1

RES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "results")
NOISE, ITERS = 0.06, 4000
LAM_P, LAM_Z, LAM_D = 0.05, 0.1, 0.06
ETA, ETA_D = 0.15, 0.30


def lesions_at(nx, positions, rng):
    les = np.zeros((nx, nx))
    for cy, cx in positions:
        mm._disc(les, cy, cx, rng.uniform(0.9, 1.5), rng.uniform(0.55, 0.85))
    return les


def lesion_positions(rng, nx, n, support):
    pos = []
    while len(pos) < n:
        cy, cx = rng.integers(int(0.12 * nx), int(0.88 * nx), 2)
        if support[cy, cx]:
            continue
        pos.append((int(cy), int(cx)))
    return pos


def build(kind, level):
    nx, K = mm.NX, mm.K
    truths0, lesions, base, masks, alphas = M1.setup()
    les_stack = truths0 - base
    rng = np.random.default_rng(31)
    if kind == "shift":
        S = int(level)
        out = [np.clip(base + les_stack[0], 0, None)]
        for i in range(1, K):
            dy, dx = rng.integers(-S, S + 1, 2)
            out.append(np.clip(np.roll(base, (dy, dx), axis=(0, 1)) + les_stack[i], 0, None))
        truths = np.array(out)
    elif kind == "gain":
        out = []
        for i in range(K):
            f = ndimage.gaussian_filter(rng.standard_normal((nx, nx)), 9.0)
            f /= np.abs(f).max() + 1e-12
            out.append(np.clip(base * (1 + level * f) + les_stack[i], 0, None))
        truths = np.array(out)
    elif kind == "overlap":
        support = base > 0.02
        pos = lesion_positions(rng, nx, max(mm.N_LESION), support)
        out = []
        for i in range(K):
            out.append(np.clip(base + lesions_at(nx, pos[:mm.N_LESION[i]],
                                                 np.random.default_rng(40)), 0, None))
        truths = np.array(out)
    else:
        truths = truths0
    if kind == "frac":
        masks = mm.slice_masks(np.random.default_rng(M1.SEED_MASK), frac=level)
    if kind == "commonmask":
        m0 = mm.kspace_mask(np.random.default_rng(M1.SEED_MASK))
        masks = np.array([m0] * K)
    return truths, masks, alphas


def job(spec):
    kind, level = spec
    truths, masks, alphas = build(kind, level)
    a_z = float(np.mean(alphas))
    ys = mm.acquire(truths, masks, NOISE, np.random.default_rng(M1.SEED_NOISE))
    _, Xi = ms.independent(ys, masks, alphas, 1e-4, LAM_P, ETA, ITERS)
    _, Xc, _, _ = ms.centralized(ys, masks, alphas, LAM_Z, a_z, LAM_D, ETA, ITERS)
    _, Xd, _, _, _ = ms.decentralized(ys, masks, alphas, LAM_Z, a_z, LAM_D, ETA, ITERS,
                                      eta_d=ETA_D)
    r = dict(kind=kind, level=level,
             sampled=[float(m.mean()) for m in masks],
             union=float(np.mean(np.any(masks, axis=0))))
    for tag, X in (("ind", Xi), ("cen", Xc), ("dec", Xd)):
        n_, p_, s_ = im.report(X, truths, mm.NX)
        r[tag] = dict(nrmse=n_, psnr=p_, ssim=s_)
    r["gain"] = r["ind"]["nrmse"] / r["dec"]["nrmse"]
    print(kind, level, f"ind {r['ind']['psnr']:.2f} cen {r['cen']['psnr']:.2f} "
          f"dec {r['dec']['psnr']:.2f} gain {r['gain']:.3f}", flush=True)
    return r


def main():
    specs = [("baseline", 0)]
    specs += [("shift", s) for s in (1, 2, 3)]
    specs += [("gain", g) for g in (0.05, 0.10, 0.20)]
    specs += [("overlap", 1)]
    specs += [("frac", f) for f in (0.15, 0.20, 0.40)]
    specs += [("commonmask", 0.30)]
    with Pool(2) as pool:
        res = pool.map(job, specs, chunksize=1)
    with open(os.path.join(RES, "c2_mismatch.json"), "w") as fh:
        json.dump(res, fh, indent=1)


if __name__ == "__main__":
    main()
