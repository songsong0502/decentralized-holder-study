"""Communication graphs and doubly-stochastic mixing matrices.

A decentralized method has no master: node i only exchanges vectors with
its graph neighbours, and averaging is done through a mixing matrix W
that is symmetric and doubly stochastic (rows and columns sum to one).
We build W by the Metropolis--Hastings rule, which needs only local
degree information, so a node can compute its own row from the identities
of its neighbours alone -- exactly what a real deployment can do.

The second largest eigenvalue modulus

    rho(W) = max( lambda_2(W), -lambda_m(W) )

controls how fast neighbour averaging drives the nodes to consensus; a
complete graph has rho = 0 (one step to the exact average), a ring has
rho close to 1 (slow mixing).  rho is the single scalar through which
topology enters every convergence statement in this report.
"""
import numpy as np


def ring(m):
    """Undirected ring: node i talks to i-1 and i+1 (mod m)."""
    A = np.zeros((m, m), dtype=int)
    for i in range(m):
        A[i, (i - 1) % m] = 1
        A[i, (i + 1) % m] = 1
    return A


def complete(m):
    """Every node talks to every other node."""
    return np.ones((m, m), dtype=int) - np.eye(m, dtype=int)


def star(m):
    """Node 0 is the hub; all others are leaves attached to it."""
    A = np.zeros((m, m), dtype=int)
    A[0, 1:] = 1
    A[1:, 0] = 1
    return A


def grid2d(rows, cols):
    """4-neighbour 2-D grid (used to mirror drones flying in a lattice)."""
    m = rows * cols
    A = np.zeros((m, m), dtype=int)
    for r in range(rows):
        for c in range(cols):
            k = r * cols + c
            if r > 0:
                A[k, k - cols] = A[k - cols, k] = 1
            if c > 0:
                A[k, k - 1] = A[k - 1, k] = 1
    return A


def erdos_renyi(m, prob=0.4, seed=0):
    """Random graph, resampled until connected (so consensus is possible)."""
    rng = np.random.default_rng(seed)
    while True:
        A = (rng.random((m, m)) < prob).astype(int)
        A = np.triu(A, 1)
        A = A + A.T
        if _connected(A):
            return A


def _connected(A):
    m = A.shape[0]
    seen = {0}
    stack = [0]
    while stack:
        u = stack.pop()
        for v in np.nonzero(A[u])[0]:
            if v not in seen:
                seen.add(int(v))
                stack.append(int(v))
    return len(seen) == m


def metropolis(A):
    """Metropolis--Hastings doubly-stochastic weights for adjacency A.

        W_ij = 1 / (1 + max(deg_i, deg_j))          (i, j) an edge
        W_ii = 1 - sum_{j != i} W_ij
    Symmetric, doubly stochastic, computable from local degrees only.
    """
    A = np.asarray(A)
    m = A.shape[0]
    deg = A.sum(axis=1)
    W = np.zeros((m, m))
    for i in range(m):
        for j in np.nonzero(A[i])[0]:
            W[i, j] = 1.0 / (1.0 + max(deg[i], deg[j]))
    for i in range(m):
        W[i, i] = 1.0 - W[i].sum()
    return W


def spectral_gap(W):
    """rho(W): second largest eigenvalue modulus (0 = instant averaging)."""
    ev = np.sort(np.abs(np.linalg.eigvalsh(W)))[::-1]
    return float(ev[1])


TOPOLOGIES = {
    "complete": complete,
    "star": star,
    "ring": ring,
}
