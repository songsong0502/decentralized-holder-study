"""Standard image-reconstruction error measures.

A relative l2 error is convenient for optimization but is not what the
imaging literature reports.  The three standard measures are:

NRMSE -- normalised root-mean-square error,
    NRMSE = ||u - u_ref||_2 / ||u_ref||_2 ,
  a dimensionless global error.  Small is good.  This is the quantity the
  optimization also drives, so it links the two literatures.

PSNR -- peak signal-to-noise ratio, in decibels,
    PSNR = 10 log10( PEAK^2 / MSE ),   MSE = mean (u - u_ref)^2 ,
  with PEAK the maximum intensity of the reference.  It is the standard
  headline number for CT/MRI reconstruction quality; +3 dB means the mean
  square error halved.  Large is good.

SSIM -- structural similarity index,
    SSIM = (2 mu_x mu_y + C1)(2 cov_xy + C2)
           / ((mu_x^2 + mu_y^2 + C1)(var_x + var_y + C2)) ,
  computed on local windows and averaged.  Unlike NRMSE and PSNR it
  compares local STRUCTURE (means, variances, correlation) rather than
  pixel-by-pixel intensity, so it is sensitive to whether a lesion is still
  recognisable rather than merely to how far its grey value moved.  It lies
  in [-1, 1]; 1 is a perfect match.

Why report all three.  A reconstruction can improve its NRMSE by shrinking
everything toward the mean while destroying the focal detail a radiologist
looks for; SSIM catches that, NRMSE does not.  Reporting the three together
is what makes an imaging claim checkable.
"""
import numpy as np


def nrmse(u, ref):
    ref = np.asarray(ref, float); u = np.asarray(u, float)
    return float(np.linalg.norm(u - ref) / np.linalg.norm(ref))


def psnr(u, ref, peak=None):
    ref = np.asarray(ref, float); u = np.asarray(u, float)
    peak = float(ref.max()) if peak is None else float(peak)
    mse = float(np.mean((u - ref) ** 2))
    if mse <= 0:
        return float("inf")
    return float(10.0 * np.log10(peak ** 2 / mse))


def ssim(u, ref, win=5, peak=None):
    """Windowed SSIM on 2-D images, averaged over all full windows."""
    u = np.asarray(u, float); ref = np.asarray(ref, float)
    peak = float(ref.max()) if peak is None else float(peak)
    C1 = (0.01 * peak) ** 2
    C2 = (0.03 * peak) ** 2
    H, W = ref.shape
    vals = []
    for i in range(0, H - win + 1):
        for j in range(0, W - win + 1):
            a = u[i:i + win, j:j + win].ravel()
            b = ref[i:i + win, j:j + win].ravel()
            ma, mb = a.mean(), b.mean()
            va, vb = a.var(), b.var()
            cov = ((a - ma) * (b - mb)).mean()
            vals.append(((2 * ma * mb + C1) * (2 * cov + C2)) /
                        ((ma ** 2 + mb ** 2 + C1) * (va + vb + C2)))
    return float(np.mean(vals))


def report(u_stack, ref_stack, nx):
    """Mean NRMSE / PSNR / SSIM over a stack of flattened images."""
    ns = [nrmse(u, r) for u, r in zip(u_stack, ref_stack)]
    ps = [psnr(u, r, peak=float(np.max(ref_stack))) for u, r in zip(u_stack, ref_stack)]
    ss = [ssim(u.reshape(nx, nx), r.reshape(nx, nx), peak=float(np.max(ref_stack)))
          for u, r in zip(u_stack, ref_stack)]
    return float(np.mean(ns)), float(np.mean(ps)), float(np.mean(ss))
